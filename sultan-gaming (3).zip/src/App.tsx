import React from 'react';
import { StoreProvider, useStore } from './context/StoreContext';
import { Header } from './components/layout/Header';
import { Sidebar } from './components/layout/Sidebar';
import { Footer } from './components/layout/Footer';
import { SearchModal } from './components/common/SearchModal';
import { AuthModal } from './components/common/AuthModal';
import { ProfileModal } from './components/common/ProfileModal';
import { HomePage } from './pages/HomePage';
import { CommunityPage } from './pages/CommunityPage';
import { PCSpecsPage } from './pages/PCSpecsPage';
import { GiveawaysPage } from './pages/GiveawaysPage';
import { FAQPage } from './pages/FAQPage';
import { YouTubePage } from './pages/YouTubePage';
import { KickPage } from './pages/KickPage';
import { DiscordPage } from './pages/DiscordPage';
import { InstagramPage } from './pages/InstagramPage';
import { GameDetailPage } from './pages/GameDetailPage';
import { AdminPage } from './pages/AdminPage';
import { DashboardPage } from './pages/DashboardPage';

const AppContent: React.FC = () => {
  const { currentPage } = useStore();

  const renderActivePage = () => {
    if (currentPage.startsWith('game-')) {
      const slug = currentPage.replace('game-', '');
      return <GameDetailPage gameSlug={slug} />;
    }

    switch (currentPage) {
      case 'home':
        return <HomePage />;
      case 'community':
        return <CommunityPage />;
      case 'dashboard':
        return <DashboardPage />;
      case 'pc-specs':
        return <PCSpecsPage />;
      case 'giveaways':
        return <GiveawaysPage />;
      case 'faq':
        return <FAQPage />;
      case 'youtube':
        return <YouTubePage />;
      case 'kick':
        return <KickPage />;
      case 'discord':
        return <DiscordPage />;
      case 'instagram':
        return <InstagramPage />;
      case 'admin':
        return <AdminPage />;
      default:
        return <HomePage />;
    }
  };

  return (
    <div className="min-h-screen bg-[#020817] text-[#EAF4FF] flex flex-col selection:bg-[#FF7A00] selection:text-white font-['Plus_Jakarta_Sans',sans-serif]">
      {/* Top Header */}
      <Header />

      {/* Main Layout Body */}
      <div className="flex-1 flex max-w-[1700px] w-full mx-auto relative px-3 sm:px-6 lg:px-8">
        {/* Left Sticky Sidebar */}
        <Sidebar />

        {/* Main Content View with Smooth Layout Transition */}
        <main className="flex-1 w-full lg:pl-72 py-6 min-w-0">
          <div className="w-full">
            {renderActivePage()}
          </div>
        </main>
      </div>

      {/* Global Footer */}
      <Footer />

      {/* Global Search Dialog Modal */}
      <SearchModal />

      {/* Auth & RBAC Modal */}
      <AuthModal />

      {/* User Profile & XP Modal */}
      <ProfileModal />
    </div>
  );
};

export default function App() {
  return (
    <StoreProvider>
      <AppContent />
    </StoreProvider>
  );
}
