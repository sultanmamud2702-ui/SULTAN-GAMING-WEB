export type PageId =
  | 'home'
  | 'dashboard'
  | 'community'
  | 'pc-specs'
  | 'giveaways'
  | 'faq'
  | 'platforms'
  | 'youtube'
  | 'kick'
  | 'discord'
  | 'instagram'
  | 'admin'
  | `game-${string}`;

export interface HeroSlide {
  id: string;
  category: string;
  title: string;
  titleHighlight: string;
  description: string;
  primaryBtnText: string;
  primaryBtnUrl: string;
  secondaryBtnText: string;
  secondaryBtnUrl: string;
  bgImage: string;
  order: number;
  active: boolean;
}

export type PlatformType =
  | 'video'
  | 'streaming'
  | 'social'
  | 'community'
  | 'youtube'
  | 'kick'
  | 'discord'
  | 'instagram'
  | 'twitch'
  | 'tiktok'
  | 'twitter'
  | 'custom';

export type SyncStatus =
  | 'CONNECTED'
  | 'SYNCING'
  | 'SYNCED'
  | 'SYNC_FAILED'
  | 'NOT_CONNECTED'
  | 'API_ERROR'
  | 'connected'
  | 'syncing'
  | 'error'
  | 'idle';

export interface SyncedContentItem {
  id: string;
  title: string;
  url?: string;
  thumbnail?: string;
  views?: string;
  likes?: string;
  comments?: string;
  publishedAt?: string;
  duration?: string;
  type?: 'video' | 'stream' | 'post' | 'clip';
}

export interface PlatformSyncedData {
  username?: string;
  handle?: string;
  channelName?: string;
  avatar?: string;
  banner?: string;
  description?: string;
  subscribers?: string;
  subscribersCount?: number;
  followers?: string;
  followersNum?: number;
  members?: string;
  membersCount?: number;
  onlineCount?: number;
  videoCount?: number;
  postCount?: number;
  followingCount?: number;
  liveStatus?: boolean;
  viewerCount?: number;
  streamTitle?: string;
  streamCategory?: string;
  latestContent?: SyncedContentItem[];
}

export interface Platform {
  id: string;
  name: string;
  url: string;
  logo: string;
  banner?: string;
  username?: string;
  handle?: string;
  followers: string;
  followersNum: number;
  subscribers?: string;
  subscribersCount?: number;
  members?: string;
  membersCount?: number;
  description?: string;
  platformType?: PlatformType;
  type: PlatformType | 'youtube' | 'kick' | 'discord' | 'instagram' | 'custom';
  accentColor: string;
  glowColor?: string;
  isActive: boolean;
  active?: boolean;
  displayOrder: number;
  order?: number;
  syncStatus: SyncStatus;
  lastSynced?: string;
  lastSyncAt?: string;
  lastSuccessfulSyncAt?: string;
  syncSource?: string;
  syncErrorMessage?: string;
  liveStatus?: boolean;
  viewerCount?: number;
  verified?: boolean;
  featured?: boolean;
  channelId?: string;
  syncedData?: PlatformSyncedData;
  createdAt?: string;
  updatedAt?: string;
}

export interface Game {
  id: string;
  title: string;
  slug: string;
  logo: string;
  banner: string;
  coverImage: string;
  description: string;
  shortDescription: string;
  genre: string;
  releaseYear: string;
  platform: string;
  color: string;
  featured: boolean;
  tags: string[];
  subscribersCount?: string;
  order: number;
}

export interface PollOption {
  id: string;
  text: string;
  votes: number;
}

export interface CommunityPost {
  id: string;
  author: {
    name: string;
    avatar: string;
    level: number;
    badge?: string;
    verified?: boolean;
    isOwner?: boolean;
  };
  timestamp: string;
  gameTag: string;
  content: string;
  images?: string[];
  likes: number;
  commentsCount: number;
  userLiked?: boolean;
  poll?: {
    question: string;
    options: PollOption[];
    totalVotes: number;
    userVotedOptionId?: string;
  };
  link?: {
    url: string;
    title: string;
    description: string;
    image?: string;
  };
}

export interface CommunityComment {
  id: string;
  postId: string;
  author: {
    name: string;
    avatar: string;
    level: number;
  };
  timestamp: string;
  content: string;
  likes: number;
}

export interface PCSpecItem {
  id: string;
  category: 'gaming' | 'streaming' | 'editing' | 'multitasking' | string;
  name: string;
  specs: string;
  description: string;
  image: string;
  affiliateUrl?: string;
  buyUrl?: string;
  enabled?: boolean;
  order: number;
}

export interface GiveawayPrizeImage {
  title: string;
  image: string;
}

export interface GiveawayPrizeFeature {
  title: string;
  desc: string;
  icon: 'garage' | 'pool' | 'safe' | 'theater' | 'shield' | 'trophy';
}

export interface Giveaway {
  id: string;
  title: string;
  edition: string;
  description: string;
  banner: string;
  mainPrizeImage: string;
  prizeImages: GiveawayPrizeImage[];
  prizeFeatures: GiveawayPrizeFeature[];
  prizeValue: string;
  endDate: string; // ISO format or future timestamp
  completed: boolean;
  winnerName?: string;
  winnerAnnounced?: boolean;
  terms: string[];
  entriesCount: number;
  isEntered?: boolean;
}

export interface FAQItem {
  id: string;
  question: string;
  answer: string;
  category: 'giveaway' | 'specs' | 'community' | 'general';
  icon: 'book' | 'globe' | 'trophy' | 'shield' | 'truck' | 'settings' | 'help';
  order: number;
}

export interface VideoItem {
  id: string;
  title: string;
  duration: string;
  views: string;
  viewsCount: number;
  uploadDate: string;
  channelName: string;
  channelLogo: string;
  thumbnail: string;
  platform: 'youtube' | 'kick';
  url: string;
  gameSlug: string;
  isLive?: boolean;
  isShort?: boolean;
  playlistId?: string;
}

export interface Playlist {
  id: string;
  title: string;
  videoCount: number;
  thumbnail: string;
  gameSlug: string;
}

export interface DiscordChannel {
  id: string;
  name: string;
  type: 'text' | 'voice';
  description?: string;
  activeUsers?: number;
}

export interface DiscordEvent {
  id: string;
  title: string;
  date: string;
  time: string;
  gameSlug: string;
  gameTitle: string;
  participants: number;
}

export interface InstagramPost {
  id: string;
  image: string;
  likes: string;
  likesCount: number;
  comments: number;
  caption: string;
  date: string;
  pinned?: boolean;
  isReel?: boolean;
}

export interface InstagramStory {
  id: string;
  title: string;
  icon: string;
  image: string;
}

export interface SiteSettings {
  brandName: string;
  tagline: string;
  logoText: string;
  description: string;
  socialLinks: {
    youtube: string;
    kick: string;
    discord: string;
    instagram: string;
  };
  stats: {
    totalSubscribers: string;
    totalFollowers: string;
    totalViews: string;
    activeCommunityMembers: string;
  };
}

export interface NotificationItem {
  id: string;
  title: string;
  message: string;
  time: string;
  read: boolean;
  type: 'youtube' | 'kick' | 'giveaway' | 'community' | 'event';
  linkPage?: PageId;
}

export interface MediaItem {
  id: string;
  name: string;
  url: string;
  size: string;
  type: 'banner' | 'game' | 'hardware' | 'giveaway' | 'avatar' | 'post';
  createdAt: string;
}

export type UserRole = 'USER' | 'ADMIN' | 'SUPER_ADMIN';
export type UserStatus = 'ACTIVE' | 'SUSPENDED' | 'BANNED';

export interface UserUploadedFile {
  id: string;
  userId: string;
  name: string;
  url: string;
  size?: number;
  sizeFormatted?: string;
  type?: string;
  category?: 'avatar' | 'post' | 'media' | 'document' | 'other';
  createdAt: string;
  uploaderEmail?: string;
  uploaderName?: string;
}

export interface FirestoreUserData {
  id: string;
  email: string;
  displayName?: string;
  username?: string;
  avatar?: string;
  role?: string;
  status?: string;
  createdAt: string;
  lastLoginAt?: string;
  filesCount?: number;
  uploadedFiles?: UserUploadedFile[];
}

export interface User {
  id: string;
  googleId?: string;
  email: string;
  displayName: string;
  username: string;
  avatar: string;
  bio?: string;
  role: UserRole;
  status: UserStatus;
  verified: boolean;
  level: number;
  xp: number;
  postsCount: number;
  commentsCount: number;
  giveawaysEnteredCount: number;
  filesCount?: number;
  createdAt: string;
  lastLoginAt: string;
}

export interface AuditLog {
  id: string;
  action: string;
  adminId: string;
  adminName: string;
  adminRole: UserRole;
  targetId?: string;
  targetType?: string;
  details: string;
  ipAddress?: string;
  timestamp: string;
}

export interface ReportItem {
  id: string;
  reporterId: string;
  reporterName: string;
  targetType: 'post' | 'comment' | 'user';
  targetId: string;
  targetSnippet?: string;
  reason: string;
  status: 'pending' | 'resolved' | 'dismissed';
  actionTaken?: string;
  resolvedBy?: string;
  createdAt: string;
  resolvedAt?: string;
}

export interface AuthState {
  user: User | null;
  isAuthenticated: boolean;
  isLoading: boolean;
}

