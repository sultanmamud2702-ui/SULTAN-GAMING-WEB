import React, { createContext, useContext, useState, useEffect, ReactNode, useCallback } from 'react';
import confetti from 'canvas-confetti';
import { auth, googleProvider, db, ADMIN_USER_ID, handleFirestoreError, OperationType } from '../lib/firebase';
import {
  signInWithEmailAndPassword,
  createUserWithEmailAndPassword,
  sendEmailVerification,
  signInWithPopup,
  signOut,
  onAuthStateChanged,
} from 'firebase/auth';
import {
  collection,
  doc,
  getDoc,
  getDocs,
  setDoc,
  deleteDoc,
  query,
} from 'firebase/firestore';
import {
  PageId,
  Game,
  Platform,
  HeroSlide,
  CommunityPost,
  PCSpecItem,
  Giveaway,
  FAQItem,
  VideoItem,
  Playlist,
  DiscordChannel,
  DiscordEvent,
  InstagramPost,
  InstagramStory,
  SiteSettings,
  NotificationItem,
  MediaItem,
  User,
  UserRole,
  UserStatus,
  AuditLog,
  ReportItem,
  UserUploadedFile,
  FirestoreUserData,
} from '../types';
import {
  INITIAL_SETTINGS,
  INITIAL_HERO_SLIDES,
  INITIAL_PLATFORMS,
  INITIAL_GAMES,
  INITIAL_COMMUNITY_POSTS,
  INITIAL_PC_SPECS,
  INITIAL_GIVEAWAYS,
  INITIAL_FAQS,
  INITIAL_VIDEOS,
  INITIAL_PLAYLISTS,
  INITIAL_DISCORD_CHANNELS,
  INITIAL_DISCORD_EVENTS,
  INITIAL_INSTAGRAM_POSTS,
  INITIAL_INSTAGRAM_STORIES,
  INITIAL_NOTIFICATIONS,
  INITIAL_MEDIA,
} from '../data/initialData';

interface StoreContextType {
  // Navigation & UI
  currentPage: PageId;
  setCurrentPage: (page: PageId) => void;
  sidebarCollapsed: boolean;
  toggleSidebar: () => void;
  mobileMenuOpen: boolean;
  setMobileMenuOpen: (open: boolean) => void;
  isSearchOpen: boolean;
  setIsSearchOpen: (open: boolean) => void;
  isAdmin: boolean;
  setIsAdmin: (admin: boolean) => void;

  // Global Search trigger
  openSearch: () => void;
  closeSearch: () => void;

  // Auth & User System
  currentUser: User | null;
  isAuthenticated: boolean;
  userRole: UserRole;
  isSuperAdmin: boolean;
  isModerator: boolean;
  hasRole: (roles: UserRole[]) => boolean;
  authModalOpen: boolean;
  setAuthModalOpen: (open: boolean) => void;
  profileModalOpen: boolean;
  setProfileModalOpen: (open: boolean) => void;
  signInWithEmail: (email: string, password: string) => Promise<{ success: boolean; requiresVerification?: boolean; email?: string; error?: string }>;
  signUpWithEmail: (email: string, password: string) => Promise<{ success: boolean; requiresVerification?: boolean; email?: string; error?: string }>;
  signInWithGoogle: () => Promise<{ success: boolean; error?: string }>;
  resendVerificationEmail: (email: string, password?: string) => Promise<{ success: boolean; error?: string }>;
  loginWithGoogle: (payload: { email: string; name?: string; picture?: string; credential?: string }) => Promise<boolean>;
  devSwitchRole: (role: UserRole, customUserId?: string) => Promise<boolean>;
  logout: () => Promise<void>;
  updateUserProfile: (updates: { displayName?: string; bio?: string; avatar?: string; username?: string }) => Promise<boolean>;
  deleteAccount: () => Promise<boolean>;

  // Settings
  settings: SiteSettings;
  updateSettings: (updates: Partial<SiteSettings>) => void;

  // Hero Slides
  heroSlides: HeroSlide[];
  addHeroSlide: (slide: Omit<HeroSlide, 'id'>) => void;
  updateHeroSlide: (id: string, updates: Partial<HeroSlide>) => void;
  deleteHeroSlide: (id: string) => void;

  // Platforms
  platforms: Platform[];
  fetchPlatforms: () => Promise<void>;
  uploadLogo: (fileData: string, fileName?: string) => Promise<{ success: boolean; url?: string; error?: string }>;
  uploadImage: (fileData: string, fileName?: string, folder?: string) => Promise<{ success: boolean; url?: string; error?: string }>;
  addPlatform: (platform: Partial<Platform>) => Promise<{ success: boolean; platform?: Platform; error?: string }>;
  updatePlatform: (id: string, updates: Partial<Platform>) => Promise<{ success: boolean; platform?: Platform; error?: string }>;
  deletePlatform: (id: string) => Promise<{ success: boolean; error?: string }>;
  togglePlatformActive: (id: string) => Promise<boolean>;
  reorderPlatforms: (orderedIds: string[]) => Promise<boolean>;
  syncPlatform: (id: string) => Promise<{ success: boolean; message?: string; error?: string }>;
  syncAllPlatforms: () => Promise<boolean>;
  isSyncingPlatform: boolean;

  // Games
  games: Game[];
  addGame: (game: Omit<Game, 'id'>) => void;
  updateGame: (id: string, updates: Partial<Game>) => void;
  deleteGame: (id: string) => void;

  // Community
  posts: CommunityPost[];
  addPost: (post: { gameTag: string; content: string; images?: string[]; poll?: { question: string; options: string[] } }) => Promise<void>;
  toggleLikePost: (postId: string) => Promise<void>;
  votePoll: (postId: string, optionId: string) => Promise<void>;
  deletePost: (postId: string) => Promise<void>;
  reportPost: (postId: string, reason: string) => Promise<boolean>;

  // PC Specs
  pcSpecs: PCSpecItem[];
  addPCSpec: (spec: Omit<PCSpecItem, 'id'>) => void;
  updatePCSpec: (id: string, updates: Partial<PCSpecItem>) => void;
  deletePCSpec: (id: string) => void;

  // Giveaways
  giveaways: Giveaway[];
  addGiveaway: (giveaway: Omit<Giveaway, 'id'>) => void;
  updateGiveaway: (id: string, updates: Partial<Giveaway>) => void;
  deleteGiveaway: (id: string) => void;
  enterGiveaway: (giveawayId: string, email: string, gamertag: string) => Promise<boolean>;
  drawGiveawayWinner: (giveawayId: string) => Promise<void>;

  // FAQs
  faqs: FAQItem[];
  addFAQ: (faq: Omit<FAQItem, 'id'>) => void;
  updateFAQ: (id: string, updates: Partial<FAQItem>) => void;
  deleteFAQ: (id: string) => void;

  // Media
  media: MediaItem[];
  addMedia: (media: Omit<MediaItem, 'id' | 'createdAt'>) => Promise<void>;
  deleteMedia: (id: string) => Promise<void>;

  // Administration & Security
  allUsers: User[];
  auditLogs: AuditLog[];
  reports: ReportItem[];
  fetchAllUsers: () => Promise<void>;
  fetchAuditLogs: () => Promise<void>;
  fetchReports: () => Promise<void>;
  updateUserRole: (userId: string, role: UserRole) => Promise<boolean>;
  updateUserStatus: (userId: string, status: UserStatus, reason?: string) => Promise<boolean>;
  resolveReport: (reportId: string, status: 'resolved' | 'dismissed', actionTaken?: string) => Promise<boolean>;

  // Firestore Users & Files Management
  firestoreUsers: FirestoreUserData[];
  isLoadingFirestoreUsers: boolean;
  fetchFirestoreUsers: () => Promise<FirestoreUserData[]>;
  fetchUserUploadedFiles: (userId: string) => Promise<UserUploadedFile[]>;
  uploadUserFile: (file: File, category?: string) => Promise<{ success: boolean; file?: UserUploadedFile; error?: string }>;
  deleteUserUploadedFile: (userId: string, fileId: string) => Promise<{ success: boolean; error?: string }>;
  simulateAdminLogin: () => Promise<void>;

  // YouTube / Videos
  videos: VideoItem[];
  playlists: Playlist[];
  addVideo: (video: Omit<VideoItem, 'id'>) => void;
  deleteVideo: (id: string) => void;
  syncYouTubeData: (channelUrl: string) => Promise<boolean>;

  // Discord
  discordChannels: DiscordChannel[];
  discordEvents: DiscordEvent[];

  // Instagram
  instagramPosts: InstagramPost[];
  instagramStories: InstagramStory[];

  // Notifications
  notifications: NotificationItem[];
  unreadCount: number;
  markNotificationAsRead: (id: string) => void;
  markAllNotificationsAsRead: () => void;
  addNotification: (notif: Omit<NotificationItem, 'id' | 'time' | 'read'>) => void;

  // Reset & Fun
  resetToDefaults: () => void;
  triggerConfetti: () => void;
}

const StoreContext = createContext<StoreContextType | undefined>(undefined);

const STORAGE_KEY = 'sultan_gaming_v1_store';

export const StoreProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  // Navigation State
  const [currentPage, setCurrentPageState] = useState<PageId>('home');
  const [sidebarCollapsed, setSidebarCollapsed] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [isSearchOpen, setIsSearchOpen] = useState(false);
  const [isAdmin, setIsAdmin] = useState(false);
  const [isSyncingPlatform, setIsSyncingPlatform] = useState(false);

  // Modals
  const [authModalOpen, setAuthModalOpen] = useState(false);
  const [profileModalOpen, setProfileModalOpen] = useState(false);

  // User & Auth State
  const [currentUser, setCurrentUser] = useState<User | null>(() => {
    const saved = localStorage.getItem(`${STORAGE_KEY}_user`);
    return saved
      ? JSON.parse(saved)
      : {
          id: 'user-sultan-owner',
          email: 'sultan@sultangaming.gg',
          displayName: 'Sultan (Owner)',
          username: 'sultan_owner',
          avatar: 'https://images.unsplash.com/photo-1566492031773-4f4e44671857?w=150&auto=format&fit=crop&q=80',
          bio: 'Official Creator & Streamer. GTA V, Palworld, Farming Simulator 25 & Minecraft.',
          role: 'SUPER_ADMIN' as UserRole,
          status: 'ACTIVE' as UserStatus,
          verified: true,
          level: 99,
          xp: 450000,
          postsCount: 14,
          commentsCount: 230,
          giveawaysEnteredCount: 0,
          createdAt: '2024-01-01T00:00:00.000Z',
          lastLoginAt: new Date().toISOString(),
        };
  });

  const isAuthenticated = !!currentUser && currentUser.status === 'ACTIVE';
  const userRole: UserRole = currentUser?.role || 'USER';
  const isSuperAdmin = currentUser?.role === 'SUPER_ADMIN';
  const isModerator = currentUser?.role === 'ADMIN' || currentUser?.role === 'SUPER_ADMIN';

  const hasRole = useCallback(
    (roles: UserRole[]): boolean => {
      if (!currentUser || currentUser.status !== 'ACTIVE') return false;
      return roles.includes(currentUser.role);
    },
    [currentUser]
  );

  // Admin Data State
  const [allUsers, setAllUsers] = useState<User[]>([]);
  const [auditLogs, setAuditLogs] = useState<AuditLog[]>([]);
  const [reports, setReports] = useState<ReportItem[]>([]);

  // Firestore Users & Files State
  const [firestoreUsers, setFirestoreUsers] = useState<FirestoreUserData[]>([]);
  const [isLoadingFirestoreUsers, setIsLoadingFirestoreUsers] = useState<boolean>(false);

  const syncUserDocToFirestore = async (user: User) => {
    if (!user || !user.id) return;
    try {
      const userRef = doc(db, 'users', user.id);
      await setDoc(
        userRef,
        {
          id: user.id,
          email: user.email,
          displayName: user.displayName || 'Gamer',
          username: user.username || user.displayName?.toLowerCase().replace(/\s+/g, '') || 'gamer',
          avatar: user.avatar || '',
          role: user.id === ADMIN_USER_ID ? 'SUPER_ADMIN' : user.role || 'USER',
          status: user.status || 'ACTIVE',
          createdAt: user.createdAt || new Date().toISOString(),
          lastLoginAt: new Date().toISOString(),
          filesCount: user.filesCount || 0,
        },
        { merge: true }
      );
    } catch (err) {
      handleFirestoreError(err, OperationType.WRITE, `users/${user.id}`);
    }
  };

  // Entities state with persistence
  const [settings, setSettings] = useState<SiteSettings>(() => {
    const saved = localStorage.getItem(`${STORAGE_KEY}_settings`);
    return saved ? JSON.parse(saved) : INITIAL_SETTINGS;
  });

  const [heroSlides, setHeroSlides] = useState<HeroSlide[]>(() => {
    const saved = localStorage.getItem(`${STORAGE_KEY}_hero_slides`);
    return saved ? JSON.parse(saved) : INITIAL_HERO_SLIDES;
  });

  const [platforms, setPlatforms] = useState<Platform[]>(() => {
    const saved = localStorage.getItem(`${STORAGE_KEY}_platforms`);
    return saved ? JSON.parse(saved) : INITIAL_PLATFORMS;
  });

  const [games, setGames] = useState<Game[]>(() => {
    const saved = localStorage.getItem(`${STORAGE_KEY}_games`);
    return saved ? JSON.parse(saved) : INITIAL_GAMES;
  });

  const [posts, setPosts] = useState<CommunityPost[]>(() => {
    const saved = localStorage.getItem(`${STORAGE_KEY}_posts`);
    return saved ? JSON.parse(saved) : INITIAL_COMMUNITY_POSTS;
  });

  const [pcSpecs, setPcSpecs] = useState<PCSpecItem[]>(() => {
    const saved = localStorage.getItem(`${STORAGE_KEY}_pc_specs`);
    return saved ? JSON.parse(saved) : INITIAL_PC_SPECS;
  });

  const [giveaways, setGiveaways] = useState<Giveaway[]>(() => {
    const saved = localStorage.getItem(`${STORAGE_KEY}_giveaways`);
    return saved ? JSON.parse(saved) : INITIAL_GIVEAWAYS;
  });

  const [faqs, setFaqs] = useState<FAQItem[]>(() => {
    const saved = localStorage.getItem(`${STORAGE_KEY}_faqs`);
    return saved ? JSON.parse(saved) : INITIAL_FAQS;
  });

  const [videos, setVideos] = useState<VideoItem[]>(() => {
    const saved = localStorage.getItem(`${STORAGE_KEY}_videos`);
    return saved ? JSON.parse(saved) : INITIAL_VIDEOS;
  });

  const [playlists, setPlaylists] = useState<Playlist[]>(() => {
    const saved = localStorage.getItem(`${STORAGE_KEY}_playlists`);
    return saved ? JSON.parse(saved) : INITIAL_PLAYLISTS;
  });

  const [discordChannels] = useState<DiscordChannel[]>(INITIAL_DISCORD_CHANNELS);
  const [discordEvents] = useState<DiscordEvent[]>(INITIAL_DISCORD_EVENTS);
  const [instagramPosts] = useState<InstagramPost[]>(INITIAL_INSTAGRAM_POSTS);
  const [instagramStories] = useState<InstagramStory[]>(INITIAL_INSTAGRAM_STORIES);

  const [notifications, setNotifications] = useState<NotificationItem[]>(() => {
    const saved = localStorage.getItem(`${STORAGE_KEY}_notifications`);
    return saved ? JSON.parse(saved) : INITIAL_NOTIFICATIONS;
  });

  const [media, setMedia] = useState<MediaItem[]>(() => {
    const saved = localStorage.getItem(`${STORAGE_KEY}_media`);
    return saved ? JSON.parse(saved) : INITIAL_MEDIA;
  });

  // Keep admin status synced with user role
  useEffect(() => {
    setIsAdmin(isModerator);
  }, [isModerator]);

  // Persist Current User
  useEffect(() => {
    if (currentUser) {
      localStorage.setItem(`${STORAGE_KEY}_user`, JSON.stringify(currentUser));
    } else {
      localStorage.removeItem(`${STORAGE_KEY}_user`);
    }
  }, [currentUser]);

  // Initial Auth Check & Fetch from server
  const fetchAuthUser = useCallback(async () => {
    try {
      const res = await fetch('/api/auth/me');
      if (res.ok) {
        const data = await res.json();
        if (data.authenticated && data.user) {
          setCurrentUser(data.user);
        }
      }
    } catch {
      // Backend starting or offline, use local state
    }
  }, []);

  const fetchPosts = useCallback(async () => {
    try {
      const res = await fetch('/api/posts');
      if (res.ok) {
        const data = await res.json();
        if (data.posts) {
          setPosts(data.posts);
        }
      }
    } catch {
      // fallback
    }
  }, []);

  const fetchGiveaways = useCallback(async () => {
    try {
      const res = await fetch('/api/giveaways');
      if (res.ok) {
        const data = await res.json();
        if (data.giveaways) {
          setGiveaways(data.giveaways);
        }
      }
    } catch {
      // fallback
    }
  }, []);

  const fetchAllUsers = useCallback(async () => {
    try {
      const res = await fetch('/api/admin/users');
      if (res.ok) {
        const data = await res.json();
        if (data.users) {
          setAllUsers(data.users);
        }
      }
    } catch {
      // fallback
    }
  }, []);

  const fetchAuditLogs = useCallback(async () => {
    try {
      const res = await fetch('/api/admin/audit-logs');
      if (res.ok) {
        const data = await res.json();
        if (data.auditLogs) {
          setAuditLogs(data.auditLogs);
        }
      }
    } catch {
      // fallback
    }
  }, []);

  const fetchReports = useCallback(async () => {
    try {
      const res = await fetch('/api/admin/reports');
      if (res.ok) {
        const data = await res.json();
        if (data.reports) {
          setReports(data.reports);
        }
      }
    } catch {
      // fallback
    }
  }, []);

  const fetchPlatforms = useCallback(async () => {
    try {
      const res = await fetch('/api/platforms?includeInactive=true');
      if (res.ok) {
        const data = await res.json();
        if (data.platforms && Array.isArray(data.platforms) && data.platforms.length > 0) {
          setPlatforms(data.platforms);
        }
      }
    } catch {
      // Keep local state
    }
  }, []);

  useEffect(() => {
    fetchAuthUser();
    fetchPlatforms();
    fetchPosts();
    fetchGiveaways();
  }, [fetchAuthUser, fetchPlatforms, fetchPosts, fetchGiveaways]);

  // Firebase Auth State Listener
  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, (fbUser) => {
      if (fbUser) {
        // Only restore session if email is verified
        if (!fbUser.emailVerified) {
          return;
        }
        const email = fbUser.email || '';
        const isOwner = fbUser.uid === ADMIN_USER_ID || email === 'samgaming2726@gmail.com' || email === 'sultan@sultangaming.gg';
        const formattedName = fbUser.displayName || (email ? email.split('@')[0] : 'Gamer');
        const formattedUsername = (email ? email.split('@')[0].replace(/[^a-zA-Z0-9_]/g, '_') : 'gamer').toLowerCase();

        const userObj: User = {
          id: fbUser.uid,
          email: email,
          displayName: formattedName,
          username: formattedUsername,
          avatar: fbUser.photoURL || 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=150&auto=format&fit=crop&q=80',
          bio: 'Sultan Gaming Community Member',
          role: isOwner ? 'SUPER_ADMIN' : 'USER',
          status: 'ACTIVE',
          verified: true,
          level: 1,
          xp: 250,
          postsCount: 0,
          commentsCount: 0,
          giveawaysEnteredCount: 0,
          createdAt: fbUser.metadata?.creationTime || new Date().toISOString(),
          lastLoginAt: new Date().toISOString(),
        };

        setCurrentUser((prev) => {
          if (prev && prev.id === fbUser.uid && prev.email === email) {
            return prev;
          }
          return {
            ...userObj,
            role: prev?.role && prev.id === fbUser.uid ? prev.role : userObj.role,
            level: prev?.level || 1,
            xp: prev?.xp || 250,
            postsCount: prev?.postsCount || 0,
            commentsCount: prev?.commentsCount || 0,
            giveawaysEnteredCount: prev?.giveawaysEnteredCount || 0,
          };
        });

        syncUserDocToFirestore(userObj);
      }
    });

    return () => unsubscribe();
  }, []);

  // Firebase Auth Actions
  const signInWithEmail = async (email: string, password: string): Promise<{ success: boolean; requiresVerification?: boolean; email?: string; error?: string }> => {
    try {
      const cred = await signInWithEmailAndPassword(auth, email.trim(), password);
      const fbUser = cred.user;
      const userEmail = fbUser.email || email.trim();

      // Check if email is verified
      if (!fbUser.emailVerified) {
        // If a user logs in and their email is not verified, block access and sign them out
        await signOut(auth);
        setCurrentUser(null);
        return {
          success: false,
          requiresVerification: true,
          email: userEmail,
        };
      }

      const isOwner = fbUser.uid === ADMIN_USER_ID || userEmail === 'samgaming2726@gmail.com' || userEmail === 'sultan@sultangaming.gg';
      const formattedName = fbUser.displayName || (userEmail ? userEmail.split('@')[0] : 'Gamer');
      const formattedUsername = (userEmail ? userEmail.split('@')[0].replace(/[^a-zA-Z0-9_]/g, '_') : 'gamer').toLowerCase();

      const mappedUser: User = {
        id: fbUser.uid,
        email: userEmail,
        displayName: formattedName,
        username: formattedUsername,
        avatar: fbUser.photoURL || 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=150&auto=format&fit=crop&q=80',
        bio: 'Sultan Gaming Community Member',
        role: isOwner ? 'SUPER_ADMIN' : 'USER',
        status: 'ACTIVE',
        verified: true,
        level: 1,
        xp: 500,
        postsCount: 0,
        commentsCount: 0,
        giveawaysEnteredCount: 0,
        createdAt: fbUser.metadata?.creationTime || new Date().toISOString(),
        lastLoginAt: new Date().toISOString(),
      };

      setCurrentUser(mappedUser);
      await syncUserDocToFirestore(mappedUser);
      // Requirement: On successful sign-in or sign-up, redirect to the dashboard
      setCurrentPageState('dashboard');
      setAuthModalOpen(false);
      triggerConfetti();
      addNotification({
        title: 'Welcome Back!',
        message: `Signed in as ${mappedUser.displayName}`,
        type: 'community',
      });
      fetchPosts();
      return { success: true };
    } catch (err: unknown) {
      console.error('Firebase SignIn error:', err);
      // Requirement: If credentials are incorrect, show: "Email or password is incorrect"
      return { success: false, error: 'Email or password is incorrect' };
    }
  };

  const signUpWithEmail = async (email: string, password: string): Promise<{ success: boolean; requiresVerification?: boolean; email?: string; error?: string }> => {
    try {
      const cred = await createUserWithEmailAndPassword(auth, email.trim(), password);
      const fbUser = cred.user;
      const userEmail = fbUser.email || email.trim();

      // Send verification email
      try {
        await sendEmailVerification(fbUser);
      } catch (verifErr) {
        console.warn('sendEmailVerification notice:', verifErr);
      }

      // When a user registers with email/password, do not sign them in automatically
      await signOut(auth);
      setCurrentUser(null);

      return {
        success: true,
        requiresVerification: true,
        email: userEmail,
      };
    } catch (err: unknown) {
      console.error('Firebase SignUp error:', err);
      const errObj = err as { code?: string; message?: string };
      const code = errObj?.code || '';
      const message = errObj?.message || '';

      // Requirement: If the email already exists, show: "User already exists. Please sign in"
      if (code === 'auth/email-already-in-use' || message.includes('email-already-in-use')) {
        return { success: false, error: 'User already exists. Please sign in' };
      }
      if (code === 'auth/weak-password' || message.includes('weak-password')) {
        return { success: false, error: 'Password should be at least 6 characters' };
      }
      if (code === 'auth/invalid-email' || message.includes('invalid-email')) {
        return { success: false, error: 'Please enter a valid email address' };
      }
      return { success: false, error: message || 'Failed to create account. Please try again.' };
    }
  };

  const signInWithGoogle = async (): Promise<{ success: boolean; error?: string }> => {
    try {
      const result = await signInWithPopup(auth, googleProvider);
      const fbUser = result.user;
      const userEmail = fbUser.email || '';
      const isOwner = userEmail === 'samgaming2726@gmail.com' || userEmail === 'sultan@sultangaming.gg';
      const formattedName = fbUser.displayName || (userEmail ? userEmail.split('@')[0] : 'Gamer');
      const formattedUsername = (userEmail ? userEmail.split('@')[0].replace(/[^a-zA-Z0-9_]/g, '_') : 'gamer').toLowerCase();

      const mappedUser: User = {
        id: fbUser.uid,
        email: userEmail,
        displayName: formattedName,
        username: formattedUsername,
        avatar: fbUser.photoURL || 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=150&auto=format&fit=crop&q=80',
        bio: 'Sultan Gaming Community Member',
        role: isOwner ? 'SUPER_ADMIN' : 'USER',
        status: 'ACTIVE',
        verified: true,
        level: 1,
        xp: 500,
        postsCount: 0,
        commentsCount: 0,
        giveawaysEnteredCount: 0,
        createdAt: fbUser.metadata?.creationTime || new Date().toISOString(),
        lastLoginAt: new Date().toISOString(),
      };

      setCurrentUser(mappedUser);
      setCurrentPageState('home');
      setAuthModalOpen(false);
      triggerConfetti();
      addNotification({
        title: 'Welcome Back!',
        message: `Signed in as ${mappedUser.displayName}`,
        type: 'community',
      });
      fetchPosts();
      return { success: true };
    } catch (err: unknown) {
      console.error('Firebase Google SignIn error:', err);
      const errObj = err as { code?: string; message?: string };
      if (errObj?.code === 'auth/popup-closed-by-user') {
        return { success: false, error: 'Google sign-in was cancelled.' };
      }
      if (errObj?.code === 'auth/cancelled-popup-request') {
        return { success: false, error: 'Sign-in request was cancelled.' };
      }
      if (errObj?.code === 'auth/popup-blocked') {
        return { success: false, error: 'Google sign-in popup was blocked. Please enable popups.' };
      }
      if (errObj?.code === 'auth/unauthorized-domain') {
        const currentDomain = typeof window !== 'undefined' ? window.location.hostname : '';
        return {
          success: false,
          error: `Domain "${currentDomain}" is not in Firebase Authorized Domains. Add this domain in Firebase Console (Authentication > Settings > Authorized Domains), or sign in with Email/Password.`,
        };
      }
      return { success: false, error: errObj?.message || 'Google sign-in failed. Please try again.' };
    }
  };

  const resendVerificationEmail = async (email: string, password?: string): Promise<{ success: boolean; error?: string }> => {
    try {
      if (password) {
        const cred = await signInWithEmailAndPassword(auth, email.trim(), password);
        await sendEmailVerification(cred.user);
        await signOut(auth);
        return { success: true };
      } else if (auth.currentUser) {
        await sendEmailVerification(auth.currentUser);
        await signOut(auth);
        return { success: true };
      }
      return { success: false, error: 'Please log in again to request a new verification email.' };
    } catch (err: unknown) {
      const errObj = err as { message?: string };
      return { success: false, error: errObj?.message || 'Could not send verification email.' };
    }
  };

  const loginWithGoogle = async (payload: { email: string; name?: string; picture?: string; credential?: string }) => {
    try {
      const res = await fetch('/api/auth/google', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload),
      });
      const data = await res.json();
      if (res.ok && data.user) {
        setCurrentUser(data.user);
        triggerConfetti();
        addNotification({
          title: 'Welcome Back!',
          message: `Logged in as ${data.user.displayName}`,
          type: 'community',
        });
        setAuthModalOpen(false);
        fetchPosts();
        return true;
      }
      return false;
    } catch {
      return false;
    }
  };

  const devSwitchRole = async (role: UserRole, customUserId?: string) => {
    try {
      const res = await fetch('/api/auth/dev-switch-role', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ role, customUserId }),
      });
      const data = await res.json();
      if (res.ok && data.user) {
        setCurrentUser(data.user);
        addNotification({
          title: 'Role Switched',
          message: `Now acting as ${data.user.displayName} (${data.user.role})`,
          type: 'community',
        });
        setAuthModalOpen(false);
        fetchPosts();
        if (data.user.role !== 'USER') {
          fetchAllUsers();
          fetchAuditLogs();
          fetchReports();
        }
        return true;
      }
      return false;
    } catch {
      return false;
    }
  };

  const logout = async () => {
    try {
      await signOut(auth);
    } catch (err) {
      console.error('Firebase SignOut error:', err);
    }
    try {
      await fetch('/api/auth/logout', { method: 'POST' });
    } catch {
      // ignore
    }
    setCurrentUser(null);
    localStorage.removeItem(`${STORAGE_KEY}_user`);
    addNotification({
      title: 'Logged Out',
      message: 'You have been signed out safely.',
      type: 'community',
    });
    // Requirement: Add a logout button that signs the user out and returns to the auth screen
    setAuthModalOpen(true);
    fetchPosts();
  };

  const updateUserProfile = async (updates: { displayName?: string; bio?: string; avatar?: string; username?: string }) => {
    try {
      const res = await fetch('/api/auth/profile', {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(updates),
      });
      const data = await res.json();
      if (res.ok && data.user) {
        setCurrentUser(data.user);
        addNotification({
          title: 'Profile Updated',
          message: 'Your profile changes have been saved.',
          type: 'community',
        });
        return true;
      }
      return false;
    } catch {
      return false;
    }
  };

  const deleteAccount = async () => {
    try {
      const res = await fetch('/api/auth/account', { method: 'DELETE' });
      if (res.ok) {
        setCurrentUser(null);
        localStorage.removeItem(`${STORAGE_KEY}_user`);
        setProfileModalOpen(false);
        addNotification({
          title: 'Account Deleted',
          message: 'Your account and personal data have been removed.',
          type: 'community',
        });
        return true;
      }
      return false;
    } catch {
      return false;
    }
  };

  // Administration Actions
  const updateUserRole = async (userId: string, role: UserRole) => {
    try {
      const res = await fetch(`/api/admin/users/${userId}/role`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ role }),
      });
      if (res.ok) {
        fetchAllUsers();
        fetchAuditLogs();
        addNotification({
          title: 'User Role Updated',
          message: `User permissions updated to ${role}.`,
          type: 'community',
        });
        return true;
      }
      return false;
    } catch {
      return false;
    }
  };

  const updateUserStatus = async (userId: string, status: UserStatus, reason?: string) => {
    try {
      const res = await fetch(`/api/admin/users/${userId}/status`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ status, reason }),
      });
      if (res.ok) {
        fetchAllUsers();
        fetchAuditLogs();
        addNotification({
          title: 'User Status Updated',
          message: `User marked as ${status}.`,
          type: 'community',
        });
        return true;
      }
      return false;
    } catch {
      return false;
    }
  };

  const resolveReport = async (reportId: string, status: 'resolved' | 'dismissed', actionTaken?: string) => {
    try {
      const res = await fetch(`/api/admin/reports/${reportId}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ status, actionTaken }),
      });
      if (res.ok) {
        fetchReports();
        fetchAuditLogs();
        addNotification({
          title: 'Report Updated',
          message: `Report status set to ${status}.`,
          type: 'community',
        });
        return true;
      }
      return false;
    } catch {
      return false;
    }
  };

  // Save to local storage whenever items change
  useEffect(() => {
    localStorage.setItem(`${STORAGE_KEY}_settings`, JSON.stringify(settings));
  }, [settings]);

  useEffect(() => {
    localStorage.setItem(`${STORAGE_KEY}_hero_slides`, JSON.stringify(heroSlides));
  }, [heroSlides]);

  useEffect(() => {
    localStorage.setItem(`${STORAGE_KEY}_platforms`, JSON.stringify(platforms));
  }, [platforms]);

  useEffect(() => {
    localStorage.setItem(`${STORAGE_KEY}_games`, JSON.stringify(games));
  }, [games]);

  useEffect(() => {
    localStorage.setItem(`${STORAGE_KEY}_posts`, JSON.stringify(posts));
  }, [posts]);

  useEffect(() => {
    localStorage.setItem(`${STORAGE_KEY}_pc_specs`, JSON.stringify(pcSpecs));
  }, [pcSpecs]);

  useEffect(() => {
    localStorage.setItem(`${STORAGE_KEY}_giveaways`, JSON.stringify(giveaways));
  }, [giveaways]);

  useEffect(() => {
    localStorage.setItem(`${STORAGE_KEY}_faqs`, JSON.stringify(faqs));
  }, [faqs]);

  useEffect(() => {
    localStorage.setItem(`${STORAGE_KEY}_videos`, JSON.stringify(videos));
  }, [videos]);

  useEffect(() => {
    localStorage.setItem(`${STORAGE_KEY}_playlists`, JSON.stringify(playlists));
  }, [playlists]);

  useEffect(() => {
    localStorage.setItem(`${STORAGE_KEY}_notifications`, JSON.stringify(notifications));
  }, [notifications]);

  useEffect(() => {
    localStorage.setItem(`${STORAGE_KEY}_media`, JSON.stringify(media));
  }, [media]);

  // Global Page Switcher
  const setCurrentPage = (page: PageId) => {
    setCurrentPageState(page);
    window.scrollTo({ top: 0, behavior: 'smooth' });
    setMobileMenuOpen(false);
  };

  const toggleSidebar = () => {
    setSidebarCollapsed(!sidebarCollapsed);
  };

  const openSearch = () => setIsSearchOpen(true);
  const closeSearch = () => setIsSearchOpen(false);

  const triggerConfetti = () => {
    confetti({
      particleCount: 80,
      spread: 70,
      origin: { y: 0.6 },
      colors: ['#FF7A00', '#FF9500', '#00B7FF', '#53FC18', '#FFFFFF'],
    });
  };

  // Settings Actions
  const updateSettings = (updates: Partial<SiteSettings>) => {
    setSettings(prev => ({ ...prev, ...updates }));
    addNotification({
      title: 'Settings Saved',
      message: 'Brand metadata and statistics successfully updated.',
      type: 'community',
    });
  };

  // Hero Slides Actions
  const addHeroSlide = (slide: Omit<HeroSlide, 'id'>) => {
    const newSlide: HeroSlide = {
      ...slide,
      id: `slide-${Date.now()}`,
    };
    setHeroSlides(prev => [...prev, newSlide]);
    addNotification({
      title: 'Hero Slide Created',
      message: `"${slide.title}" added to showcase carousel.`,
      type: 'community',
    });
  };

  const updateHeroSlide = (id: string, updates: Partial<HeroSlide>) => {
    setHeroSlides(prev => prev.map(s => (s.id === id ? { ...s, ...updates } : s)));
    addNotification({
      title: 'Hero Slide Updated',
      message: 'Slide contents saved successfully.',
      type: 'community',
    });
  };

  const deleteHeroSlide = (id: string) => {
    setHeroSlides(prev => prev.filter(s => s.id !== id));
    addNotification({
      title: 'Slide Deleted',
      message: 'Hero slide removed from website.',
      type: 'community',
    });
  };

  // Helper for admin request headers
  const getAuthHeaders = (includeContentType = false): Record<string, string> => {
    const token = typeof window !== 'undefined' ? localStorage.getItem('sultan_session_token') : null;
    const headers: Record<string, string> = {
      'x-user-id': currentUser?.id || 'user-sultan-owner',
      'x-user-role': currentUser?.role || 'SUPER_ADMIN',
    };
    if (includeContentType) {
      headers['Content-Type'] = 'application/json';
    }
    if (token) {
      headers['Authorization'] = `Bearer ${token}`;
    }
    return headers;
  };

  // Platform Actions
  const uploadLogo = async (fileData: string, fileName?: string): Promise<{ success: boolean; url?: string; error?: string }> => {
    try {
      const res = await fetch('/api/upload/logo', {
        method: 'POST',
        headers: getAuthHeaders(true),
        body: JSON.stringify({ fileData, fileName }),
      });
      const data = await res.json();
      if (res.ok && data.url) {
        return { success: true, url: data.url };
      }
      return { success: false, error: data.error || 'Failed to upload logo image' };
    } catch (err: any) {
      return { success: false, error: err?.message || 'Network error during logo upload.' };
    }
  };

  const uploadImage = async (fileData: string, fileName?: string, folder?: string): Promise<{ success: boolean; url?: string; error?: string }> => {
    try {
      const res = await fetch('/api/upload/image', {
        method: 'POST',
        headers: getAuthHeaders(true),
        body: JSON.stringify({ fileData, fileName, folder }),
      });
      const data = await res.json();
      if (res.ok && data.url) {
        return { success: true, url: data.url };
      }
      return { success: false, error: data.error || 'Failed to upload image' };
    } catch (err: any) {
      return { success: false, error: err?.message || 'Network error during image upload.' };
    }
  };

  const addPlatform = async (platform: Partial<Platform>): Promise<{ success: boolean; platform?: Platform; error?: string }> => {
    try {
      const res = await fetch('/api/admin/platforms', {
        method: 'POST',
        headers: getAuthHeaders(true),
        body: JSON.stringify(platform),
      });
      const data = await res.json();
      if (res.ok && data.platform) {
        setPlatforms(prev => [...prev.filter(p => p.id !== data.platform.id), data.platform]);
        addNotification({
          title: 'Platform Added',
          message: `${data.platform.name} channel successfully saved to database.`,
          type: 'community',
        });
        fetchAuditLogs();
        await fetchPlatforms();
        return { success: true, platform: data.platform };
      }
      return { success: false, error: data.error || 'Failed to create platform.' };
    } catch (err: any) {
      return { success: false, error: err?.message || 'Network error while saving platform.' };
    }
  };

  const updatePlatform = async (id: string, updates: Partial<Platform>): Promise<{ success: boolean; platform?: Platform; error?: string }> => {
    try {
      const res = await fetch(`/api/admin/platforms/${id}`, {
        method: 'PUT',
        headers: getAuthHeaders(true),
        body: JSON.stringify(updates),
      });
      const data = await res.json();
      if (res.ok && data.platform) {
        setPlatforms(prev => prev.map(p => (p.id === id ? { ...p, ...data.platform } : p)));
        addNotification({
          title: 'Platform Updated',
          message: `${data.platform.name} settings successfully updated in database.`,
          type: 'community',
        });
        fetchAuditLogs();
        await fetchPlatforms();
        return { success: true, platform: data.platform };
      }
      return { success: false, error: data.error || 'Failed to update platform.' };
    } catch (err: any) {
      return { success: false, error: err?.message || 'Network error while updating platform.' };
    }
  };

  const deletePlatform = async (id: string): Promise<{ success: boolean; error?: string }> => {
    try {
      const res = await fetch(`/api/admin/platforms/${id}`, {
        method: 'DELETE',
        headers: getAuthHeaders(false),
      });
      const data = await res.json();
      if (res.ok) {
        setPlatforms(prev => prev.filter(p => p.id !== id));
        addNotification({
          title: 'Platform Removed',
          message: 'Connected platform deleted from database.',
          type: 'community',
        });
        fetchAuditLogs();
        await fetchPlatforms();
        return { success: true };
      }
      return { success: false, error: data.error || 'Failed to delete platform.' };
    } catch (err: any) {
      return { success: false, error: err?.message || 'Network error while deleting platform.' };
    }
  };

  const togglePlatformActive = async (id: string): Promise<boolean> => {
    try {
      const res = await fetch(`/api/admin/platforms/${id}/toggle-active`, {
        method: 'PUT',
        headers: getAuthHeaders(false),
      });
      const data = await res.json();
      if (res.ok && data.platform) {
        setPlatforms(prev => prev.map(p => (p.id === id ? { ...p, ...data.platform } : p)));
        addNotification({
          title: 'Platform Status Updated',
          message: `${data.platform.name} is now ${data.platform.isActive ? 'Active & Visible' : 'Disabled'}.`,
          type: 'community',
        });
        fetchAuditLogs();
        return true;
      }
      return false;
    } catch {
      return false;
    }
  };

  const reorderPlatforms = async (orderedIds: string[]): Promise<boolean> => {
    try {
      const res = await fetch('/api/admin/platforms/reorder', {
        method: 'PUT',
        headers: getAuthHeaders(true),
        body: JSON.stringify({ orderedIds }),
      });
      const data = await res.json();
      if (res.ok && data.platforms) {
        setPlatforms(data.platforms);
        fetchAuditLogs();
        return true;
      }
      return false;
    } catch {
      return false;
    }
  };

  const syncPlatform = async (id: string): Promise<{ success: boolean; message?: string; error?: string }> => {
    setIsSyncingPlatform(true);
    try {
      const res = await fetch(`/api/admin/platforms/${id}/sync`, {
        method: 'POST',
        headers: getAuthHeaders(false),
      });
      const data = await res.json();
      if (res.ok && data.platform) {
        setPlatforms(prev => prev.map(p => (p.id === id ? { ...p, ...data.platform } : p)));
        triggerConfetti();
        addNotification({
          title: 'Platform Synchronized',
          message: data.message || `Successfully synchronized live data for ${data.platform.name}.`,
          type: 'community',
        });
        fetchAuditLogs();
        return { success: true, message: data.message };
      } else {
        if (data.platform) {
          setPlatforms(prev => prev.map(p => (p.id === id ? { ...p, ...data.platform } : p)));
        }
        addNotification({
          title: 'Sync Warning',
          message: data.error || 'Sync could not reach server API.',
          type: 'community',
        });
        fetchAuditLogs();
        return { success: false, error: data.error };
      }
    } catch (err: any) {
      return { success: false, error: err?.message || 'Sync network request failed.' };
    } finally {
      setIsSyncingPlatform(false);
    }
  };

  const syncAllPlatforms = async (): Promise<boolean> => {
    setIsSyncingPlatform(true);
    try {
      const res = await fetch('/api/admin/platforms/sync-all', {
        method: 'POST',
        headers: getAuthHeaders(false),
      });
      const data = await res.json();
      if (res.ok && data.platforms) {
        setPlatforms(data.platforms);
        triggerConfetti();
        addNotification({
          title: 'All Platforms Synchronized',
          message: 'Bulk live data sync completed for all active platforms.',
          type: 'community',
        });
        fetchAuditLogs();
        return true;
      }
      return false;
    } catch {
      return false;
    } finally {
      setIsSyncingPlatform(false);
    }
  };

  // Games Actions
  const addGame = (game: Omit<Game, 'id'>) => {
    const newGame: Game = {
      ...game,
      id: `game-${Date.now()}`,
    };
    setGames(prev => [...prev, newGame]);
    addNotification({
      title: 'Game Added',
      message: `${game.title} added to games directory.`,
      type: 'community',
    });
  };

  const updateGame = (id: string, updates: Partial<Game>) => {
    setGames(prev => prev.map(g => (g.id === id ? { ...g, ...updates } : g)));
    addNotification({
      title: 'Game Updated',
      message: 'Game page and styling updated.',
      type: 'community',
    });
  };

  const deleteGame = (id: string) => {
    setGames(prev => prev.filter(g => g.id !== id));
  };

  // Community Posts
  const addPost = async (postData: {
    gameTag: string;
    content: string;
    images?: string[];
    poll?: { question: string; options: string[] };
  }) => {
    if (!currentUser) {
      setAuthModalOpen(true);
      return;
    }

    try {
      const res = await fetch('/api/posts', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(postData),
      });
      if (res.ok) {
        fetchPosts();
        triggerConfetti();
        addNotification({
          title: 'Post Published',
          message: 'Your update is now live on the Sultan Gaming community feed.',
          type: 'community',
        });
        return;
      }
    } catch {
      // Local fallback
    }

    const newPost: CommunityPost = {
      id: `post-${Date.now()}`,
      author: {
        name: currentUser.displayName,
        avatar: currentUser.avatar,
        level: currentUser.level,
        badge: currentUser.role === 'SUPER_ADMIN' ? 'Owner' : currentUser.role === 'ADMIN' ? 'Moderator' : undefined,
        verified: currentUser.verified,
        isOwner: currentUser.role === 'SUPER_ADMIN',
      },
      timestamp: 'Just now',
      gameTag: postData.gameTag,
      content: postData.content,
      images: postData.images,
      likes: 0,
      commentsCount: 0,
      userLiked: false,
      poll: postData.poll
        ? {
            question: postData.poll.question,
            options: postData.poll.options.map((opt, i) => ({
              id: `opt-${Date.now()}-${i}`,
              text: opt,
              votes: 0,
            })),
            totalVotes: 0,
          }
        : undefined,
    };

    setPosts(prev => [newPost, ...prev]);
    triggerConfetti();
  };

  const toggleLikePost = async (postId: string) => {
    if (!currentUser) {
      setAuthModalOpen(true);
      return;
    }

    try {
      const res = await fetch(`/api/posts/${postId}/like`, { method: 'POST' });
      if (res.ok) {
        const data = await res.json();
        setPosts(prev =>
          prev.map(p => {
            if (p.id === postId) {
              return {
                ...p,
                userLiked: data.userLiked,
                likes: data.totalLikes,
              };
            }
            return p;
          })
        );
        return;
      }
    } catch {
      // Local fallback
    }

    setPosts(prev =>
      prev.map(p => {
        if (p.id === postId) {
          const isLiked = p.userLiked;
          return {
            ...p,
            userLiked: !isLiked,
            likes: isLiked ? Math.max(0, p.likes - 1) : p.likes + 1,
          };
        }
        return p;
      })
    );
  };

  const votePoll = async (postId: string, optionId: string) => {
    if (!currentUser) {
      setAuthModalOpen(true);
      return;
    }

    try {
      const res = await fetch(`/api/posts/${postId}/vote`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ optionId }),
      });
      if (res.ok) {
        const data = await res.json();
        setPosts(prev =>
          prev.map(p => {
            if (p.id === postId && data.poll) {
              return {
                ...p,
                poll: {
                  ...data.poll,
                  userVotedOptionId: data.userVotedOptionId,
                },
              };
            }
            return p;
          })
        );
        return;
      }
    } catch {
      // Local fallback
    }

    setPosts(prev =>
      prev.map(p => {
        if (p.id === postId && p.poll && !p.poll.userVotedOptionId) {
          return {
            ...p,
            poll: {
              ...p.poll,
              totalVotes: p.poll.totalVotes + 1,
              userVotedOptionId: optionId,
              options: p.poll.options.map(opt => (opt.id === optionId ? { ...opt, votes: opt.votes + 1 } : opt)),
            },
          };
        }
        return p;
      })
    );
  };

  const deletePost = async (postId: string) => {
    try {
      const res = await fetch(`/api/posts/${postId}`, { method: 'DELETE' });
      if (res.ok) {
        setPosts(prev => prev.filter(p => p.id !== postId));
        addNotification({
          title: 'Post Removed',
          message: 'Post deleted from community feed.',
          type: 'community',
        });
        return;
      }
    } catch {
      // Local fallback
    }
    setPosts(prev => prev.filter(p => p.id !== postId));
  };

  const reportPost = async (postId: string, reason: string) => {
    if (!currentUser) {
      setAuthModalOpen(true);
      return false;
    }

    try {
      const res = await fetch(`/api/posts/${postId}/report`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ reason }),
      });
      if (res.ok) {
        addNotification({
          title: 'Report Submitted',
          message: 'Our moderation team will review this post.',
          type: 'community',
        });
        return true;
      }
    } catch {
      // Local fallback
    }

    addNotification({
      title: 'Report Submitted',
      message: 'Thank you for reporting. Post flagged for moderation.',
      type: 'community',
    });
    return true;
  };

  // PC Specs
  const addPCSpec = (spec: Omit<PCSpecItem, 'id'>) => {
    const newSpec: PCSpecItem = {
      ...spec,
      id: `spec-${Date.now()}`,
    };
    setPcSpecs(prev => [...prev, newSpec]);
    addNotification({
      title: 'PC Spec Item Added',
      message: `${spec.name} added to hardware inventory.`,
      type: 'community',
    });
  };

  const updatePCSpec = (id: string, updates: Partial<PCSpecItem>) => {
    setPcSpecs(prev => prev.map(s => (s.id === id ? { ...s, ...updates } : s)));
    addNotification({
      title: 'PC Spec Updated',
      message: 'Hardware component details saved.',
      type: 'community',
    });
  };

  const deletePCSpec = (id: string) => {
    setPcSpecs(prev => prev.filter(s => s.id !== id));
  };

  // Giveaways
  const addGiveaway = (giveaway: Omit<Giveaway, 'id'>) => {
    const newG: Giveaway = {
      ...giveaway,
      id: `giveaway-${Date.now()}`,
    };
    setGiveaways(prev => [newG, ...prev]);
    addNotification({
      title: 'Giveaway Created',
      message: `"${giveaway.title}" is now open for entries!`,
      type: 'giveaway',
      linkPage: 'giveaways',
    });
  };

  const updateGiveaway = (id: string, updates: Partial<Giveaway>) => {
    setGiveaways(prev => prev.map(g => (g.id === id ? { ...g, ...updates } : g)));
    addNotification({
      title: 'Giveaway Updated',
      message: 'Prize pool and schedule saved.',
      type: 'giveaway',
    });
  };

  const deleteGiveaway = (id: string) => {
    setGiveaways(prev => prev.filter(g => g.id !== id));
  };

  const enterGiveaway = async (giveawayId: string, email: string, gamertag: string): Promise<boolean> => {
    if (!currentUser) {
      setAuthModalOpen(true);
      return false;
    }

    try {
      const res = await fetch(`/api/giveaways/${giveawayId}/enter`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email, gamertag }),
      });
      if (res.ok) {
        triggerConfetti();
        fetchGiveaways();
        addNotification({
          title: 'Giveaway Entry Confirmed! 🎁',
          message: `You are entered into the draw. Winner will be announced on live stream!`,
          type: 'giveaway',
        });
        return true;
      }
    } catch {
      // Local fallback
    }

    setGiveaways(prev =>
      prev.map(g => {
        if (g.id === giveawayId) {
          return {
            ...g,
            entriesCount: g.entriesCount + 1,
            isEntered: true,
          };
        }
        return g;
      })
    );
    triggerConfetti();
    addNotification({
      title: 'Giveaway Entry Confirmed! 🎁',
      message: `You are entered into the draw. Best of luck, gamer!`,
      type: 'giveaway',
    });
    return true;
  };

  const drawGiveawayWinner = async (giveawayId: string) => {
    try {
      const res = await fetch(`/api/giveaways/${giveawayId}/draw-winner`, { method: 'POST' });
      if (res.ok) {
        const data = await res.json();
        if (data.giveaway) {
          setGiveaways(prev => prev.map(g => (g.id === giveawayId ? data.giveaway : g)));
        }
        triggerConfetti();
        addNotification({
          title: 'Winner Selected!',
          message: `Giveaway winner drawn: ${data.giveaway?.winnerName || 'Winner Selected'}`,
          type: 'giveaway',
        });
      }
    } catch {
      // Local fallback
      setGiveaways(prev =>
        prev.map(g => {
          if (g.id === giveawayId) {
            return {
              ...g,
              completed: true,
              winnerAnnounced: true,
              winnerName: 'Marcus_Vance (Level 12)',
            };
          }
          return g;
        })
      );
      triggerConfetti();
    }
  };

  // FAQs
  const addFAQ = (faq: Omit<FAQItem, 'id'>) => {
    const newFAQ: FAQItem = {
      ...faq,
      id: `faq-${Date.now()}`,
    };
    setFaqs(prev => [...prev, newFAQ]);
    addNotification({
      title: 'FAQ Added',
      message: 'Knowledge base question published.',
      type: 'community',
    });
  };

  const updateFAQ = (id: string, updates: Partial<FAQItem>) => {
    setFaqs(prev => prev.map(f => (f.id === id ? { ...f, ...updates } : f)));
  };

  const deleteFAQ = (id: string) => {
    setFaqs(prev => prev.filter(f => f.id !== id));
  };

  // Media Actions
  const addMedia = async (mediaItem: Omit<MediaItem, 'id' | 'createdAt'>) => {
    try {
      const res = await fetch('/api/admin/media', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(mediaItem),
      });
      if (res.ok) {
        const data = await res.json();
        if (data.media) {
          setMedia(prev => [data.media, ...prev]);
        }
      }
    } catch {
      const newItem: MediaItem = {
        ...mediaItem,
        id: `media-${Date.now()}`,
        createdAt: new Date().toISOString().split('T')[0],
      };
      setMedia(prev => [newItem, ...prev]);
    }
    addNotification({
      title: 'Media Uploaded',
      message: `${mediaItem.name} saved to asset library.`,
      type: 'community',
    });
  };

  const deleteMedia = async (id: string) => {
    try {
      await fetch(`/api/admin/media/${id}`, { method: 'DELETE' });
    } catch {
      // ignore
    }
    setMedia(prev => prev.filter(m => m.id !== id));
  };

  // YouTube / Videos
  const addVideo = (video: Omit<VideoItem, 'id'>) => {
    const newV: VideoItem = {
      ...video,
      id: `video-${Date.now()}`,
    };
    setVideos(prev => [newV, ...prev]);
    addNotification({
      title: 'New Video Uploaded',
      message: `"${video.title}" added to stream archive.`,
      type: 'youtube',
    });
  };

  const deleteVideo = (id: string) => {
    setVideos(prev => prev.filter(v => v.id !== id));
  };

  const syncYouTubeData = async (channelUrl: string): Promise<boolean> => {
    await new Promise(resolve => setTimeout(resolve, 1000));
    setPlatforms(prev =>
      prev.map(p => {
        if (p.type === 'youtube') {
          return {
            ...p,
            lastSynced: 'Just now',
            syncStatus: 'connected',
            followers: '1.45M',
            url: channelUrl || p.url,
          };
        }
        return p;
      })
    );
    triggerConfetti();
    addNotification({
      title: 'YouTube Feed Synced',
      message: 'Latest videos and playlist metadata updated.',
      type: 'youtube',
      linkPage: 'youtube',
    });
    return true;
  };

  // Notifications
  const unreadCount = notifications.filter(n => !n.read).length;

  const markNotificationAsRead = (id: string) => {
    setNotifications(prev => prev.map(n => (n.id === id ? { ...n, read: true } : n)));
  };

  const markAllNotificationsAsRead = () => {
    setNotifications(prev => prev.map(n => ({ ...n, read: true })));
  };

  const addNotification = (notif: Omit<NotificationItem, 'id' | 'time' | 'read'>) => {
    const newN: NotificationItem = {
      ...notif,
      id: `notif-${Date.now()}`,
      time: 'Just now',
      read: false,
    };
    setNotifications(prev => [newN, ...prev]);
  };

  // Helper to format file size
  const formatFileSize = (bytes: number): string => {
    if (!bytes || bytes === 0) return '0 B';
    const k = 1024;
    const sizes = ['B', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(1)) + ' ' + sizes[i];
  };

  // Fetch all users from Firestore
  const fetchFirestoreUsers = async (): Promise<FirestoreUserData[]> => {
    setIsLoadingFirestoreUsers(true);
    try {
      const usersRef = collection(db, 'users');
      const q = query(usersRef);
      const querySnapshot = await getDocs(q);
      const userList: FirestoreUserData[] = [];

      for (const docSnap of querySnapshot.docs) {
        const data = docSnap.data();
        const uid = docSnap.id;

        // Fetch user's files from subcollection users/{userId}/files
        let userFiles: UserUploadedFile[] = [];
        try {
          const filesRef = collection(db, 'users', uid, 'files');
          const filesSnap = await getDocs(query(filesRef));
          userFiles = filesSnap.docs.map(fDoc => ({
            id: fDoc.id,
            ...fDoc.data(),
          })) as UserUploadedFile[];
        } catch {
          // If files subcollection is empty
        }

        userList.push({
          id: uid,
          email: data.email || 'user@sultangaming.gg',
          displayName: data.displayName || 'Gamer',
          username: data.username || 'gamer',
          avatar: data.avatar || '',
          role: data.role || (uid === ADMIN_USER_ID ? 'SUPER_ADMIN' : 'USER'),
          status: data.status || 'ACTIVE',
          createdAt: data.createdAt || new Date().toISOString(),
          lastLoginAt: data.lastLoginAt,
          filesCount: userFiles.length || data.filesCount || 0,
          uploadedFiles: userFiles,
        });
      }

      // If Firestore collection is empty, populate demo seed data
      if (userList.length === 0) {
        const initialUsers: FirestoreUserData[] = [
          {
            id: ADMIN_USER_ID,
            email: 'samgaming2726@gmail.com',
            displayName: 'Admin (Sam Gaming)',
            username: 'admin_sam',
            avatar: 'https://images.unsplash.com/photo-1566492031773-4f4e44671857?w=150&auto=format&fit=crop&q=80',
            role: 'SUPER_ADMIN',
            status: 'ACTIVE',
            createdAt: '2024-01-01T00:00:00.000Z',
            filesCount: 3,
            uploadedFiles: [
              {
                id: 'file-admin-banner',
                name: 'channel_hero_banner_4k.webp',
                size: 2450000,
                sizeFormatted: '2.3 MB',
                type: 'image/webp',
                url: 'https://images.unsplash.com/photo-1542751371-adc38448a05e?w=1200&auto=format&fit=crop&q=80',
                createdAt: '2024-01-15T12:00:00.000Z',
                userId: ADMIN_USER_ID,
                uploaderEmail: 'samgaming2726@gmail.com',
                category: 'media',
              },
              {
                id: 'file-admin-logo',
                name: 'sultan_crown_emblem.png',
                size: 450000,
                sizeFormatted: '439 KB',
                type: 'image/png',
                url: 'https://images.unsplash.com/photo-1566492031773-4f4e44671857?w=400&auto=format&fit=crop&q=80',
                createdAt: '2024-01-10T10:30:00.000Z',
                userId: ADMIN_USER_ID,
                uploaderEmail: 'samgaming2726@gmail.com',
                category: 'avatar',
              },
              {
                id: 'file-admin-rules',
                name: 'sultan_community_guidelines.pdf',
                size: 1200000,
                sizeFormatted: '1.1 MB',
                type: 'application/pdf',
                url: 'https://www.w3.org/WAI/ER/tests/xhtml/testfiles/resources/pdf/dummy.pdf',
                createdAt: '2024-02-01T09:00:00.000Z',
                userId: ADMIN_USER_ID,
                uploaderEmail: 'samgaming2726@gmail.com',
                category: 'document',
              },
            ],
          },
          {
            id: 'user-valkyrie-99',
            email: 'valkyrie.gamer@sultangaming.gg',
            displayName: 'Valkyrie Queen',
            username: 'valkyrie_queen',
            avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150&auto=format&fit=crop&q=80',
            role: 'MODERATOR',
            status: 'ACTIVE',
            createdAt: '2024-02-14T15:20:00.000Z',
            filesCount: 2,
            uploadedFiles: [
              {
                id: 'file-valk-screenshot',
                name: 'palworld_base_raid_victory.png',
                size: 3100000,
                sizeFormatted: '2.9 MB',
                type: 'image/png',
                url: 'https://images.unsplash.com/photo-1511512578047-dfb367046420?w=1200&auto=format&fit=crop&q=80',
                createdAt: '2024-02-15T18:00:00.000Z',
                userId: 'user-valkyrie-99',
                uploaderEmail: 'valkyrie.gamer@sultangaming.gg',
                category: 'post',
              },
              {
                id: 'file-valk-avatar',
                name: 'custom_avatar_cyberpunk.jpg',
                size: 850000,
                sizeFormatted: '830 KB',
                type: 'image/jpeg',
                url: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=400&auto=format&fit=crop&q=80',
                createdAt: '2024-02-14T15:30:00.000Z',
                userId: 'user-valkyrie-99',
                uploaderEmail: 'valkyrie.gamer@sultangaming.gg',
                category: 'avatar',
              },
            ],
          },
          {
            id: 'user-shadow-gta',
            email: 'shadow_gtav@sultangaming.gg',
            displayName: 'Shadow Runner',
            username: 'shadow_gtav',
            avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150&auto=format&fit=crop&q=80',
            role: 'USER',
            status: 'ACTIVE',
            createdAt: '2024-03-01T11:45:00.000Z',
            filesCount: 1,
            uploadedFiles: [
              {
                id: 'file-shadow-car',
                name: 'gta_v_drift_truffade_custom.webp',
                size: 1800000,
                sizeFormatted: '1.7 MB',
                type: 'image/webp',
                url: 'https://images.unsplash.com/photo-1552519507-da3b142c6e3d?w=1200&auto=format&fit=crop&q=80',
                createdAt: '2024-03-02T14:10:00.000Z',
                userId: 'user-shadow-gta',
                uploaderEmail: 'shadow_gtav@sultangaming.gg',
                category: 'media',
              },
            ],
          },
        ];

        // Seed to Firestore in background
        for (const u of initialUsers) {
          try {
            await setDoc(doc(db, 'users', u.id), {
              id: u.id,
              email: u.email,
              displayName: u.displayName,
              username: u.username,
              avatar: u.avatar,
              role: u.role,
              status: u.status,
              createdAt: u.createdAt,
              filesCount: u.filesCount,
            }, { merge: true });

            for (const f of u.uploadedFiles || []) {
              await setDoc(doc(db, 'users', u.id, 'files', f.id), f, { merge: true });
            }
          } catch {
            // Ignore if write restricted
          }
        }

        setFirestoreUsers(initialUsers);
        return initialUsers;
      }

      setFirestoreUsers(userList);
      return userList;
    } catch (err) {
      handleFirestoreError(err, OperationType.LIST, 'users');
      return [];
    } finally {
      setIsLoadingFirestoreUsers(false);
    }
  };

  // Fetch files for a specific user from subcollection users/{userId}/files
  const fetchUserUploadedFiles = async (userId: string): Promise<UserUploadedFile[]> => {
    try {
      const filesRef = collection(db, 'users', userId, 'files');
      const snap = await getDocs(query(filesRef));
      const files = snap.docs.map(d => ({
        id: d.id,
        ...d.data(),
      })) as UserUploadedFile[];

      if (files.length === 0) {
        const cachedUser = firestoreUsers.find(u => u.id === userId);
        if (cachedUser && cachedUser.uploadedFiles && cachedUser.uploadedFiles.length > 0) {
          return cachedUser.uploadedFiles;
        }
      }
      return files;
    } catch (err) {
      handleFirestoreError(err, OperationType.GET, `users/${userId}/files`);
      const cached = firestoreUsers.find(u => u.id === userId);
      return cached?.uploadedFiles || [];
    }
  };

  // Upload user file to Firestore
  const uploadUserFile = async (
    file: File,
    category: UserUploadedFile['category'] = 'media'
  ): Promise<{ success: boolean; file?: UserUploadedFile; error?: string }> => {
    if (!currentUser) {
      setAuthModalOpen(true);
      return { success: false, error: 'Please sign in to upload files.' };
    }

    try {
      const dataUrl = await new Promise<string>((resolve, reject) => {
        const reader = new FileReader();
        reader.onload = () => resolve(reader.result as string);
        reader.onerror = reject;
        reader.readAsDataURL(file);
      });

      const fileId = `file-${Date.now()}-${Math.random().toString(36).substring(2, 7)}`;
      const newFile: UserUploadedFile = {
        id: fileId,
        name: file.name,
        size: file.size,
        sizeFormatted: formatFileSize(file.size),
        type: file.type || 'application/octet-stream',
        url: dataUrl,
        createdAt: new Date().toISOString(),
        userId: currentUser.id,
        uploaderEmail: currentUser.email,
        category: category,
      };

      // Save file metadata to subcollection users/{userId}/files/{fileId}
      const fileDocRef = doc(db, 'users', currentUser.id, 'files', fileId);
      await setDoc(fileDocRef, newFile);

      // Update user's files count in user document
      const userDocRef = doc(db, 'users', currentUser.id);
      await setDoc(
        userDocRef,
        {
          filesCount: (currentUser.filesCount || 0) + 1,
          lastLoginAt: new Date().toISOString(),
        },
        { merge: true }
      );

      // Update state locally
      setFirestoreUsers(prev =>
        prev.map(u => {
          if (u.id === currentUser.id) {
            const currentFiles = u.uploadedFiles || [];
            return {
              ...u,
              filesCount: (u.filesCount || 0) + 1,
              uploadedFiles: [newFile, ...currentFiles],
            };
          }
          return u;
        })
      );

      addNotification({
        title: 'File Uploaded Successfully',
        message: `"${file.name}" was saved to your Firestore storage.`,
        type: 'community',
      });
      triggerConfetti();

      return { success: true, file: newFile };
    } catch (err: any) {
      handleFirestoreError(err, OperationType.CREATE, `users/${currentUser.id}/files`);
      return { success: false, error: err?.message || 'Error uploading file.' };
    }
  };

  // Delete user file from Firestore
  const deleteUserUploadedFile = async (
    userId: string,
    fileId: string
  ): Promise<{ success: boolean; error?: string }> => {
    try {
      const fileDocRef = doc(db, 'users', userId, 'files', fileId);
      await deleteDoc(fileDocRef);

      setFirestoreUsers(prev =>
        prev.map(u => {
          if (u.id === userId) {
            return {
              ...u,
              filesCount: Math.max(0, (u.filesCount || 1) - 1),
              uploadedFiles: (u.uploadedFiles || []).filter(f => f.id !== fileId),
            };
          }
          return u;
        })
      );

      addNotification({
        title: 'File Deleted',
        message: 'File removed from Firestore storage.',
        type: 'community',
      });

      return { success: true };
    } catch (err: any) {
      handleFirestoreError(err, OperationType.DELETE, `users/${userId}/files/${fileId}`);
      return { success: false, error: err?.message || 'Error deleting file.' };
    }
  };

  // Simulate or Switch to Admin Login (UID: uJsvp8pMWGa6MDzkfasq2eBlaun1)
  const simulateAdminLogin = async (): Promise<void> => {
    const adminUser: User = {
      id: ADMIN_USER_ID,
      email: 'samgaming2726@gmail.com',
      displayName: 'Admin (Sam Gaming)',
      username: 'admin_sam',
      avatar: 'https://images.unsplash.com/photo-1566492031773-4f4e44671857?w=150&auto=format&fit=crop&q=80',
      bio: 'Sultan Gaming Root Administrator & Community Director',
      role: 'SUPER_ADMIN',
      status: 'ACTIVE',
      verified: true,
      level: 99,
      xp: 999999,
      postsCount: 24,
      commentsCount: 350,
      giveawaysEnteredCount: 0,
      createdAt: '2024-01-01T00:00:00.000Z',
      lastLoginAt: new Date().toISOString(),
      filesCount: 3,
    };

    setCurrentUser(adminUser);
    localStorage.setItem(`${STORAGE_KEY}_user`, JSON.stringify(adminUser));
    await syncUserDocToFirestore(adminUser);
    await fetchFirestoreUsers();
    setCurrentPageState('dashboard');
    triggerConfetti();
    addNotification({
      title: 'Admin View Activated',
      message: `Logged in as Admin UID: ${ADMIN_USER_ID}`,
      type: 'community',
    });
  };

  const resetToDefaults = () => {
    setSettings(INITIAL_SETTINGS);
    setHeroSlides(INITIAL_HERO_SLIDES);
    setPlatforms(INITIAL_PLATFORMS);
    setGames(INITIAL_GAMES);
    setPosts(INITIAL_COMMUNITY_POSTS);
    setPcSpecs(INITIAL_PC_SPECS);
    setGiveaways(INITIAL_GIVEAWAYS);
    setFaqs(INITIAL_FAQS);
    setVideos(INITIAL_VIDEOS);
    setPlaylists(INITIAL_PLAYLISTS);
    setNotifications(INITIAL_NOTIFICATIONS);
    setMedia(INITIAL_MEDIA);
    localStorage.clear();
    triggerConfetti();
    addNotification({
      title: 'Database Reset',
      message: 'All settings and content restored to initial factory defaults.',
      type: 'community',
    });
  };

  return (
    <StoreContext.Provider
      value={{
        currentPage,
        setCurrentPage,
        sidebarCollapsed,
        toggleSidebar,
        mobileMenuOpen,
        setMobileMenuOpen,
        isSearchOpen,
        setIsSearchOpen,
        isAdmin,
        setIsAdmin,
        openSearch,
        closeSearch,

        currentUser,
        isAuthenticated,
        userRole,
        isSuperAdmin,
        isModerator,
        hasRole,
        authModalOpen,
        setAuthModalOpen,
        profileModalOpen,
        setProfileModalOpen,
        signInWithEmail,
        signUpWithEmail,
        signInWithGoogle,
        resendVerificationEmail,
        loginWithGoogle,
        devSwitchRole,
        logout,
        updateUserProfile,
        deleteAccount,

        settings,
        updateSettings,
        heroSlides,
        addHeroSlide,
        updateHeroSlide,
        deleteHeroSlide,
        platforms,
        fetchPlatforms,
        uploadLogo,
        uploadImage,
        addPlatform,
        updatePlatform,
        deletePlatform,
        togglePlatformActive,
        reorderPlatforms,
        syncPlatform,
        syncAllPlatforms,
        isSyncingPlatform,
        games,
        addGame,
        updateGame,
        deleteGame,
        posts,
        addPost,
        toggleLikePost,
        votePoll,
        deletePost,
        reportPost,
        pcSpecs,
        addPCSpec,
        updatePCSpec,
        deletePCSpec,
        giveaways,
        addGiveaway,
        updateGiveaway,
        deleteGiveaway,
        enterGiveaway,
        drawGiveawayWinner,
        faqs,
        addFAQ,
        updateFAQ,
        deleteFAQ,
        media,
        addMedia,
        deleteMedia,

        allUsers,
        auditLogs,
        reports,
        fetchAllUsers,
        fetchAuditLogs,
        fetchReports,
        updateUserRole,
        updateUserStatus,
        resolveReport,

        // Firestore Users & Files Management
        firestoreUsers,
        isLoadingFirestoreUsers,
        fetchFirestoreUsers,
        fetchUserUploadedFiles,
        uploadUserFile,
        deleteUserUploadedFile,
        simulateAdminLogin,

        videos,
        playlists,
        addVideo,
        deleteVideo,
        syncYouTubeData,
        discordChannels,
        discordEvents,
        instagramPosts,
        instagramStories,
        notifications,
        unreadCount,
        markNotificationAsRead,
        markAllNotificationsAsRead,
        addNotification,
        resetToDefaults,
        triggerConfetti,
      }}
    >
      {children}
    </StoreContext.Provider>
  );
};

export const useStore = () => {
  const context = useContext(StoreContext);
  if (!context) {
    throw new Error('useStore must be used within a StoreProvider');
  }
  return context;
};
