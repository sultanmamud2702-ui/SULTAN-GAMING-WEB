import React, { useState } from 'react';
import {
  Instagram,
  Heart,
  MessageCircle,
  ExternalLink,
  Sparkles,
  CheckCircle2,
  X,
  Play,
} from 'lucide-react';
import { useStore } from '../context/StoreContext';
import { InstagramPost, InstagramStory } from '../types';

export const InstagramPage: React.FC = () => {
  const { instagramPosts, instagramStories, triggerConfetti } = useStore();
  const [activeStoryModal, setActiveStoryModal] = useState<InstagramStory | null>(null);
  const [activePostModal, setActivePostModal] = useState<InstagramPost | null>(null);

  return (
    <div className="space-y-8 animate-in fade-in duration-300">
      {/* INSTAGRAM PROFILE HEADER BANNER */}
      <div className="relative rounded-3xl overflow-hidden bg-[#041426] border border-[#E1306C]/40 shadow-2xl p-6 sm:p-8">
        <div className="absolute top-0 right-0 w-96 h-96 bg-gradient-to-tr from-[#FD1D1D]/15 to-[#833AB4]/15 rounded-full blur-3xl pointer-events-none" />

        <div className="relative z-10 flex flex-col md:flex-row md:items-center justify-between gap-6">
          <div className="flex items-center gap-5">
            {/* Gradient Avatar Ring */}
            <div className="w-20 h-20 sm:w-24 sm:h-24 rounded-full p-1 bg-gradient-to-tr from-[#FD1D1D] via-[#E1306C] to-[#833AB4] flex-shrink-0">
              <div className="w-full h-full rounded-full bg-black overflow-hidden p-0.5">
                <img
                  src="https://images.unsplash.com/photo-1566492031773-4f4e44671857?auto=format&fit=crop&w=200&q=80"
                  alt="Sultan Gaming"
                  className="w-full h-full rounded-full object-cover"
                />
              </div>
            </div>

            <div>
              <div className="flex items-center gap-2">
                <h1 className="text-xl sm:text-2xl font-black text-white font-['Space_Grotesk']">
                  sultangaming
                </h1>
                <CheckCircle2 className="w-5 h-5 text-[#008CFF] fill-current text-white" />
              </div>

              {/* Stats Bar */}
              <div className="flex items-center gap-4 text-xs text-[#B8C7D9] my-2">
                <span>
                  <strong className="text-white font-bold">{instagramPosts.length}</strong> posts
                </span>
                <span>
                  <strong className="text-white font-bold">40.2K</strong> followers
                </span>
                <span>
                  <strong className="text-white font-bold">184</strong> following
                </span>
              </div>

              <p className="text-xs text-white/80 max-w-md">
                🎮 Sultan Gaming Official • Daily GTA & Minecraft setups, stream clips, luxury giveaways & Los Santos RP vibes.
              </p>
            </div>
          </div>

          <a
            href="https://instagram.com"
            target="_blank"
            rel="noreferrer"
            onClick={triggerConfetti}
            className="flex items-center gap-2 px-6 py-2.5 rounded-full bg-gradient-to-tr from-[#FD1D1D] via-[#E1306C] to-[#833AB4] text-white font-bold text-xs sm:text-sm tracking-wide shadow-lg hover:scale-105 active:scale-95 transition-all self-start md:self-auto"
          >
            <Instagram className="w-4 h-4" />
            <span>Follow on Instagram</span>
            <ExternalLink className="w-3.5 h-3.5" />
          </a>
        </div>
      </div>

      {/* INSTAGRAM STORIES HIGHLIGHTS */}
      <div className="space-y-3">
        <h3 className="text-xs font-bold uppercase tracking-wider text-[#E1306C] font-['Space_Grotesk']">
          Story Highlights
        </h3>

        <div className="flex items-center gap-5 overflow-x-auto pb-2 scrollbar-none">
          {instagramStories.map(story => (
            <div
              key={story.id}
              onClick={() => setActiveStoryModal(story)}
              className="flex flex-col items-center gap-2 cursor-pointer group flex-shrink-0"
            >
              <div className="w-16 h-16 sm:w-18 sm:h-18 rounded-full p-0.5 bg-gradient-to-tr from-[#FD1D1D] via-[#E1306C] to-[#833AB4] group-hover:scale-105 transition-transform">
                <div className="w-full h-full rounded-full bg-black p-0.5 overflow-hidden">
                  <img src={story.icon} alt={story.title} className="w-full h-full rounded-full object-cover" />
                </div>
              </div>
              <span className="text-[11px] font-medium text-white/80 group-hover:text-white truncate max-w-[72px]">
                {story.title}
              </span>
            </div>
          ))}
        </div>
      </div>

      {/* 3-COLUMN PHOTOS & REELS GRID */}
      <div className="space-y-3">
        <h3 className="text-xs font-bold uppercase tracking-wider text-white font-['Space_Grotesk']">
          Posts & Clips
        </h3>

        <div className="grid grid-cols-2 sm:grid-cols-3 gap-3 sm:gap-4">
          {instagramPosts.map(post => (
            <div
              key={post.id}
              onClick={() => setActivePostModal(post)}
              className="relative aspect-square rounded-2xl overflow-hidden bg-black/60 border border-white/10 cursor-pointer group"
            >
              <img
                src={post.image}
                alt={post.caption}
                className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
              />

              {/* Hover overlay with likes and comments */}
              <div className="absolute inset-0 bg-black/60 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center gap-4 text-white">
                <div className="flex items-center gap-1 font-bold text-xs">
                  <Heart className="w-4 h-4 fill-current text-[#FD1D1D]" />
                  <span>{post.likes}</span>
                </div>
                <div className="flex items-center gap-1 font-bold text-xs">
                  <MessageCircle className="w-4 h-4 fill-current" />
                  <span>{post.comments}</span>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* STORY VIEWER MODAL */}
      {activeStoryModal && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/90 backdrop-blur-md"
          onClick={() => setActiveStoryModal(null)}
        >
          <div
            className="relative w-full max-w-sm rounded-3xl bg-[#061B2E] border border-white/20 overflow-hidden shadow-2xl p-4 space-y-4"
            onClick={e => e.stopPropagation()}
          >
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <img src={activeStoryModal.icon} alt="" className="w-6 h-6 rounded-full object-cover" />
                <span className="text-xs font-bold text-white">{activeStoryModal.title}</span>
              </div>
              <button onClick={() => setActiveStoryModal(null)} className="text-white/60 hover:text-white">
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="relative aspect-[9/16] rounded-2xl overflow-hidden bg-black">
              <img src={activeStoryModal.image} alt="" className="w-full h-full object-cover" />
              <div className="absolute bottom-4 left-4 right-4 p-3 rounded-xl bg-black/60 backdrop-blur-md text-xs text-white">
                Sultan Gaming • Story Highlight
              </div>
            </div>
          </div>
        </div>
      )}

      {/* POST VIEWER MODAL */}
      {activePostModal && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/90 backdrop-blur-md"
          onClick={() => setActivePostModal(null)}
        >
          <div
            className="w-full max-w-2xl rounded-3xl bg-[#061B2E] border border-white/20 overflow-hidden shadow-2xl flex flex-col sm:flex-row"
            onClick={e => e.stopPropagation()}
          >
            <div className="sm:w-1/2 bg-black aspect-square">
              <img src={activePostModal.image} alt="" className="w-full h-full object-cover" />
            </div>

            <div className="sm:w-1/2 p-5 flex flex-col justify-between space-y-4">
              <div className="space-y-3">
                <div className="flex items-center justify-between border-b border-white/10 pb-3">
                  <div className="flex items-center gap-2">
                    <img
                      src="https://images.unsplash.com/photo-1566492031773-4f4e44671857?auto=format&fit=crop&w=200&q=80"
                      alt=""
                      className="w-7 h-7 rounded-full object-cover"
                    />
                    <span className="text-xs font-bold text-white">sultangaming</span>
                  </div>
                  <button onClick={() => setActivePostModal(null)} className="text-white/50 hover:text-white">
                    <X className="w-4 h-4" />
                  </button>
                </div>

                <p className="text-xs text-[#EAF4FF] leading-relaxed">{activePostModal.caption}</p>
              </div>

              <div className="pt-3 border-t border-white/10 space-y-2">
                <div className="flex items-center gap-4 text-xs text-white">
                  <span className="flex items-center gap-1 font-bold">
                    <Heart className="w-4 h-4 text-[#FD1D1D] fill-current" />
                    {activePostModal.likes} likes
                  </span>
                  <span className="flex items-center gap-1 font-bold">
                    <MessageCircle className="w-4 h-4 text-white" />
                    {activePostModal.comments} comments
                  </span>
                </div>
                <p className="text-[10px] text-white/40">{activePostModal.date}</p>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
