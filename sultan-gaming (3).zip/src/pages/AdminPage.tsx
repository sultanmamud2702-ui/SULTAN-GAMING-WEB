import React, { useState, useEffect } from 'react';
import {
  ShieldCheck,
  Sliders,
  Image as ImageIcon,
  Gamepad2,
  Radio,
  Gift,
  Laptop,
  HelpCircle,
  Users,
  Plus,
  Trash2,
  Edit2,
  Check,
  RotateCcw,
  Sparkles,
  ExternalLink,
  Save,
  Eye,
  RefreshCw,
  UserCheck,
  AlertTriangle,
  FileText,
  Lock,
  Crown,
  Ban,
  UserX,
  Search,
  CheckCircle,
  Clock,
  Activity,
  ArrowUp,
  ArrowDown,
  Info,
  Globe,
  Power,
  Layers,
  Sparkle,
  Upload,
} from 'lucide-react';
import { useStore } from '../context/StoreContext';
import {
  HeroSlide,
  Game,
  Platform,
  PlatformType,
  Giveaway,
  PCSpecItem,
  FAQItem,
  MediaItem,
  UserRole,
  UserStatus,
} from '../types';

export const AdminPage: React.FC = () => {
  const {
    settings,
    updateSettings,
    heroSlides,
    addHeroSlide,
    updateHeroSlide,
    deleteHeroSlide,
    games,
    addGame,
    updateGame,
    deleteGame,
    platforms,
    uploadLogo,
    addPlatform,
    updatePlatform,
    deletePlatform,
    togglePlatformActive,
    reorderPlatforms,
    syncPlatform,
    syncAllPlatforms,
    isSyncingPlatform,
    giveaways,
    addGiveaway,
    updateGiveaway,
    deleteGiveaway,
    drawGiveawayWinner,
    pcSpecs,
    addPCSpec,
    updatePCSpec,
    deletePCSpec,
    faqs,
    addFAQ,
    updateFAQ,
    deleteFAQ,
    posts,
    deletePost,
    media,
    addMedia,
    deleteMedia,
    allUsers,
    auditLogs,
    reports,
    fetchAllUsers,
    fetchAuditLogs,
    fetchReports,
    updateUserRole,
    updateUserStatus,
    resolveReport,
    resetToDefaults,
    triggerConfetti,
    setCurrentPage,
    currentUser,
    isSuperAdmin,
  } = useStore();

  const [activeTab, setActiveTab] = useState<
    | 'overview'
    | 'users'
    | 'reports'
    | 'audit'
    | 'settings'
    | 'hero'
    | 'games'
    | 'platforms'
    | 'giveaways'
    | 'specs'
    | 'faq'
    | 'community'
    | 'media'
  >('overview');

  const [savedSuccess, setSavedSuccess] = useState(false);
  const [userSearch, setUserSearch] = useState('');
  const [auditSearch, setAuditSearch] = useState('');

  // Fetch admin data on mount
  useEffect(() => {
    fetchAllUsers();
    fetchAuditLogs();
    fetchReports();
  }, [fetchAllUsers, fetchAuditLogs, fetchReports]);

  // Settings Local Form State
  const [settingsForm, setSettingsForm] = useState(settings);

  // Modal / Form state for Hero Slide
  const [heroForm, setHeroForm] = useState<Omit<HeroSlide, 'id'>>({
    category: 'GTA 5 Online',
    title: 'LOS SANTOS',
    titleHighlight: 'NEVER STOPS',
    description: 'Missions. Races. Heists. Live with Viewers. Only on Sultan Gaming.',
    bgImage: 'https://images.unsplash.com/photo-1542751371-adc38448a05e?auto=format&fit=crop&w=1600&q=80',
    primaryBtnText: 'Watch Live',
    primaryBtnUrl: 'kick',
    secondaryBtnText: 'View Game',
    secondaryBtnUrl: 'game-gta-5-online',
    active: true,
    order: 1,
  });
  const [showHeroModal, setShowHeroModal] = useState(false);
  const [editingHeroId, setEditingHeroId] = useState<string | null>(null);

  // Modal / Form state for Game
  const [gameForm, setGameForm] = useState<Omit<Game, 'id'>>({
    title: '',
    slug: '',
    color: '#FF7A00',
    coverImage: 'https://images.unsplash.com/photo-1542751371-adc38448a05e?auto=format&fit=crop&w=600&q=80',
    platform: 'PC / PS5 / Xbox Series X',
    releaseYear: '2025',
    order: 1,
    genre: 'Action & Adventure',
    banner: 'https://images.unsplash.com/photo-1542751371-adc38448a05e?auto=format&fit=crop&w=1200&q=80',
    logo: 'https://images.unsplash.com/photo-1566492031773-4f4e44671857?auto=format&fit=crop&w=200&q=80',
    shortDescription: 'Open-world gameplay & multiplayer.',
    description: 'Detailed description of gameplay, viewer sessions, and guides.',
    tags: ['Multiplayer', 'Live Streams', '4K'],
    featured: true,
  });
  const [showGameModal, setShowGameModal] = useState(false);
  const [editingGameId, setEditingGameId] = useState<string | null>(null);

  // Modal / Form state for Giveaway
  const [giveawayForm, setGiveawayForm] = useState<Omit<Giveaway, 'id'>>({
    title: '',
    edition: 'Official Edition',
    description: '',
    prizeValue: '$5,000 Value',
    endDate: '2026-10-31',
    entriesCount: 1500,
    banner: 'https://images.unsplash.com/photo-1587202372775-e229f172b9d7?auto=format&fit=crop&w=1200&q=80',
    mainPrizeImage: 'https://images.unsplash.com/photo-1587202372775-e229f172b9d7?auto=format&fit=crop&w=1000&q=80',
    prizeImages: [],
    prizeFeatures: [],
    completed: false,
    terms: ['Open to international viewers 18+', 'Must follow Sultan Gaming on YouTube & Kick'],
  });
  const [showGiveawayModal, setShowGiveawayModal] = useState(false);
  const [editingGiveawayId, setEditingGiveawayId] = useState<string | null>(null);

  // Modal / Form state for FAQ
  const [faqForm, setFaqForm] = useState<Omit<FAQItem, 'id'>>({
    question: '',
    answer: '',
    category: 'general',
    icon: 'help',
    order: faqs.length + 1,
  });
  const [showFaqModal, setShowFaqModal] = useState(false);
  const [editingFaqId, setEditingFaqId] = useState<string | null>(null);

  // Media Library Form State
  const [mediaTitle, setMediaTitle] = useState('');
  const [mediaUrl, setMediaUrl] = useState('');
  const [mediaType, setMediaType] = useState<'banner' | 'game' | 'hardware' | 'giveaway' | 'avatar' | 'post'>('banner');

  // Platform Form & Detail States
  const [platformForm, setPlatformForm] = useState<Partial<Platform>>({
    name: '',
    url: '',
    type: 'youtube',
    platformType: 'youtube',
    logo: 'https://cdn-icons-png.flaticon.com/512/1384/1384060.png',
    banner: 'https://images.unsplash.com/photo-1511512578047-dfb367046420?auto=format&fit=crop&w=1600&q=80',
    followers: '0',
    followersNum: 0,
    accentColor: '#FF0000',
    glowColor: 'rgba(255, 0, 0, 0.4)',
    description: '',
    isActive: true,
    verified: true,
    featured: false,
  });
  const [showPlatformModal, setShowPlatformModal] = useState(false);
  const [editingPlatformId, setEditingPlatformId] = useState<string | null>(null);
  const [selectedPlatformDetails, setSelectedPlatformDetails] = useState<Platform | null>(null);
  const [showPlatformDetailsModal, setShowPlatformDetailsModal] = useState(false);
  const [platformFilter, setPlatformFilter] = useState('');
  const [platformSyncingId, setPlatformSyncingId] = useState<string | null>(null);
  const [platformSaving, setPlatformSaving] = useState(false);
  const [platformError, setPlatformError] = useState<string | null>(null);
  const [platformLogoFile, setPlatformLogoFile] = useState<File | null>(null);
  const [platformLogoPreview, setPlatformLogoPreview] = useState<string | null>(null);

  const handleSavePlatform = async () => {
    setPlatformError(null);
    if (!platformForm.name || !platformForm.name.trim()) {
      setPlatformError('Platform Display Name is required.');
      return;
    }
    if (!platformForm.url || !platformForm.url.trim()) {
      setPlatformError('Platform URL is required.');
      return;
    }

    try {
      const parsed = new URL(platformForm.url.trim());
      if (!['http:', 'https:'].includes(parsed.protocol)) {
        setPlatformError('Please enter a valid web URL starting with http:// or https://');
        return;
      }
    } catch {
      setPlatformError('Please enter a valid URL (e.g. https://youtube.com/@SultanGaming)');
      return;
    }

    setPlatformSaving(true);
    try {
      let finalLogo = platformForm.logo;

      if (platformLogoPreview && platformLogoPreview.startsWith('data:')) {
        const uploadRes = await uploadLogo(platformLogoPreview, platformLogoFile?.name || 'platform-logo.png');
        if (uploadRes.success && uploadRes.url) {
          finalLogo = uploadRes.url;
        } else if (uploadRes.error) {
          setPlatformError(`Logo upload error: ${uploadRes.error}`);
          setPlatformSaving(false);
          return;
        }
      }

      const payload: Partial<Platform> = {
        ...platformForm,
        name: platformForm.name.trim(),
        url: platformForm.url.trim(),
        logo: finalLogo || platformForm.logo || 'https://cdn-icons-png.flaticon.com/512/3670/3670157.png',
        followers: platformForm.followers?.trim() || '0',
        followersNum: Number(platformForm.followersNum) || (parseInt(platformForm.followers?.replace(/[^0-9]/g, '') || '0', 10)),
        type: platformForm.type || 'youtube',
        platformType: platformForm.platformType || platformForm.type || 'youtube',
        accentColor: platformForm.accentColor || '#008CFF',
        glowColor: platformForm.glowColor || `${platformForm.accentColor || '#008CFF'}66`,
        isActive: platformForm.isActive !== false,
        verified: platformForm.verified !== false,
        featured: platformForm.featured === true,
      };

      if (editingPlatformId) {
        const result = await updatePlatform(editingPlatformId, payload);
        if (!result.success) {
          setPlatformError(result.error || 'Failed to update platform in database.');
          setPlatformSaving(false);
          return;
        }
      } else {
        const result = await addPlatform(payload);
        if (!result.success) {
          setPlatformError(result.error || 'Failed to create platform in database.');
          setPlatformSaving(false);
          return;
        }
      }

      setShowPlatformModal(false);
      setPlatformLogoFile(null);
      setPlatformLogoPreview(null);
      setPlatformError(null);
      flashSave();
    } catch (err: any) {
      setPlatformError(err?.message || 'Failed to save platform.');
    } finally {
      setPlatformSaving(false);
    }
  };

  const autoDetectPlatformInfo = (url: string) => {
    const lower = url.toLowerCase();
    let type: PlatformType = 'custom';
    let name = '';
    let accentColor = '#008CFF';
    let glowColor = 'rgba(0, 140, 255, 0.4)';
    let logo = 'https://cdn-icons-png.flaticon.com/512/3670/3670157.png';

    if (lower.includes('youtube.com') || lower.includes('youtu.be')) {
      type = 'youtube';
      name = 'YouTube';
      accentColor = '#FF0000';
      glowColor = 'rgba(255, 0, 0, 0.4)';
      logo = 'https://cdn-icons-png.flaticon.com/512/1384/1384060.png';
    } else if (lower.includes('kick.com')) {
      type = 'kick';
      name = 'KICK Live';
      accentColor = '#53FC18';
      glowColor = 'rgba(83, 252, 24, 0.4)';
      logo = 'https://assets.streamlinehq.com/image/private/w_300,h_300,ar_1:1,c_fill,f_auto/v1/icons/all-logos/kick-logo-vector-d4h7uawbvd98qvyg2l4o9.png';
    } else if (lower.includes('discord.gg') || lower.includes('discord.com')) {
      type = 'discord';
      name = 'Discord';
      accentColor = '#5865F2';
      glowColor = 'rgba(88, 101, 242, 0.4)';
      logo = 'https://cdn-icons-png.flaticon.com/512/3670/3670157.png';
    } else if (lower.includes('instagram.com')) {
      type = 'instagram';
      name = 'Instagram';
      accentColor = '#E4405F';
      glowColor = 'rgba(228, 64, 95, 0.4)';
      logo = 'https://cdn-icons-png.flaticon.com/512/174/174855.png';
    } else if (lower.includes('twitch.tv')) {
      type = 'twitch';
      name = 'Twitch';
      accentColor = '#9146FF';
      glowColor = 'rgba(145, 70, 255, 0.4)';
      logo = 'https://cdn-icons-png.flaticon.com/512/5968/5968819.png';
    } else if (lower.includes('tiktok.com')) {
      type = 'tiktok';
      name = 'TikTok';
      accentColor = '#00F2FE';
      glowColor = 'rgba(0, 242, 254, 0.4)';
      logo = 'https://cdn-icons-png.flaticon.com/512/3046/3046121.png';
    } else if (lower.includes('twitter.com') || lower.includes('x.com')) {
      type = 'twitter';
      name = 'X / Twitter';
      accentColor = '#1DA1F2';
      glowColor = 'rgba(29, 161, 242, 0.4)';
      logo = 'https://cdn-icons-png.flaticon.com/512/5969/5969020.png';
    }

    return { type, name, accentColor, glowColor, logo };
  };

  const flashSave = () => {
    setSavedSuccess(true);
    triggerConfetti();
    setTimeout(() => setSavedSuccess(false), 2500);
  };

  const handleSaveSettings = (e: React.FormEvent) => {
    e.preventDefault();
    updateSettings(settingsForm);
    flashSave();
  };

  const filteredUsers = allUsers.filter(
    u =>
      u.displayName.toLowerCase().includes(userSearch.toLowerCase()) ||
      u.email.toLowerCase().includes(userSearch.toLowerCase()) ||
      u.username.toLowerCase().includes(userSearch.toLowerCase())
  );

  const filteredLogs = auditLogs.filter(
    l =>
      l.action.toLowerCase().includes(auditSearch.toLowerCase()) ||
      l.details.toLowerCase().includes(auditSearch.toLowerCase()) ||
      l.adminName.toLowerCase().includes(auditSearch.toLowerCase())
  );

  return (
    <div className="space-y-8 animate-in fade-in duration-300">
      {/* CMS TOP HEADER */}
      <div className="relative rounded-3xl overflow-hidden bg-gradient-to-r from-[#041426] via-[#061B2E] to-[#020817] border border-[#FF7A00]/40 p-6 sm:p-8 shadow-2xl">
        <div className="absolute top-0 right-0 w-96 h-96 bg-[#FF7A00]/10 rounded-full blur-3xl pointer-events-none" />

        <div className="relative z-10 flex flex-col md:flex-row md:items-center justify-between gap-5">
          <div className="space-y-1">
            <div className="flex items-center gap-2 text-[#FF9500] text-xs font-bold uppercase tracking-wider">
              <ShieldCheck className="w-4 h-4" />
              <span>SULTAN GAMING ADMIN CMS & SECURITY STUDIO</span>
            </div>
            <h1 className="text-3xl sm:text-4xl font-black uppercase text-white font-['Space_Grotesk'] tracking-tight">
              Control & RBAC Dashboard
            </h1>
            <p className="text-xs sm:text-sm text-[#B8C7D9]">
              Server-enforced access control, community moderation, audit logs, giveaways, and site management.
            </p>
          </div>

          <div className="flex items-center gap-2 self-start md:self-auto">
            <button
              onClick={() => {
                if (confirm('Are you sure you want to reset all CMS content to original default data?')) {
                  resetToDefaults();
                }
              }}
              className="flex items-center gap-1.5 px-4 py-2 rounded-full bg-white/5 hover:bg-white/10 border border-white/10 text-white/70 hover:text-white text-xs font-semibold transition-all"
            >
              <RotateCcw className="w-3.5 h-3.5" />
              <span>Reset Defaults</span>
            </button>

            <button
              onClick={() => setCurrentPage('home')}
              className="flex items-center gap-1.5 px-5 py-2 rounded-full bg-[#008CFF] hover:bg-[#00B7FF] text-white text-xs font-bold transition-all shadow-md"
            >
              <Eye className="w-3.5 h-3.5" />
              <span>View Live Site</span>
            </button>
          </div>
        </div>
      </div>

      {savedSuccess && (
        <div className="p-3 rounded-2xl bg-[#53FC18]/20 border border-[#53FC18] text-[#53FC18] text-xs font-bold flex items-center justify-center gap-2 animate-in fade-in">
          <Check className="w-4 h-4" />
          <span>Changes successfully saved and synchronized across the server!</span>
        </div>
      )}

      {/* CMS NAVIGATION TABS */}
      <div className="flex items-center gap-2 overflow-x-auto pb-2 scrollbar-none">
        {[
          { id: 'overview', label: 'Dashboard Overview', icon: <Sliders className="w-3.5 h-3.5" /> },
          { id: 'users', label: `Users & RBAC (${allUsers.length || 3})`, icon: <UserCheck className="w-3.5 h-3.5 text-[#FF7A00]" /> },
          { id: 'reports', label: `Reports (${reports.filter(r => r.status === 'pending').length} New)`, icon: <AlertTriangle className="w-3.5 h-3.5 text-[#FFB000]" /> },
          { id: 'audit', label: `Audit Logs (${auditLogs.length})`, icon: <FileText className="w-3.5 h-3.5 text-[#00B7FF]" /> },
          { id: 'settings', label: 'Branding & Slogan', icon: <Sparkles className="w-3.5 h-3.5" /> },
          { id: 'hero', label: `Hero Slides (${heroSlides.length})`, icon: <ImageIcon className="w-3.5 h-3.5" /> },
          { id: 'games', label: `Games Catalog (${games.length})`, icon: <Gamepad2 className="w-3.5 h-3.5" /> },
          { id: 'platforms', label: `Platforms (${platforms.length})`, icon: <Radio className="w-3.5 h-3.5" /> },
          { id: 'giveaways', label: `Giveaways (${giveaways.length})`, icon: <Gift className="w-3.5 h-3.5" /> },
          { id: 'specs', label: `PC Specs (${pcSpecs.length})`, icon: <Laptop className="w-3.5 h-3.5" /> },
          { id: 'faq', label: `FAQ Items (${faqs.length})`, icon: <HelpCircle className="w-3.5 h-3.5" /> },
          { id: 'community', label: `Community Posts (${posts.length})`, icon: <Users className="w-3.5 h-3.5" /> },
          { id: 'media', label: `Media Library (${media.length})`, icon: <ImageIcon className="w-3.5 h-3.5" /> },
        ].map(tab => (
          <button
            key={tab.id}
            onClick={() => setActiveTab(tab.id as any)}
            className={`flex items-center gap-2 px-4 py-2.5 rounded-full text-xs font-bold tracking-wide whitespace-nowrap transition-all ${
              activeTab === tab.id
                ? 'bg-gradient-to-r from-[#FF7A00] to-[#FF9500] text-white shadow-[0_0_15px_rgba(255,122,0,0.4)]'
                : 'bg-[#041426]/80 text-[#B8C7D9] hover:text-white hover:bg-white/10 border border-white/10'
            }`}
          >
            {tab.icon}
            <span>{tab.label}</span>
          </button>
        ))}
      </div>

      {/* TAB 1: OVERVIEW METRICS */}
      {activeTab === 'overview' && (
        <div className="space-y-6">
          <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-4">
            {[
              { label: 'Total Registered Users', val: allUsers.length || 3, sub: 'Server-authenticated accounts', color: 'text-[#FF7A00]' },
              { label: 'Security Audit Logs', val: auditLogs.length, sub: 'Admin actions recorded', color: 'text-[#00B7FF]' },
              { label: 'Pending Reports', val: reports.filter(r => r.status === 'pending').length, sub: 'Needs mod review', color: 'text-[#FFB000]' },
              { label: 'Featured Games', val: games.length, sub: 'Active in catalog', color: 'text-[#53FC18]' },
              { label: 'Hero Slides', val: heroSlides.length, sub: 'Rotating banner', color: 'text-[#FF9500]' },
              { label: 'Active Giveaways', val: giveaways.filter(g => !g.completed).length, sub: 'Open for registration', color: 'text-[#5865F2]' },
              { label: 'Community Posts', val: posts.length, sub: 'User discussions', color: 'text-[#E1306C]' },
              { label: 'Media Assets', val: media.length, sub: 'Stored images', color: 'text-[#008CFF]' },
            ].map(card => (
              <div
                key={card.label}
                className="p-5 rounded-2xl bg-[#041426]/85 border border-white/10 backdrop-blur-xl space-y-1 shadow-lg"
              >
                <span className="text-xs text-[#B8C7D9] font-medium">{card.label}</span>
                <p className={`text-3xl font-black font-['Space_Grotesk'] ${card.color}`}>
                  {card.val}
                </p>
                <span className="text-[11px] text-white/40 block">{card.sub}</span>
              </div>
            ))}
          </div>

          {/* Quick Actions Panel */}
          <div className="p-6 rounded-3xl bg-[#041426]/80 border border-white/10 backdrop-blur-xl space-y-4">
            <h3 className="text-sm font-bold uppercase tracking-wider text-white font-['Space_Grotesk'] flex items-center justify-between">
              <span>Quick Management Shortcuts</span>
              <button
                onClick={() => setCurrentPage('dashboard')}
                className="text-xs text-[#FF7A00] hover:text-[#FF9500] font-bold flex items-center gap-1.5"
              >
                <span>Go to User Files & Admin Dashboard</span>
                <ExternalLink className="w-3.5 h-3.5" />
              </button>
            </h3>
            <div className="grid grid-cols-1 sm:grid-cols-4 gap-3">
              <button
                onClick={() => setCurrentPage('dashboard')}
                className="p-3.5 rounded-xl bg-gradient-to-br from-[#FF7A00]/20 to-[#FF9500]/10 hover:bg-[#FF7A00]/30 border border-[#FF7A00]/40 text-left text-xs font-semibold text-white flex items-center justify-between"
              >
                <div>
                  <span className="block font-bold text-[#FF9500]">Firestore Admin View</span>
                  <span className="text-[10px] text-[#B8C7D9]">View all users & inspect uploaded files</span>
                </div>
                <ShieldCheck className="w-5 h-5 text-[#FF7A00]" />
              </button>

              <button
                onClick={() => setActiveTab('users')}
                className="p-3.5 rounded-xl bg-white/5 hover:bg-white/10 border border-white/10 text-left text-xs font-semibold text-white flex items-center justify-between"
              >
                <div>
                  <span className="block font-bold">Manage Users & Roles</span>
                  <span className="text-[10px] text-[#B8C7D9]">Assign Admin / Super Admin roles</span>
                </div>
                <UserCheck className="w-5 h-5 text-[#FF7A00]" />
              </button>

              <button
                onClick={() => setActiveTab('reports')}
                className="p-3.5 rounded-xl bg-white/5 hover:bg-white/10 border border-white/10 text-left text-xs font-semibold text-white flex items-center justify-between"
              >
                <div>
                  <span className="block font-bold">Review Flagged Reports</span>
                  <span className="text-[10px] text-[#B8C7D9]">Moderate spam or toxic posts</span>
                </div>
                <AlertTriangle className="w-5 h-5 text-[#FFB000]" />
              </button>

              <button
                onClick={() => setActiveTab('audit')}
                className="p-3.5 rounded-xl bg-white/5 hover:bg-white/10 border border-white/10 text-left text-xs font-semibold text-white flex items-center justify-between"
              >
                <div>
                  <span className="block font-bold">Security Audit Trail</span>
                  <span className="text-[10px] text-[#B8C7D9]">Inspect actions & timestamps</span>
                </div>
                <FileText className="w-5 h-5 text-[#00B7FF]" />
              </button>
            </div>
          </div>
        </div>
      )}

      {/* TAB: USERS & RBAC ROLES */}
      {activeTab === 'users' && (
        <div className="space-y-4">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
            <div>
              <h3 className="text-base font-bold text-white uppercase font-['Space_Grotesk']">
                User Management & Access Control (RBAC)
              </h3>
              <p className="text-xs text-[#B8C7D9]">
                Assign roles (USER, ADMIN, SUPER_ADMIN) and enforce account suspensions.
              </p>
            </div>

            <div className="relative w-full sm:w-64">
              <Search className="w-4 h-4 text-white/40 absolute left-3 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                placeholder="Search users..."
                value={userSearch}
                onChange={e => setUserSearch(e.target.value)}
                className="w-full pl-9 pr-3 py-2 rounded-xl bg-[#041426] border border-white/15 text-xs text-white placeholder-white/30 focus:outline-none focus:border-[#FF7A00]"
              />
            </div>
          </div>

          <div className="space-y-3">
            {filteredUsers.length === 0 ? (
              <div className="p-8 text-center bg-[#041426]/80 rounded-2xl text-xs text-[#B8C7D9]">
                No users found matching search.
              </div>
            ) : (
              filteredUsers.map(user => (
                <div
                  key={user.id}
                  className="p-4 rounded-2xl bg-[#041426]/85 border border-white/10 backdrop-blur-xl flex flex-col md:flex-row md:items-center justify-between gap-4"
                >
                  <div className="flex items-center gap-3">
                    <img
                      src={user.avatar}
                      alt={user.displayName}
                      className="w-12 h-12 rounded-2xl object-cover border border-white/15"
                    />
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="font-bold text-sm text-white">{user.displayName}</span>
                        <span className="text-xs text-[#B8C7D9] font-mono">@{user.username}</span>
                        {user.verified && (
                          <span className="w-3.5 h-3.5 rounded-full bg-[#00B7FF] flex items-center justify-center text-white text-[8px] font-bold">
                            ✓
                          </span>
                        )}
                      </div>
                      <p className="text-xs text-white/60">{user.email}</p>
                      <div className="flex items-center gap-2 mt-1">
                        <span
                          className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${
                            user.role === 'SUPER_ADMIN'
                              ? 'bg-[#FF7A00]/20 text-[#FF9500] border border-[#FF7A00]/30'
                              : user.role === 'ADMIN'
                              ? 'bg-[#008CFF]/20 text-[#00B7FF] border border-[#008CFF]/30'
                              : 'bg-white/10 text-white/80'
                          }`}
                        >
                          {user.role}
                        </span>
                        <span
                          className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${
                            user.status === 'ACTIVE'
                              ? 'bg-[#53FC18]/20 text-[#53FC18]'
                              : 'bg-red-500/20 text-red-400'
                          }`}
                        >
                          {user.status}
                        </span>
                        <span className="text-[10px] text-white/40">Level {user.level} • {user.postsCount} Posts</span>
                      </div>
                    </div>
                  </div>

                  {/* Actions for User */}
                  <div className="flex flex-wrap items-center gap-2 pt-2 md:pt-0 border-t md:border-t-0 border-white/10">
                    {isSuperAdmin && (
                      <div className="flex items-center gap-1 bg-white/5 p-1 rounded-xl border border-white/10">
                        <span className="text-[10px] text-white/50 px-1 font-semibold">Role:</span>
                        <button
                          onClick={() => updateUserRole(user.id, 'USER')}
                          className={`px-2 py-1 rounded-lg text-[10px] font-bold transition-colors ${
                            user.role === 'USER' ? 'bg-white/20 text-white' : 'text-white/60 hover:text-white'
                          }`}
                        >
                          USER
                        </button>
                        <button
                          onClick={() => updateUserRole(user.id, 'ADMIN')}
                          className={`px-2 py-1 rounded-lg text-[10px] font-bold transition-colors ${
                            user.role === 'ADMIN' ? 'bg-[#008CFF] text-white' : 'text-white/60 hover:text-white'
                          }`}
                        >
                          ADMIN
                        </button>
                        <button
                          onClick={() => updateUserRole(user.id, 'SUPER_ADMIN')}
                          className={`px-2 py-1 rounded-lg text-[10px] font-bold transition-colors ${
                            user.role === 'SUPER_ADMIN' ? 'bg-[#FF7A00] text-white' : 'text-white/60 hover:text-white'
                          }`}
                        >
                          SUPER ADMIN
                        </button>
                      </div>
                    )}

                    {user.role !== 'SUPER_ADMIN' && (
                      <button
                        onClick={() =>
                          updateUserStatus(
                            user.id,
                            user.status === 'ACTIVE' ? 'BANNED' : 'ACTIVE',
                            'Moderator action via Admin Panel'
                          )
                        }
                        className={`px-3 py-1.5 rounded-xl text-xs font-semibold flex items-center gap-1.5 transition-colors ${
                          user.status === 'ACTIVE'
                            ? 'bg-red-500/10 hover:bg-red-500/20 text-red-400 border border-red-500/20'
                            : 'bg-[#53FC18]/10 hover:bg-[#53FC18]/20 text-[#53FC18] border border-[#53FC18]/20'
                        }`}
                      >
                        <Ban className="w-3.5 h-3.5" />
                        <span>{user.status === 'ACTIVE' ? 'Ban User' : 'Unban'}</span>
                      </button>
                    )}
                  </div>
                </div>
              ))
            )}
          </div>
        </div>
      )}

      {/* TAB: MODERATION & REPORTS */}
      {activeTab === 'reports' && (
        <div className="space-y-4">
          <div>
            <h3 className="text-base font-bold text-white uppercase font-['Space_Grotesk']">
              Flagged Content & User Reports ({reports.length})
            </h3>
            <p className="text-xs text-[#B8C7D9]">
              Community reports submitted by members for moderation review.
            </p>
          </div>

          <div className="space-y-3">
            {reports.length === 0 ? (
              <div className="p-8 text-center bg-[#041426]/80 rounded-2xl text-xs text-[#B8C7D9]">
                No reports submitted. All clear!
              </div>
            ) : (
              reports.map(report => (
                <div
                  key={report.id}
                  className="p-5 rounded-2xl bg-[#041426]/85 border border-white/10 backdrop-blur-xl space-y-3"
                >
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-[#FFB000]/20 text-[#FFB000]">
                        {report.targetType.toUpperCase()} REPORT
                      </span>
                      <span className="text-xs font-semibold text-white">Reported by {report.reporterName}</span>
                    </div>
                    <span
                      className={`px-2.5 py-0.5 rounded-full text-[10px] font-bold ${
                        report.status === 'pending'
                          ? 'bg-[#FF7A00]/20 text-[#FF7A00] border border-[#FF7A00]/30 animate-pulse'
                          : 'bg-[#53FC18]/20 text-[#53FC18]'
                      }`}
                    >
                      {report.status.toUpperCase()}
                    </span>
                  </div>

                  <div className="p-3 rounded-xl bg-white/5 border border-white/10 space-y-1">
                    <span className="text-[10px] text-white/40 block">Snippet / Target Content:</span>
                    <p className="text-xs text-white italic">"{report.targetSnippet || report.targetId}"</p>
                  </div>

                  <div>
                    <span className="text-[11px] text-[#B8C7D9] font-medium block">Reason for flag:</span>
                    <p className="text-xs text-red-300">{report.reason}</p>
                  </div>

                  {report.actionTaken && (
                    <div className="text-[11px] text-[#53FC18]">
                      ✓ {report.actionTaken} (by {report.resolvedBy || 'Moderator'})
                    </div>
                  )}

                  {report.status === 'pending' && (
                    <div className="flex items-center justify-end gap-2 pt-2 border-t border-white/10">
                      <button
                        onClick={() => resolveReport(report.id, 'dismissed', 'Dismissed: No violation found')}
                        className="px-3 py-1.5 rounded-xl bg-white/10 text-white text-xs font-semibold hover:bg-white/15"
                      >
                        Dismiss Report
                      </button>
                      <button
                        onClick={() => {
                          if (report.targetType === 'post') {
                            deletePost(report.targetId);
                          }
                          resolveReport(report.id, 'resolved', 'Post removed and reporter notified.');
                        }}
                        className="px-4 py-1.5 rounded-xl bg-gradient-to-r from-red-600 to-red-700 text-white text-xs font-bold hover:shadow-lg"
                      >
                        Remove Content & Resolve
                      </button>
                    </div>
                  )}
                </div>
              ))
            )}
          </div>
        </div>
      )}

      {/* TAB: SECURITY AUDIT LOGS */}
      {activeTab === 'audit' && (
        <div className="space-y-4">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
            <div>
              <h3 className="text-base font-bold text-white uppercase font-['Space_Grotesk']">
                Security Audit Logs & Admin Activity
              </h3>
              <p className="text-xs text-[#B8C7D9]">
                Server-side tamper-resistant record of all administrative and moderation events.
              </p>
            </div>

            <div className="relative w-full sm:w-64">
              <Search className="w-4 h-4 text-white/40 absolute left-3 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                placeholder="Search audit logs..."
                value={auditSearch}
                onChange={e => setAuditSearch(e.target.value)}
                className="w-full pl-9 pr-3 py-2 rounded-xl bg-[#041426] border border-white/15 text-xs text-white placeholder-white/30 focus:outline-none focus:border-[#FF7A00]"
              />
            </div>
          </div>

          <div className="space-y-2">
            {filteredLogs.map(log => (
              <div
                key={log.id}
                className="p-3.5 rounded-2xl bg-[#041426]/85 border border-white/10 backdrop-blur-xl flex flex-col sm:flex-row sm:items-center justify-between gap-3 font-mono text-xs"
              >
                <div className="space-y-0.5">
                  <div className="flex items-center gap-2">
                    <span className="px-2 py-0.5 rounded bg-white/10 text-[#00B7FF] font-bold text-[10px]">
                      {log.action}
                    </span>
                    <span className="text-white font-semibold font-sans">{log.adminName}</span>
                    <span className="text-[10px] text-white/40">({log.adminRole})</span>
                  </div>
                  <p className="text-xs text-[#EAF4FF] font-sans pt-0.5">{log.details}</p>
                </div>

                <div className="text-right flex-shrink-0 text-[10px] text-white/40 font-mono">
                  <span>{new Date(log.timestamp).toLocaleString()}</span>
                  <span className="block text-white/30">IP: {log.ipAddress || '127.0.0.1'}</span>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* TAB: BRANDING & SLOGAN SETTINGS */}
      {activeTab === 'settings' && (
        <form onSubmit={handleSaveSettings} className="p-6 sm:p-8 rounded-3xl bg-[#041426]/90 border border-white/10 backdrop-blur-xl shadow-xl space-y-6">
          <div className="border-b border-white/10 pb-4">
            <h3 className="text-base font-bold text-white uppercase font-['Space_Grotesk']">
              Brand Identity & Global Slogan
            </h3>
            <p className="text-xs text-[#B8C7D9]">
              Configure the brand name, tagline, description, and creator socials.
            </p>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-semibold text-[#B8C7D9] mb-1">Brand Name</label>
              <input
                type="text"
                value={settingsForm.brandName}
                onChange={e => setSettingsForm({ ...settingsForm, brandName: e.target.value })}
                className="w-full bg-white/5 border border-white/10 rounded-xl p-3 text-xs text-white focus:outline-none focus:border-[#FF7A00]"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-[#B8C7D9] mb-1">Global Tagline / Slogan</label>
              <input
                type="text"
                value={settingsForm.tagline}
                onChange={e => setSettingsForm({ ...settingsForm, tagline: e.target.value })}
                className="w-full bg-white/5 border border-white/10 rounded-xl p-3 text-xs text-white focus:outline-none focus:border-[#FF7A00]"
              />
            </div>
          </div>

          <div>
            <label className="block text-xs font-semibold text-[#B8C7D9] mb-1">Brand Bio / SEO Description</label>
            <textarea
              rows={3}
              value={settingsForm.description}
              onChange={e => setSettingsForm({ ...settingsForm, description: e.target.value })}
              className="w-full bg-white/5 border border-white/10 rounded-xl p-3 text-xs text-white focus:outline-none focus:border-[#FF7A00]"
            />
          </div>

          <div className="pt-2 border-t border-white/10 flex justify-end">
            <button
              type="submit"
              className="flex items-center gap-2 px-6 py-2.5 rounded-full bg-gradient-to-r from-[#FF7A00] to-[#FF9500] text-white font-bold text-xs tracking-wide shadow-lg hover:scale-105 active:scale-95 transition-all"
            >
              <Save className="w-4 h-4" />
              <span>Save Branding Settings</span>
            </button>
          </div>
        </form>
      )}

      {/* TAB: HERO SLIDER CMS */}
      {activeTab === 'hero' && (
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="text-base font-bold text-white uppercase font-['Space_Grotesk']">
              Hero Carousel Slides ({heroSlides.length})
            </h3>
            <button
              onClick={() => {
                setEditingHeroId(null);
                setHeroForm({
                  category: 'GTA 5 Online',
                  title: 'NEW ADVENTURE',
                  titleHighlight: 'STARTS NOW',
                  description: 'Watch daily stream highlights, community races, and multiplayer heists.',
                  bgImage: 'https://images.unsplash.com/photo-1542751371-adc38448a05e?auto=format&fit=crop&w=1600&q=80',
                  primaryBtnText: 'Watch Live',
                  primaryBtnUrl: 'kick',
                  secondaryBtnText: 'View Game',
                  secondaryBtnUrl: 'game-gta-5-online',
                  active: true,
                  order: heroSlides.length + 1,
                });
                setShowHeroModal(true);
              }}
              className="flex items-center gap-1.5 px-4 py-2 rounded-full bg-[#FF7A00] hover:bg-[#FF9500] text-white text-xs font-bold shadow-md transition-all"
            >
              <Plus className="w-3.5 h-3.5" />
              <span>Add Slide</span>
            </button>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            {heroSlides.map(slide => (
              <div
                key={slide.id}
                className="rounded-3xl bg-[#041426]/85 border border-white/10 p-4 backdrop-blur-xl space-y-3 relative overflow-hidden"
              >
                <div className="relative h-36 rounded-2xl overflow-hidden bg-black">
                  <img src={slide.bgImage} alt="" className="w-full h-full object-cover" />
                  <div className="absolute top-2 left-2 px-2.5 py-0.5 rounded-full text-[10px] font-bold uppercase bg-black/70 text-[#FF9500]">
                    {slide.category}
                  </div>
                </div>

                <div>
                  <h4 className="text-sm font-bold text-white">
                    {slide.title} <span className="text-[#FF9500]">{slide.titleHighlight}</span>
                  </h4>
                  <p className="text-xs text-[#B8C7D9] line-clamp-2 mt-0.5">{slide.description}</p>
                </div>

                <div className="flex items-center justify-between pt-2 border-t border-white/10">
                  <span className={`text-[11px] font-bold ${slide.active ? 'text-[#53FC18]' : 'text-white/40'}`}>
                    {slide.active ? '● Active in Carousel' : '○ Inactive'}
                  </span>

                  <div className="flex items-center gap-1.5">
                    <button
                      onClick={() => {
                        setEditingHeroId(slide.id);
                        setHeroForm({ ...slide });
                        setShowHeroModal(true);
                      }}
                      className="p-1.5 rounded-lg bg-white/5 hover:bg-white/10 text-white"
                      title="Edit"
                    >
                      <Edit2 className="w-3.5 h-3.5" />
                    </button>
                    <button
                      onClick={() => deleteHeroSlide(slide.id)}
                      className="p-1.5 rounded-lg bg-red-500/10 hover:bg-red-500/20 text-red-400"
                      title="Delete"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>

          {/* Hero Modal */}
          {showHeroModal && (
            <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md">
              <div className="w-full max-w-lg rounded-3xl bg-[#061B2E] border border-white/15 p-6 shadow-2xl space-y-4">
                <h3 className="text-lg font-bold text-white">
                  {editingHeroId ? 'Edit Hero Slide' : 'Add Hero Slide'}
                </h3>
                <div className="space-y-3">
                  <div>
                    <label className="block text-xs text-[#B8C7D9] mb-1">Slide Title</label>
                    <input
                      type="text"
                      value={heroForm.title}
                      onChange={e => setHeroForm({ ...heroForm, title: e.target.value })}
                      className="w-full bg-white/5 border border-white/10 rounded-xl p-2.5 text-xs text-white"
                    />
                  </div>
                  <div>
                    <label className="block text-xs text-[#B8C7D9] mb-1">Highlight Slogan Word</label>
                    <input
                      type="text"
                      value={heroForm.titleHighlight}
                      onChange={e => setHeroForm({ ...heroForm, titleHighlight: e.target.value })}
                      className="w-full bg-white/5 border border-white/10 rounded-xl p-2.5 text-xs text-white"
                    />
                  </div>
                  <div>
                    <label className="block text-xs text-[#B8C7D9] mb-1">Background Image URL</label>
                    <input
                      type="url"
                      value={heroForm.bgImage}
                      onChange={e => setHeroForm({ ...heroForm, bgImage: e.target.value })}
                      className="w-full bg-white/5 border border-white/10 rounded-xl p-2.5 text-xs text-white"
                    />
                  </div>
                  <div>
                    <label className="block text-xs text-[#B8C7D9] mb-1">Description</label>
                    <textarea
                      rows={2}
                      value={heroForm.description}
                      onChange={e => setHeroForm({ ...heroForm, description: e.target.value })}
                      className="w-full bg-white/5 border border-white/10 rounded-xl p-2.5 text-xs text-white"
                    />
                  </div>
                </div>

                <div className="flex items-center justify-end gap-2 pt-3 border-t border-white/10">
                  <button onClick={() => setShowHeroModal(false)} className="px-4 py-2 rounded-xl bg-white/5 text-xs text-white">
                    Cancel
                  </button>
                  <button
                    onClick={() => {
                      if (editingHeroId) {
                        updateHeroSlide(editingHeroId, heroForm);
                      } else {
                        addHeroSlide(heroForm);
                      }
                      setShowHeroModal(false);
                      flashSave();
                    }}
                    className="px-5 py-2 rounded-xl bg-[#FF7A00] text-xs font-bold text-white"
                  >
                    Save Slide
                  </button>
                </div>
              </div>
            </div>
          )}
        </div>
      )}

      {/* TAB: GAMES CATALOG */}
      {activeTab === 'games' && (
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="text-base font-bold text-white uppercase font-['Space_Grotesk']">
              Featured Games ({games.length})
            </h3>
            <button
              onClick={() => {
                setEditingGameId(null);
                setGameForm({
                  title: '',
                  slug: '',
                  genre: 'Action & Adventure',
                  color: '#FF7A00',
                  coverImage: 'https://images.unsplash.com/photo-1542751371-adc38448a05e?auto=format&fit=crop&w=600&q=80',
                  platform: 'PC / PS5 / Xbox Series X',
                  releaseYear: '2025',
                  order: games.length + 1,
                  banner: 'https://images.unsplash.com/photo-1542751371-adc38448a05e?auto=format&fit=crop&w=1200&q=80',
                  logo: 'https://images.unsplash.com/photo-1566492031773-4f4e44671857?auto=format&fit=crop&w=200&q=80',
                  shortDescription: 'Open-world gameplay & multiplayer.',
                  description: 'Detailed description of gameplay, viewer sessions, and guides.',
                  tags: ['Multiplayer', 'Live Streams', '4K'],
                  featured: true,
                });
                setShowGameModal(true);
              }}
              className="flex items-center gap-1.5 px-4 py-2 rounded-full bg-[#FF7A00] hover:bg-[#FF9500] text-white text-xs font-bold shadow-md transition-all"
            >
              <Plus className="w-3.5 h-3.5" />
              <span>Add Game</span>
            </button>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
            {games.map(game => (
              <div
                key={game.id}
                className="p-4 rounded-3xl bg-[#041426]/85 border border-white/10 backdrop-blur-xl space-y-3"
              >
                <div className="relative h-32 rounded-2xl overflow-hidden bg-black">
                  <img src={game.banner} alt={game.title} className="w-full h-full object-cover" />
                </div>
                <div>
                  <h4 className="font-bold text-white text-sm">{game.title}</h4>
                  <p className="text-xs text-[#B8C7D9] line-clamp-1">{game.genre}</p>
                </div>
                <div className="flex items-center justify-between pt-2 border-t border-white/10">
                  <span className="text-[10px] text-white/50">/{game.slug}</span>
                  <div className="flex items-center gap-1.5">
                    <button
                      onClick={() => {
                        setEditingGameId(game.id);
                        setGameForm({ ...game });
                        setShowGameModal(true);
                      }}
                      className="p-1.5 rounded-lg bg-white/5 hover:bg-white/10 text-white"
                    >
                      <Edit2 className="w-3.5 h-3.5" />
                    </button>
                    <button
                      onClick={() => deleteGame(game.id)}
                      className="p-1.5 rounded-lg bg-red-500/10 hover:bg-red-500/20 text-red-400"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>

          {showGameModal && (
            <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md">
              <div className="w-full max-w-lg rounded-3xl bg-[#061B2E] border border-white/15 p-6 shadow-2xl space-y-4">
                <h3 className="text-lg font-bold text-white">{editingGameId ? 'Edit Game' : 'Add Game'}</h3>
                <div className="space-y-3">
                  <div>
                    <label className="block text-xs text-[#B8C7D9] mb-1">Title</label>
                    <input
                      type="text"
                      value={gameForm.title}
                      onChange={e => setGameForm({ ...gameForm, title: e.target.value, slug: e.target.value.toLowerCase().replace(/[^a-z0-9]+/g, '-') })}
                      className="w-full bg-white/5 border border-white/10 rounded-xl p-2.5 text-xs text-white"
                    />
                  </div>
                  <div>
                    <label className="block text-xs text-[#B8C7D9] mb-1">Genre</label>
                    <input
                      type="text"
                      value={gameForm.genre}
                      onChange={e => setGameForm({ ...gameForm, genre: e.target.value })}
                      className="w-full bg-white/5 border border-white/10 rounded-xl p-2.5 text-xs text-white"
                    />
                  </div>
                  <div>
                    <label className="block text-xs text-[#B8C7D9] mb-1">Banner Image URL</label>
                    <input
                      type="url"
                      value={gameForm.banner}
                      onChange={e => setGameForm({ ...gameForm, banner: e.target.value })}
                      className="w-full bg-white/5 border border-white/10 rounded-xl p-2.5 text-xs text-white"
                    />
                  </div>
                </div>

                <div className="flex items-center justify-end gap-2 pt-3 border-t border-white/10">
                  <button onClick={() => setShowGameModal(false)} className="px-4 py-2 rounded-xl bg-white/5 text-xs text-white">
                    Cancel
                  </button>
                  <button
                    onClick={() => {
                      if (editingGameId) {
                        updateGame(editingGameId, gameForm);
                      } else {
                        addGame(gameForm);
                      }
                      setShowGameModal(false);
                      flashSave();
                    }}
                    className="px-5 py-2 rounded-xl bg-[#FF7A00] text-xs font-bold text-white"
                  >
                    Save Game
                  </button>
                </div>
              </div>
            </div>
          )}
        </div>
      )}

      {/* TAB: PLATFORMS */}
      {activeTab === 'platforms' && (
        <div className="space-y-6">
          {/* Platforms Header & Action Bar */}
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-[#041426]/80 p-5 rounded-3xl border border-white/10 backdrop-blur-xl">
            <div>
              <div className="flex items-center gap-2">
                <Radio className="w-5 h-5 text-[#FF7A00]" />
                <h3 className="text-base font-bold text-white uppercase font-['Space_Grotesk'] tracking-wider">
                  Connected Platforms ({platforms.length})
                </h3>
                <span className="px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-[#008CFF]/20 text-[#008CFF] border border-[#008CFF]/30">
                  Database-Driven
                </span>
              </div>
              <p className="text-xs text-[#B8C7D9] mt-1">
                Manage streaming links, social channels, and execute live API synchronization.
              </p>
            </div>

            <div className="flex flex-wrap items-center gap-2.5">
              <button
                onClick={async () => {
                  await syncAllPlatforms();
                  flashSave();
                }}
                disabled={isSyncingPlatform}
                className="flex items-center gap-2 px-4 py-2 rounded-2xl bg-gradient-to-r from-[#008CFF]/20 to-[#53FC18]/20 hover:from-[#008CFF]/30 hover:to-[#53FC18]/30 border border-[#008CFF]/40 text-white text-xs font-bold transition-all shadow-lg hover:shadow-[#008CFF]/20"
              >
                <RefreshCw className={`w-3.5 h-3.5 text-[#53FC18] ${isSyncingPlatform ? 'animate-spin' : ''}`} />
                <span>{isSyncingPlatform ? 'Syncing Platforms...' : 'Sync All Platforms'}</span>
              </button>

              <button
                onClick={() => {
                  setEditingPlatformId(null);
                  setPlatformForm({
                    name: '',
                    url: '',
                    type: 'youtube',
                    platformType: 'youtube',
                    logo: 'https://cdn-icons-png.flaticon.com/512/1384/1384060.png',
                    banner: 'https://images.unsplash.com/photo-1511512578047-dfb367046420?auto=format&fit=crop&w=1600&q=80',
                    followers: '0 Followers',
                    followersNum: 0,
                    accentColor: '#FF0000',
                    glowColor: 'rgba(255, 0, 0, 0.4)',
                    description: '',
                    isActive: true,
                    verified: true,
                    featured: false,
                  });
                  setShowPlatformModal(true);
                }}
                className="flex items-center gap-1.5 px-4 py-2 rounded-2xl bg-gradient-to-r from-[#FF7A00] to-[#FF9500] hover:from-[#FF9500] hover:to-[#FFAE00] text-white text-xs font-bold shadow-lg shadow-[#FF7A00]/25 transition-all"
              >
                <Plus className="w-4 h-4" />
                <span>Add Platform</span>
              </button>
            </div>
          </div>

          {/* Filter / Search Bar */}
          <div className="relative">
            <Search className="w-4 h-4 text-white/40 absolute left-4 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              placeholder="Search platforms by name, type, handle, or URL..."
              value={platformFilter}
              onChange={e => setPlatformFilter(e.target.value)}
              className="w-full bg-[#041426]/60 border border-white/10 rounded-2xl pl-11 pr-4 py-2.5 text-xs text-white placeholder-white/40 focus:outline-none focus:border-[#FF7A00]/60 transition-all"
            />
          </div>

          {/* Platforms Table & Card Grid */}
          <div className="space-y-3">
            {platforms
              .filter(p =>
                p.name.toLowerCase().includes(platformFilter.toLowerCase()) ||
                (p.type && p.type.toLowerCase().includes(platformFilter.toLowerCase())) ||
                p.url.toLowerCase().includes(platformFilter.toLowerCase())
              )
              .map((platform, index, arr) => {
                const isFirst = index === 0;
                const isLast = index === arr.length - 1;
                const isCurrentlySyncing = isSyncingPlatform && platformSyncingId === platform.id;

                return (
                  <div
                    key={platform.id}
                    className={`p-4 sm:p-5 rounded-3xl bg-[#041426]/85 border transition-all duration-200 backdrop-blur-xl flex flex-col lg:flex-row lg:items-center justify-between gap-4 ${
                      platform.isActive === false
                        ? 'border-white/5 opacity-60 bg-black/40'
                        : 'border-white/10 hover:border-white/20'
                    }`}
                  >
                    {/* Left: Reorder Controls + Platform Identity */}
                    <div className="flex items-center gap-3 min-w-0">
                      {/* Reorder Buttons */}
                      <div className="flex flex-col gap-1 items-center justify-center p-1 bg-white/5 rounded-xl border border-white/10 shrink-0">
                        <button
                          disabled={isFirst}
                          onClick={() => {
                            if (isFirst) return;
                            const newOrder = [...platforms];
                            const temp = newOrder[index];
                            newOrder[index] = newOrder[index - 1];
                            newOrder[index - 1] = temp;
                            reorderPlatforms(newOrder.map(p => p.id));
                          }}
                          className={`p-1 rounded hover:bg-white/10 text-white/70 hover:text-white transition-colors ${
                            isFirst ? 'opacity-20 cursor-not-allowed' : ''
                          }`}
                          title="Move Up"
                        >
                          <ArrowUp className="w-3.5 h-3.5" />
                        </button>
                        <span className="text-[9px] font-bold text-white/40">{index + 1}</span>
                        <button
                          disabled={isLast}
                          onClick={() => {
                            if (isLast) return;
                            const newOrder = [...platforms];
                            const temp = newOrder[index];
                            newOrder[index] = newOrder[index + 1];
                            newOrder[index + 1] = temp;
                            reorderPlatforms(newOrder.map(p => p.id));
                          }}
                          className={`p-1 rounded hover:bg-white/10 text-white/70 hover:text-white transition-colors ${
                            isLast ? 'opacity-20 cursor-not-allowed' : ''
                          }`}
                          title="Move Down"
                        >
                          <ArrowDown className="w-3.5 h-3.5" />
                        </button>
                      </div>

                      {/* Logo + Names */}
                      <div className="relative shrink-0">
                        <div
                          className="w-12 h-12 rounded-2xl flex items-center justify-center p-2.5 bg-black/50 border border-white/10 overflow-hidden shadow-inner"
                          style={{ borderColor: platform.accentColor ? `${platform.accentColor}40` : undefined }}
                        >
                          <img src={platform.logo} alt={platform.name} className="w-full h-full object-contain" />
                        </div>
                        {platform.liveStatus && (
                          <span className="absolute -top-1 -right-1 flex h-3 w-3">
                            <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-red-400 opacity-75"></span>
                            <span className="relative inline-flex rounded-full h-3 w-3 bg-red-500"></span>
                          </span>
                        )}
                      </div>

                      {/* Name & URL */}
                      <div className="min-w-0">
                        <div className="flex items-center gap-2 flex-wrap">
                          <h4 className="font-bold text-white text-sm tracking-wide flex items-center gap-1.5 truncate">
                            {platform.name}
                            {platform.verified !== false && (
                              <CheckCircle className="w-3.5 h-3.5 text-[#008CFF] shrink-0" />
                            )}
                          </h4>
                          <span
                            className="px-2 py-0.5 rounded-md text-[9px] font-extrabold uppercase tracking-wider"
                            style={{
                              backgroundColor: `${platform.accentColor || '#008CFF'}20`,
                              color: platform.accentColor || '#008CFF',
                              border: `1px solid ${platform.accentColor || '#008CFF'}40`,
                            }}
                          >
                            {platform.type || platform.platformType || 'Platform'}
                          </span>
                          {platform.liveStatus && (
                            <span className="px-2 py-0.5 rounded-md text-[9px] font-bold uppercase bg-red-500/20 text-red-400 border border-red-500/40 animate-pulse">
                              LIVE NOW ({platform.viewerCount?.toLocaleString() || 'Streaming'})
                            </span>
                          )}
                        </div>

                        <a
                          href={platform.url}
                          target="_blank"
                          rel="noreferrer"
                          className="text-[11px] text-[#B8C7D9] hover:text-[#FF7A00] flex items-center gap-1 transition-colors truncate mt-0.5 max-w-xs sm:max-w-md"
                        >
                          <span className="truncate">{platform.url}</span>
                          <ExternalLink className="w-3 h-3 shrink-0 opacity-60" />
                        </a>
                      </div>
                    </div>

                    {/* Middle: Follower Stats & Sync Engine Status */}
                    <div className="flex flex-wrap items-center gap-4 lg:gap-8 py-2 lg:py-0 border-y lg:border-y-0 border-white/5">
                      {/* Metric */}
                      <div>
                        <span className="text-[10px] text-white/40 uppercase font-bold block">Followers / Audience</span>
                        <div className="flex items-center gap-1.5 mt-0.5">
                          <span className="text-sm font-extrabold text-white font-['Space_Grotesk']">
                            {platform.followers || '0'}
                          </span>
                        </div>
                      </div>

                      {/* Active Status */}
                      <div>
                        <span className="text-[10px] text-white/40 uppercase font-bold block">Visibility</span>
                        <button
                          onClick={() => togglePlatformActive(platform.id)}
                          className={`mt-1 flex items-center gap-1.5 px-2.5 py-1 rounded-full text-[10px] font-bold transition-all ${
                            platform.isActive !== false
                              ? 'bg-[#53FC18]/15 text-[#53FC18] border border-[#53FC18]/30 hover:bg-[#53FC18]/25'
                              : 'bg-white/10 text-white/40 border border-white/10 hover:bg-white/15'
                          }`}
                        >
                          <Power className="w-3 h-3" />
                          <span>{platform.isActive !== false ? 'Active' : 'Disabled'}</span>
                        </button>
                      </div>

                      {/* Sync Status Badge */}
                      <div>
                        <span className="text-[10px] text-white/40 uppercase font-bold block">API Sync Status</span>
                        <div className="flex items-center gap-1.5 mt-1">
                          <span
                            className={`px-2.5 py-0.5 rounded-full text-[10px] font-bold flex items-center gap-1 ${
                              platform.syncStatus === 'SYNCED' || platform.syncStatus === 'connected'
                                ? 'bg-[#53FC18]/15 text-[#53FC18] border border-[#53FC18]/30'
                                : platform.syncStatus === 'SYNCING'
                                ? 'bg-[#008CFF]/20 text-[#008CFF] border border-[#008CFF]/30 animate-pulse'
                                : platform.syncStatus === 'SYNC_FAILED'
                                ? 'bg-[#FF7A00]/20 text-[#FF7A00] border border-[#FF7A00]/30'
                                : 'bg-white/10 text-white/50 border border-white/10'
                            }`}
                            title={platform.syncErrorMessage || platform.syncSource || 'Connected'}
                          >
                            <span className="w-1.5 h-1.5 rounded-full bg-current"></span>
                            <span>{platform.syncStatus || 'Connected'}</span>
                          </span>
                          <span className="text-[10px] text-white/40">
                            {platform.lastSynced || 'Recently'}
                          </span>
                        </div>
                      </div>
                    </div>

                    {/* Right: Actions (Details, Sync, Edit, Delete) */}
                    <div className="flex items-center gap-2 self-end lg:self-center shrink-0">
                      <button
                        onClick={() => {
                          setSelectedPlatformDetails(platform);
                          setShowPlatformDetailsModal(true);
                        }}
                        className="p-2 rounded-xl bg-white/5 hover:bg-white/10 text-white/80 hover:text-white border border-white/10 transition-colors"
                        title="View Live API Details"
                      >
                        <Info className="w-4 h-4 text-[#008CFF]" />
                      </button>

                      <button
                        onClick={async () => {
                          setPlatformSyncingId(platform.id);
                          await syncPlatform(platform.id);
                          setPlatformSyncingId(null);
                        }}
                        disabled={isSyncingPlatform}
                        className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-[#53FC18]/10 hover:bg-[#53FC18]/20 text-[#53FC18] border border-[#53FC18]/30 text-xs font-bold transition-all disabled:opacity-50"
                        title="Trigger Live API Sync"
                      >
                        <RefreshCw className={`w-3.5 h-3.5 ${isCurrentlySyncing ? 'animate-spin' : ''}`} />
                        <span>Sync</span>
                      </button>

                      <button
                        onClick={() => {
                          setEditingPlatformId(platform.id);
                          setPlatformForm({ ...platform });
                          setShowPlatformModal(true);
                        }}
                        className="p-2 rounded-xl bg-white/5 hover:bg-white/10 text-white/80 hover:text-white border border-white/10 transition-colors"
                        title="Edit Platform"
                      >
                        <Edit2 className="w-4 h-4 text-[#FF7A00]" />
                      </button>

                      <button
                        onClick={() => {
                          if (confirm(`Are you sure you want to delete platform "${platform.name}"?`)) {
                            deletePlatform(platform.id);
                          }
                        }}
                        className="p-2 rounded-xl bg-red-500/10 hover:bg-red-500/20 text-red-400 border border-red-500/20 transition-colors"
                        title="Delete Platform"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  </div>
                );
              })}
          </div>

          {/* ADD / EDIT PLATFORM MODAL */}
          {showPlatformModal && (
            <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md overflow-y-auto">
              <div className="w-full max-w-xl rounded-3xl bg-[#061B2E] border border-white/15 p-6 shadow-2xl space-y-5 my-8">
                <div className="flex items-center justify-between pb-3 border-b border-white/10">
                  <div className="flex items-center gap-2">
                    <Radio className="w-5 h-5 text-[#FF7A00]" />
                    <h3 className="text-lg font-bold text-white font-['Space_Grotesk']">
                      {editingPlatformId ? 'Edit Connected Platform' : 'Add New Platform'}
                    </h3>
                  </div>
                  <span className="text-xs text-[#53FC18] font-semibold flex items-center gap-1">
                    <span className="w-2 h-2 rounded-full bg-[#53FC18] animate-pulse"></span>
                    Persistent Database
                  </span>
                </div>

                {platformError && (
                  <div className="p-3.5 rounded-2xl bg-red-500/15 border border-red-500/30 text-red-300 text-xs font-semibold flex items-center gap-2 animate-in fade-in">
                    <AlertTriangle className="w-4 h-4 text-red-400 shrink-0" />
                    <span>{platformError}</span>
                  </div>
                )}

                <div className="space-y-4 max-h-[65vh] overflow-y-auto pr-1">
                  {/* Platform URL with Smart Auto-Detection */}
                  <div>
                    <div className="flex items-center justify-between mb-1">
                      <label className="text-xs text-[#B8C7D9] font-semibold">
                        Platform Channel or Invite URL <span className="text-red-400">*</span>
                      </label>
                      <span className="text-[10px] text-[#008CFF]">Auto-detects brand & type</span>
                    </div>
                    <input
                      type="url"
                      placeholder="https://youtube.com/@SultanGaming or https://kick.com/sultan..."
                      value={platformForm.url || ''}
                      onChange={e => {
                        const newUrl = e.target.value;
                        const detected = autoDetectPlatformInfo(newUrl);
                        setPlatformForm(prev => ({
                          ...prev,
                          url: newUrl,
                          name: prev.name ? prev.name : detected.name,
                          type: prev.type && prev.type !== 'custom' ? prev.type : detected.type,
                          platformType: prev.platformType && prev.platformType !== 'custom' ? prev.platformType : detected.type,
                          accentColor: prev.accentColor ? prev.accentColor : detected.accentColor,
                          glowColor: prev.glowColor ? prev.glowColor : detected.glowColor,
                          logo: prev.logo && !prev.logo.includes('flaticon') ? prev.logo : detected.logo,
                        }));
                      }}
                      className="w-full bg-white/5 border border-white/15 rounded-xl p-3 text-xs text-white focus:outline-none focus:border-[#FF7A00]"
                      required
                    />
                  </div>

                  {/* Name & Platform Type */}
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    <div>
                      <label className="block text-xs text-[#B8C7D9] mb-1 font-semibold">
                        Platform Display Name <span className="text-red-400">*</span>
                      </label>
                      <input
                        type="text"
                        placeholder="e.g. YouTube, KICK Live, Discord"
                        value={platformForm.name || ''}
                        onChange={e => setPlatformForm({ ...platformForm, name: e.target.value })}
                        className="w-full bg-white/5 border border-white/15 rounded-xl p-2.5 text-xs text-white"
                        required
                      />
                    </div>

                    <div>
                      <label className="block text-xs text-[#B8C7D9] mb-1 font-semibold">Platform Type</label>
                      <select
                        value={platformForm.type || 'youtube'}
                        onChange={e => {
                          const t = e.target.value as PlatformType;
                          setPlatformForm({ ...platformForm, type: t, platformType: t });
                        }}
                        className="w-full bg-[#041426] border border-white/15 rounded-xl p-2.5 text-xs text-white"
                      >
                        <option value="youtube">YouTube</option>
                        <option value="kick">KICK</option>
                        <option value="discord">Discord</option>
                        <option value="instagram">Instagram</option>
                        <option value="twitch">Twitch</option>
                        <option value="tiktok">TikTok</option>
                        <option value="twitter">X / Twitter</option>
                        <option value="custom">Custom / Other</option>
                      </select>
                    </div>
                  </div>

                  {/* Followers & Username */}
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    <div>
                      <label className="block text-xs text-[#B8C7D9] mb-1 font-semibold">Followers / Subscriber Count</label>
                      <input
                        type="text"
                        placeholder="e.g. 1.45M Subscribers, 325K Followers"
                        value={platformForm.followers || ''}
                        onChange={e => setPlatformForm({ ...platformForm, followers: e.target.value })}
                        className="w-full bg-white/5 border border-white/15 rounded-xl p-2.5 text-xs text-white"
                      />
                    </div>

                    <div>
                      <label className="block text-xs text-[#B8C7D9] mb-1 font-semibold">Username / Handle</label>
                      <input
                        type="text"
                        placeholder="e.g. @SultanGaming"
                        value={platformForm.username || platformForm.handle || ''}
                        onChange={e => setPlatformForm({ ...platformForm, username: e.target.value, handle: e.target.value })}
                        className="w-full bg-white/5 border border-white/15 rounded-xl p-2.5 text-xs text-white"
                      />
                    </div>
                  </div>

                  {/* Logo Management (File Upload + Drag & Drop + URL + Preview) */}
                  <div
                    onDragOver={(e) => e.preventDefault()}
                    onDrop={(e) => {
                      e.preventDefault();
                      const file = e.dataTransfer.files?.[0];
                      if (file && file.type.startsWith('image/')) {
                        setPlatformLogoFile(file);
                        const reader = new FileReader();
                        reader.onload = ev => {
                          const res = ev.target?.result as string;
                          setPlatformLogoPreview(res);
                          setPlatformForm(prev => ({ ...prev, logo: res }));
                        };
                        reader.readAsDataURL(file);
                      }
                    }}
                    className="p-4 rounded-2xl bg-white/5 border border-white/10 space-y-3"
                  >
                    <div className="flex items-center justify-between">
                      <label className="text-xs text-[#B8C7D9] font-semibold">Platform Logo & Icon</label>
                      <span className="text-[10px] text-white/40">PNG, JPG, SVG, WebP (Drag & Drop or Click)</span>
                    </div>

                    <div className="flex items-center gap-4">
                      {/* Logo Preview */}
                      <div
                        className="w-14 h-14 rounded-2xl flex items-center justify-center p-2.5 bg-black/60 border border-white/15 overflow-hidden shrink-0 shadow-inner"
                        style={{ borderColor: platformForm.accentColor ? `${platformForm.accentColor}60` : undefined }}
                      >
                        <img
                          src={platformLogoPreview || platformForm.logo || 'https://cdn-icons-png.flaticon.com/512/3670/3670157.png'}
                          alt="Logo Preview"
                          className="w-full h-full object-contain"
                          onError={e => {
                            (e.target as HTMLImageElement).src = 'https://cdn-icons-png.flaticon.com/512/3670/3670157.png';
                          }}
                        />
                      </div>

                      <div className="flex-1 space-y-2">
                        {/* File selector */}
                        <div className="flex items-center gap-2">
                          <label className="cursor-pointer flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-white/10 hover:bg-white/15 border border-white/15 text-xs text-white font-semibold transition-all">
                            <Upload className="w-3.5 h-3.5 text-[#FF7A00]" />
                            <span>Upload Logo Image</span>
                            <input
                              type="file"
                              accept="image/*"
                              className="hidden"
                              onChange={e => {
                                const file = e.target.files?.[0];
                                if (file) {
                                  setPlatformLogoFile(file);
                                  const reader = new FileReader();
                                  reader.onload = ev => {
                                    const res = ev.target?.result as string;
                                    setPlatformLogoPreview(res);
                                    setPlatformForm(prev => ({ ...prev, logo: res }));
                                  };
                                  reader.readAsDataURL(file);
                                }
                              }}
                            />
                          </label>
                          {platformLogoPreview && (
                            <button
                              type="button"
                              onClick={() => {
                                setPlatformLogoPreview(null);
                                setPlatformLogoFile(null);
                                setPlatformForm(prev => ({ ...prev, logo: 'https://cdn-icons-png.flaticon.com/512/3670/3670157.png' }));
                              }}
                              className="text-[11px] text-red-400 hover:text-red-300"
                            >
                              Reset
                            </button>
                          )}
                        </div>

                        {/* Direct URL input */}
                        <input
                          type="url"
                          placeholder="Or paste direct image URL (https://...)"
                          value={platformLogoPreview ? '(Custom Image Selected)' : (platformForm.logo || '')}
                          disabled={!!platformLogoPreview}
                          onChange={e => setPlatformForm({ ...platformForm, logo: e.target.value })}
                          className="w-full bg-black/40 border border-white/10 rounded-xl px-3 py-1.5 text-xs text-white disabled:opacity-50"
                        />
                      </div>
                    </div>
                  </div>

                  {/* Brand Accent Color */}
                  <div>
                    <label className="block text-xs text-[#B8C7D9] mb-1 font-semibold">Platform Brand Color</label>
                    <div className="flex items-center gap-2">
                      <input
                        type="color"
                        value={platformForm.accentColor || '#008CFF'}
                        onChange={e => setPlatformForm({ ...platformForm, accentColor: e.target.value, glowColor: `${e.target.value}66` })}
                        className="w-10 h-9 rounded-lg bg-transparent cursor-pointer border border-white/15"
                      />
                      <input
                        type="text"
                        value={platformForm.accentColor || '#008CFF'}
                        onChange={e => setPlatformForm({ ...platformForm, accentColor: e.target.value, glowColor: `${e.target.value}66` })}
                        className="w-full bg-white/5 border border-white/15 rounded-xl p-2 text-xs text-white uppercase font-mono"
                      />
                    </div>
                  </div>

                  {/* Description */}
                  <div>
                    <label className="block text-xs text-[#B8C7D9] mb-1 font-semibold">Platform Description</label>
                    <textarea
                      rows={2}
                      placeholder="Brief description for Sultan Gaming community on this platform..."
                      value={platformForm.description || ''}
                      onChange={e => setPlatformForm({ ...platformForm, description: e.target.value })}
                      className="w-full bg-white/5 border border-white/15 rounded-xl p-2.5 text-xs text-white"
                    />
                  </div>

                  {/* Toggles */}
                  <div className="flex flex-wrap items-center gap-6 pt-2 border-t border-white/10">
                    <label className="flex items-center gap-2 cursor-pointer text-xs text-white">
                      <input
                        type="checkbox"
                        checked={platformForm.isActive !== false}
                        onChange={e => setPlatformForm({ ...platformForm, isActive: e.target.checked })}
                        className="rounded border-white/20 bg-white/5 text-[#FF7A00] focus:ring-[#FF7A00]"
                      />
                      <span>Active & Visible on Public Site</span>
                    </label>

                    <label className="flex items-center gap-2 cursor-pointer text-xs text-white">
                      <input
                        type="checkbox"
                        checked={platformForm.verified !== false}
                        onChange={e => setPlatformForm({ ...platformForm, verified: e.target.checked })}
                        className="rounded border-white/20 bg-white/5 text-[#008CFF] focus:ring-[#008CFF]"
                      />
                      <span>Verified Badge</span>
                    </label>

                    <label className="flex items-center gap-2 cursor-pointer text-xs text-white">
                      <input
                        type="checkbox"
                        checked={platformForm.featured === true}
                        onChange={e => setPlatformForm({ ...platformForm, featured: e.target.checked })}
                        className="rounded border-white/20 bg-white/5 text-[#53FC18] focus:ring-[#53FC18]"
                      />
                      <span>Featured Highlight</span>
                    </label>
                  </div>
                </div>

                {/* Actions */}
                <div className="flex items-center justify-end gap-3 pt-3 border-t border-white/10">
                  <button
                    disabled={platformSaving}
                    onClick={() => {
                      setShowPlatformModal(false);
                      setPlatformError(null);
                      setPlatformLogoPreview(null);
                      setPlatformLogoFile(null);
                    }}
                    className="px-4 py-2 rounded-xl bg-white/5 hover:bg-white/10 text-xs text-white transition-colors disabled:opacity-50"
                  >
                    Cancel
                  </button>
                  <button
                    disabled={platformSaving}
                    onClick={handleSavePlatform}
                    className="flex items-center gap-2 px-6 py-2.5 rounded-xl bg-gradient-to-r from-[#FF7A00] to-[#FF9500] hover:from-[#FF9500] hover:to-[#FFAE00] text-xs font-bold text-white shadow-lg transition-all disabled:opacity-50"
                  >
                    {platformSaving && <RefreshCw className="w-3.5 h-3.5 animate-spin" />}
                    <span>
                      {platformSaving
                        ? 'Saving to Database...'
                        : editingPlatformId
                        ? 'Save Platform Changes'
                        : 'Save Now'}
                    </span>
                  </button>
                </div>
              </div>
            </div>
          )}

          {/* PLATFORM DETAILS INSPECTION MODAL */}
          {showPlatformDetailsModal && selectedPlatformDetails && (
            <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md">
              <div className="w-full max-w-lg rounded-3xl bg-[#061B2E] border border-white/15 p-6 shadow-2xl space-y-4">
                <div className="flex items-center justify-between pb-3 border-b border-white/10">
                  <div className="flex items-center gap-3">
                    <img src={selectedPlatformDetails.logo} alt="" className="w-8 h-8 object-contain" />
                    <div>
                      <h3 className="text-base font-bold text-white font-['Space_Grotesk']">
                        {selectedPlatformDetails.name} Live Sync Report
                      </h3>
                      <span className="text-[10px] text-[#B8C7D9]">ID: {selectedPlatformDetails.id}</span>
                    </div>
                  </div>
                  <button
                    onClick={() => setShowPlatformDetailsModal(false)}
                    className="p-1.5 rounded-lg bg-white/5 hover:bg-white/10 text-white"
                  >
                    ✕
                  </button>
                </div>

                <div className="space-y-3 text-xs">
                  <div className="grid grid-cols-2 gap-2">
                    <div className="p-3 rounded-xl bg-white/5 border border-white/10">
                      <span className="text-[10px] text-white/40 block">Followers Count</span>
                      <span className="text-sm font-bold text-white font-['Space_Grotesk']">
                        {selectedPlatformDetails.followers}
                      </span>
                    </div>
                    <div className="p-3 rounded-xl bg-white/5 border border-white/10">
                      <span className="text-[10px] text-white/40 block">Sync Status</span>
                      <span className="text-xs font-bold text-[#53FC18]">
                        {selectedPlatformDetails.syncStatus || 'CONNECTED'}
                      </span>
                    </div>
                  </div>

                  <div className="p-3 rounded-xl bg-white/5 border border-white/10 space-y-1">
                    <span className="text-[10px] text-white/40 block">Official API Sync Source</span>
                    <p className="text-xs text-[#008CFF] font-medium">
                      {selectedPlatformDetails.syncSource || 'Official Webhook Engine / Public REST Adapter'}
                    </p>
                  </div>

                  <div className="p-3 rounded-xl bg-white/5 border border-white/10 space-y-1">
                    <span className="text-[10px] text-white/40 block">Target URL</span>
                    <a
                      href={selectedPlatformDetails.url}
                      target="_blank"
                      rel="noreferrer"
                      className="text-xs text-white hover:text-[#FF7A00] truncate block"
                    >
                      {selectedPlatformDetails.url}
                    </a>
                  </div>

                  {selectedPlatformDetails.syncErrorMessage && (
                    <div className="p-3 rounded-xl bg-red-500/10 border border-red-500/20 text-red-300 space-y-1">
                      <span className="text-[10px] font-bold block uppercase text-red-400">Sync Warning / Error</span>
                      <p className="text-xs">{selectedPlatformDetails.syncErrorMessage}</p>
                    </div>
                  )}

                  <div className="flex items-center justify-between text-[11px] text-white/50 pt-2 border-t border-white/10">
                    <span>Last Synced: {selectedPlatformDetails.lastSynced || 'Recently'}</span>
                    <span>Order Position: #{selectedPlatformDetails.displayOrder || 1}</span>
                  </div>
                </div>

                <div className="flex items-center justify-end gap-2 pt-2">
                  <button
                    onClick={async () => {
                      await syncPlatform(selectedPlatformDetails.id);
                      setShowPlatformDetailsModal(false);
                    }}
                    className="px-4 py-2 rounded-xl bg-[#53FC18]/20 hover:bg-[#53FC18]/30 text-[#53FC18] text-xs font-bold border border-[#53FC18]/30 flex items-center gap-1.5"
                  >
                    <RefreshCw className="w-3.5 h-3.5" />
                    <span>Run Sync Now</span>
                  </button>
                  <button
                    onClick={() => setShowPlatformDetailsModal(false)}
                    className="px-4 py-2 rounded-xl bg-white/10 hover:bg-white/15 text-xs text-white font-semibold"
                  >
                    Close
                  </button>
                </div>
              </div>
            </div>
          )}
        </div>
      )}

      {/* TAB: GIVEAWAYS */}
      {activeTab === 'giveaways' && (
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="text-base font-bold text-white uppercase font-['Space_Grotesk']">
              Giveaways & Prize Draws ({giveaways.length})
            </h3>
            <button
              onClick={() => {
                setEditingGiveawayId(null);
                setGiveawayForm({
                  title: '',
                  edition: 'Official Stream Giveaway',
                  description: 'Win premium gaming gear, PS5 pro, or high-end graphics card.',
                  prizeValue: '$4,500 Value',
                  endDate: '2026-12-31',
                  entriesCount: 0,
                  banner: 'https://images.unsplash.com/photo-1587202372775-e229f172b9d7?auto=format&fit=crop&w=1200&q=80',
                  mainPrizeImage: 'https://images.unsplash.com/photo-1587202372775-e229f172b9d7?auto=format&fit=crop&w=1000&q=80',
                  prizeImages: [],
                  prizeFeatures: [],
                  completed: false,
                  terms: ['Open worldwide to registered users', 'Must be active in Sultan Gaming community'],
                });
                setShowGiveawayModal(true);
              }}
              className="flex items-center gap-1.5 px-4 py-2 rounded-full bg-[#FF7A00] hover:bg-[#FF9500] text-white text-xs font-bold shadow-md transition-all"
            >
              <Plus className="w-3.5 h-3.5" />
              <span>Launch Giveaway</span>
            </button>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            {giveaways.map(g => (
              <div
                key={g.id}
                className="p-5 rounded-3xl bg-[#041426]/85 border border-white/10 backdrop-blur-xl space-y-3"
              >
                <div className="flex items-center justify-between">
                  <h4 className="font-bold text-white text-sm">{g.title}</h4>
                  <span
                    className={`px-2.5 py-0.5 rounded-full text-[10px] font-bold ${
                      g.completed ? 'bg-white/10 text-white/50' : 'bg-[#53FC18]/20 text-[#53FC18]'
                    }`}
                  >
                    {g.completed ? 'Completed' : 'Active'}
                  </span>
                </div>

                <p className="text-xs text-[#B8C7D9] line-clamp-2">{g.description}</p>
                <div className="flex items-center gap-2 text-xs font-mono text-[#FF9500]">
                  <span>{g.prizeValue}</span>
                  <span>•</span>
                  <span>{g.entriesCount} Entries</span>
                </div>

                {g.winnerName && (
                  <div className="p-2 rounded-xl bg-[#53FC18]/10 border border-[#53FC18]/20 text-xs text-[#53FC18] font-bold">
                    Winner: {g.winnerName}
                  </div>
                )}

                <div className="flex items-center justify-between pt-2 border-t border-white/10">
                  {!g.completed && (
                    <button
                      onClick={() => drawGiveawayWinner(g.id)}
                      className="px-3 py-1.5 rounded-xl bg-gradient-to-r from-[#FF7A00] to-[#FF9500] text-white text-xs font-bold hover:shadow-lg"
                    >
                      🎲 Draw Random Winner
                    </button>
                  )}

                  <div className="flex items-center gap-1.5 ml-auto">
                    <button
                      onClick={() => deleteGiveaway(g.id)}
                      className="p-1.5 rounded-lg bg-red-500/10 hover:bg-red-500/20 text-red-400"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* TAB: PC SPECS */}
      {activeTab === 'specs' && (
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="text-base font-bold text-white uppercase font-['Space_Grotesk']">
              Hardware & Streaming PC Specs ({pcSpecs.length})
            </h3>
            <button
              onClick={() => {
                addPCSpec({
                  name: 'Custom RTX 5090 OC GPU',
                  category: 'gaming',
                  specs: '32GB GDDR7, 2.6GHz Boost, Liquid Cooled',
                  description: 'Ultra 4K 240FPS gaming and raytracing rendering.',
                  image: 'https://images.unsplash.com/photo-1587202372775-e229f172b9d7?auto=format&fit=crop&w=600&q=80',
                  order: pcSpecs.length + 1,
                  enabled: true,
                });
                flashSave();
              }}
              className="flex items-center gap-1.5 px-4 py-2 rounded-full bg-[#FF7A00] text-white text-xs font-bold"
            >
              <Plus className="w-3.5 h-3.5" />
              <span>Add Hardware Item</span>
            </button>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            {pcSpecs.map(spec => (
              <div
                key={spec.id}
                className="p-4 rounded-2xl bg-[#041426]/85 border border-white/10 backdrop-blur-xl flex items-center justify-between gap-4"
              >
                <div>
                  <span className="text-[10px] text-[#FF9500] uppercase font-bold">{spec.category}</span>
                  <h4 className="text-xs font-bold text-white mt-0.5">{spec.name}</h4>
                  <p className="text-[11px] text-[#B8C7D9]">{spec.specs}</p>
                </div>
                <button onClick={() => deletePCSpec(spec.id)} className="text-red-400 p-2">
                  <Trash2 className="w-4 h-4" />
                </button>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* TAB: FAQ */}
      {activeTab === 'faq' && (
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="text-base font-bold text-white uppercase font-['Space_Grotesk']">
              FAQ Database ({faqs.length})
            </h3>
          </div>
          <div className="space-y-3">
            {faqs.map(faq => (
              <div
                key={faq.id}
                className="p-4 rounded-2xl bg-[#041426]/85 border border-white/10 backdrop-blur-xl flex items-center justify-between gap-4"
              >
                <div>
                  <span className="text-[10px] px-2 py-0.5 rounded-full bg-white/5 text-[#00B7FF] font-medium">
                    {faq.category}
                  </span>
                  <h4 className="text-xs font-bold text-white mt-1">{faq.question}</h4>
                  <p className="text-[11px] text-[#B8C7D9] line-clamp-1 mt-0.5">{faq.answer}</p>
                </div>
                <button onClick={() => deleteFAQ(faq.id)} className="p-1.5 rounded-lg bg-red-500/10 text-red-400">
                  <Trash2 className="w-3.5 h-3.5" />
                </button>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* TAB: COMMUNITY */}
      {activeTab === 'community' && (
        <div className="space-y-4">
          <h3 className="text-base font-bold text-white uppercase font-['Space_Grotesk']">
            Community Posts & Moderation ({posts.length})
          </h3>
          <div className="space-y-3">
            {posts.map(post => (
              <div
                key={post.id}
                className="p-4 rounded-2xl bg-[#041426]/85 border border-white/10 backdrop-blur-xl flex items-start justify-between gap-4"
              >
                <div className="space-y-1">
                  <div className="flex items-center gap-2">
                    <span className="font-bold text-xs text-white">{post.author.name}</span>
                    <span className="text-[10px] text-[#FF9500]">#{post.gameTag}</span>
                    <span className="text-[10px] text-white/40">{post.timestamp}</span>
                  </div>
                  <p className="text-xs text-[#EAF4FF]">{post.content}</p>
                  <span className="text-[10px] text-white/40">{post.likes} Likes • {post.commentsCount} Comments</span>
                </div>
                <button
                  onClick={() => deletePost(post.id)}
                  className="p-2 rounded-xl bg-red-500/10 hover:bg-red-500/20 text-red-400 transition-colors flex-shrink-0"
                >
                  <Trash2 className="w-4 h-4" />
                </button>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* TAB: MEDIA LIBRARY */}
      {activeTab === 'media' && (
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="text-base font-bold text-white uppercase font-['Space_Grotesk']">
              Media Asset Library ({media.length})
            </h3>
          </div>

          <div className="p-4 rounded-2xl bg-white/5 border border-white/10 flex flex-wrap items-center gap-3">
            <input
              type="text"
              value={mediaTitle}
              onChange={e => setMediaTitle(e.target.value)}
              placeholder="Media asset title..."
              className="flex-1 min-w-[150px] bg-black/40 border border-white/10 rounded-xl px-3 py-2 text-xs text-white"
            />
            <input
              type="url"
              value={mediaUrl}
              onChange={e => setMediaUrl(e.target.value)}
              placeholder="Image URL (https://...)"
              className="flex-1 min-w-[200px] bg-black/40 border border-white/10 rounded-xl px-3 py-2 text-xs text-white"
            />
            <select
              value={mediaType}
              onChange={e => setMediaType(e.target.value as any)}
              className="bg-black/40 border border-white/10 rounded-xl px-3 py-2 text-xs text-white"
            >
              <option value="banner">Banner</option>
              <option value="game">Game</option>
              <option value="hardware">Hardware</option>
              <option value="giveaway">Giveaway</option>
            </select>
            <button
              onClick={() => {
                if (mediaTitle && mediaUrl) {
                  addMedia({ name: mediaTitle, url: mediaUrl, type: mediaType, size: '1.2 MB' });
                  setMediaTitle('');
                  setMediaUrl('');
                  flashSave();
                }
              }}
              className="px-4 py-2 rounded-xl bg-[#008CFF] text-white text-xs font-bold hover:bg-[#00B7FF]"
            >
              Add Asset
            </button>
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
            {media.map(item => (
              <div key={item.id} className="relative aspect-video rounded-2xl overflow-hidden bg-black/60 border border-white/10 group">
                <img src={item.url} alt={item.name} className="w-full h-full object-cover" />
                <div className="absolute inset-0 bg-black/70 opacity-0 group-hover:opacity-100 transition-opacity p-2 flex flex-col justify-between text-xs text-white">
                  <span className="font-bold truncate">{item.name}</span>
                  <div className="flex items-center justify-between">
                    <span className="text-[10px] text-[#FF9500] uppercase">{item.type}</span>
                    <button onClick={() => deleteMedia(item.id)} className="text-red-400 p-1">
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};
