import React, { useState, useEffect } from 'react';
import {
  ShieldCheck,
  Users,
  FileText,
  Upload,
  Calendar,
  Mail,
  HardDrive,
  Eye,
  Trash2,
  RefreshCw,
  Search,
  ExternalLink,
  CheckCircle2,
  AlertTriangle,
  FolderOpen,
  Image as ImageIcon,
  FileCode,
  FileArchive,
  Download,
  X,
  UserCheck,
  Sparkles,
  Lock,
  ArrowRight,
  Database,
  Layers,
  Clock,
  KeyRound,
  ChevronRight,
  Plus
} from 'lucide-react';
import { useStore } from '../context/StoreContext';
import { FirestoreUserData, UserUploadedFile } from '../types';
import { ADMIN_USER_ID } from '../lib/firebase';

export const DashboardPage: React.FC = () => {
  const {
    currentUser,
    isAuthenticated,
    setAuthModalOpen,
    firestoreUsers,
    isLoadingFirestoreUsers,
    fetchFirestoreUsers,
    fetchUserUploadedFiles,
    uploadUserFile,
    deleteUserUploadedFile,
    simulateAdminLogin,
    addNotification,
  } = useStore();

  // Admin View State
  const [selectedUser, setSelectedUser] = useState<FirestoreUserData | null>(null);
  const [selectedUserFiles, setSelectedUserFiles] = useState<UserUploadedFile[]>([]);
  const [isLoadingFiles, setIsLoadingFiles] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [previewFile, setPreviewFile] = useState<UserUploadedFile | null>(null);
  const [isRefreshing, setIsRefreshing] = useState(false);

  // Personal Dashboard Upload State
  const [isUploading, setIsUploading] = useState(false);
  const [dragActive, setDragActive] = useState(false);
  const [uploadCategory, setUploadCategory] = useState<'media' | 'post' | 'avatar' | 'document'>('media');
  const [personalFiles, setPersonalFiles] = useState<UserUploadedFile[]>([]);
  const [isLoadingPersonalFiles, setIsLoadingPersonalFiles] = useState(false);

  // Determine if the current user is the root Admin
  const isRootAdmin = currentUser?.id === ADMIN_USER_ID || currentUser?.role === 'SUPER_ADMIN';

  // Load Firestore users when page mounts
  useEffect(() => {
    fetchFirestoreUsers();
  }, []);

  // Load files for regular user
  useEffect(() => {
    if (currentUser && !isRootAdmin) {
      loadPersonalFiles(currentUser.id);
    }
  }, [currentUser, isRootAdmin]);

  const loadPersonalFiles = async (uid: string) => {
    setIsLoadingPersonalFiles(true);
    try {
      const files = await fetchUserUploadedFiles(uid);
      setPersonalFiles(files);
    } finally {
      setIsLoadingPersonalFiles(false);
    }
  };

  const handleRefresh = async () => {
    setIsRefreshing(true);
    try {
      await fetchFirestoreUsers();
      if (selectedUser) {
        const files = await fetchUserUploadedFiles(selectedUser.id);
        setSelectedUserFiles(files);
      }
      if (currentUser && !isRootAdmin) {
        await loadPersonalFiles(currentUser.id);
      }
      addNotification({
        title: 'Firestore Synced',
        message: 'Loaded latest users and files from database.',
        type: 'community',
      });
    } finally {
      setIsRefreshing(false);
    }
  };

  const handleSelectUser = async (user: FirestoreUserData) => {
    setSelectedUser(user);
    setIsLoadingFiles(true);
    try {
      // First check if user already has uploadedFiles cached
      if (user.uploadedFiles && user.uploadedFiles.length > 0) {
        setSelectedUserFiles(user.uploadedFiles);
      }
      // Fetch fresh files for this user from Firestore
      const files = await fetchUserUploadedFiles(user.id);
      setSelectedUserFiles(files);
    } catch (err) {
      console.error('Error fetching user files:', err);
    } finally {
      setIsLoadingFiles(false);
    }
  };

  const handleFileUpload = async (file: File) => {
    if (!file) return;
    setIsUploading(true);
    try {
      const res = await uploadUserFile(file, uploadCategory);
      if (res.success && res.file) {
        if (currentUser) {
          await loadPersonalFiles(currentUser.id);
        }
        await fetchFirestoreUsers();
      } else {
        alert(res.error || 'Upload failed');
      }
    } catch (err: any) {
      alert(err?.message || 'Error uploading file');
    } finally {
      setIsUploading(false);
    }
  };

  const handleDeleteFile = async (userId: string, fileId: string) => {
    if (!confirm('Are you sure you want to permanently delete this file?')) return;
    const res = await deleteUserUploadedFile(userId, fileId);
    if (res.success) {
      setSelectedUserFiles(prev => prev.filter(f => f.id !== fileId));
      setPersonalFiles(prev => prev.filter(f => f.id !== fileId));
      if (previewFile?.id === fileId) {
        setPreviewFile(null);
      }
      await fetchFirestoreUsers();
    }
  };

  const formatCreationDate = (dateStr?: string) => {
    if (!dateStr) return 'N/A';
    try {
      const d = new Date(dateStr);
      if (isNaN(d.getTime())) return dateStr;
      return d.toLocaleDateString('en-US', {
        year: 'numeric',
        month: 'short',
        day: 'numeric',
        hour: '2-digit',
        minute: '2-digit',
      });
    } catch {
      return dateStr;
    }
  };

  const getFileIcon = (type?: string, name?: string) => {
    const ext = name?.split('.').pop()?.toLowerCase() || '';
    if (type?.startsWith('image/') || ['png', 'jpg', 'jpeg', 'webp', 'gif'].includes(ext)) {
      return <ImageIcon className="w-5 h-5 text-emerald-400" />;
    }
    if (['zip', 'rar', '7z', 'tar', 'gz'].includes(ext)) {
      return <FileArchive className="w-5 h-5 text-amber-400" />;
    }
    if (['pdf', 'doc', 'docx', 'txt'].includes(ext)) {
      return <FileText className="w-5 h-5 text-sky-400" />;
    }
    return <FileCode className="w-5 h-5 text-indigo-400" />;
  };

  // Filtered users for admin list
  const filteredUsers = firestoreUsers.filter(u => {
    const q = searchQuery.toLowerCase().trim();
    if (!q) return true;
    return (
      u.email?.toLowerCase().includes(q) ||
      u.displayName?.toLowerCase().includes(q) ||
      u.username?.toLowerCase().includes(q) ||
      u.id?.toLowerCase().includes(q)
    );
  });

  const totalFilesAcrossAllUsers = firestoreUsers.reduce(
    (acc, u) => acc + (u.uploadedFiles?.length || u.filesCount || 0),
    0
  );

  // If user is not authenticated, show sign in / simulation banner
  if (!isAuthenticated || !currentUser) {
    return (
      <div className="max-w-4xl mx-auto py-12 px-4 space-y-8 animate-in fade-in duration-300">
        <div className="text-center space-y-4">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-[#008CFF]/20 border border-[#008CFF]/30 text-[#00B7FF] text-xs font-bold uppercase tracking-wider font-mono">
            <Lock className="w-3.5 h-3.5" />
            Authentication Required
          </div>
          <h1 className="text-3xl sm:text-4xl font-black text-white font-['Space_Grotesk'] tracking-tight">
            Sultan Gaming <span className="text-transparent bg-clip-text bg-gradient-to-r from-[#FF7A00] to-[#FF9500]">Dashboard</span>
          </h1>
          <p className="text-sm text-[#B8C7D9] max-w-lg mx-auto">
            Please sign in with your Sultan Gaming account. If you log in as the designated Admin (<span className="text-[#FF9500] font-mono font-bold">{ADMIN_USER_ID}</span>), you will automatically access the full Firestore Admin Overview.
          </p>
        </div>

        <div className="grid sm:grid-cols-2 gap-4 max-w-2xl mx-auto">
          {/* Admin Login Button */}
          <div className="p-6 rounded-2xl bg-[#041426]/90 border border-[#FF7A00]/40 flex flex-col justify-between hover:border-[#FF7A00] transition-all shadow-[0_0_20px_rgba(255,122,0,0.15)] group">
            <div className="space-y-3">
              <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-[#FF7A00] to-[#FF9500] flex items-center justify-center text-white font-bold shadow-md">
                <ShieldCheck className="w-5 h-5" />
              </div>
              <h3 className="text-lg font-bold text-white group-hover:text-[#FF9500] transition-colors">
                Admin Dashboard Access
              </h3>
              <p className="text-xs text-[#B8C7D9]">
                Sign in or switch to the root administrator ID (<code className="text-[#FF9500]">{ADMIN_USER_ID.substring(0, 10)}...</code>) to inspect all users & uploaded files.
              </p>
            </div>

            <button
              id="admin-dashboard-quick-login-btn"
              onClick={simulateAdminLogin}
              className="mt-6 w-full flex items-center justify-center gap-2 py-2.5 px-4 rounded-xl bg-gradient-to-r from-[#FF7A00] to-[#FF9500] text-white font-bold text-xs hover:shadow-[0_0_15px_rgba(255,122,0,0.5)] transition-all active:scale-95"
            >
              <KeyRound className="w-4 h-4" />
              <span>Sign In as Admin User</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>

          {/* Regular User Sign In */}
          <div className="p-6 rounded-2xl bg-[#041426]/90 border border-white/10 flex flex-col justify-between hover:border-[#008CFF]/50 transition-all group">
            <div className="space-y-3">
              <div className="w-10 h-10 rounded-xl bg-[#008CFF]/20 border border-[#008CFF]/30 flex items-center justify-center text-[#00B7FF] font-bold shadow-md">
                <Users className="w-5 h-5" />
              </div>
              <h3 className="text-lg font-bold text-white group-hover:text-[#00B7FF] transition-colors">
                Personal User Dashboard
              </h3>
              <p className="text-xs text-[#B8C7D9]">
                Sign in with your standard email & password to manage your own profile, uploaded media, and community activities.
              </p>
            </div>

            <button
              id="user-dashboard-sign-in-btn"
              onClick={() => setAuthModalOpen(true)}
              className="mt-6 w-full flex items-center justify-center gap-2 py-2.5 px-4 rounded-xl bg-white/10 hover:bg-white/15 text-white font-bold text-xs border border-white/10 transition-all active:scale-95"
            >
              <Mail className="w-4 h-4 text-[#00B7FF]" />
              <span>Sign In with Email</span>
            </button>
          </div>
        </div>
      </div>
    );
  }

  // ==========================================
  // VIEW 1: ADMIN DASHBOARD (When root Admin ID is logged in)
  // ==========================================
  if (isRootAdmin) {
    return (
      <div className="space-y-6 pb-16 animate-in fade-in duration-300">
        {/* Top Prominent Admin Badge & Indicator */}
        <div className="relative overflow-hidden rounded-2xl bg-gradient-to-r from-[#FF7A00]/20 via-[#061B2E] to-[#041426] border-2 border-[#FF7A00]/60 p-5 shadow-[0_0_30px_rgba(255,122,0,0.2)]">
          <div className="absolute top-0 right-0 -mr-12 -mt-12 w-48 h-48 bg-[#FF7A00]/10 rounded-full blur-3xl pointer-events-none" />
          
          <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
            <div className="flex items-start sm:items-center gap-4">
              <div className="relative flex-shrink-0">
                <div className="w-12 h-12 rounded-2xl bg-gradient-to-br from-[#FF7A00] to-[#FF2200] flex items-center justify-center text-white shadow-lg shadow-[#FF7A00]/30 border border-white/20">
                  <ShieldCheck className="w-7 h-7" />
                </div>
                <span className="absolute -bottom-1 -right-1 flex h-4 w-4">
                  <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-[#FF7A00] opacity-75"></span>
                  <span className="relative inline-flex rounded-full h-4 w-4 bg-[#FF7A00] border-2 border-[#020817]"></span>
                </span>
              </div>

              <div>
                <div className="flex items-center gap-2 flex-wrap">
                  {/* The requested ADMIN BADGE */}
                  <span
                    id="admin-view-badge"
                    className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-gradient-to-r from-[#FF7A00] to-[#FF9500] text-black font-black text-xs uppercase tracking-wider shadow-md shadow-[#FF7A00]/40 font-['Space_Grotesk']"
                  >
                    <ShieldCheck className="w-3.5 h-3.5 text-black" />
                    ADMIN VIEW
                  </span>
                  <span className="text-[11px] font-mono text-[#FF9500] bg-[#FF7A00]/10 border border-[#FF7A00]/30 px-2 py-0.5 rounded-md">
                    UID: {currentUser.id}
                  </span>
                  <span className="text-[11px] font-mono text-emerald-400 bg-emerald-500/10 border border-emerald-500/30 px-2 py-0.5 rounded-md flex items-center gap-1">
                    <CheckCircle2 className="w-3 h-3" />
                    Firestore Read-All Permission Active
                  </span>
                </div>
                <h1 className="text-xl sm:text-2xl font-black text-white font-['Space_Grotesk'] mt-1">
                  Firestore User & File Administration
                </h1>
                <p className="text-xs text-[#B8C7D9] max-w-2xl">
                  Logged in as root Administrator. You have comprehensive read access to all registered users and their uploaded files across the Firestore database.
                </p>
              </div>
            </div>

            {/* Quick Actions */}
            <div className="flex items-center gap-2 self-start md:self-auto">
              <button
                id="admin-refresh-firestore-btn"
                onClick={handleRefresh}
                disabled={isRefreshing || isLoadingFirestoreUsers}
                className="flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-white/10 hover:bg-white/15 text-white text-xs font-bold border border-white/15 transition-all active:scale-95 disabled:opacity-50"
              >
                <RefreshCw className={`w-3.5 h-3.5 text-[#00B7FF] ${isRefreshing ? 'animate-spin' : ''}`} />
                <span>Refresh Firestore</span>
              </button>
            </div>
          </div>
        </div>

        {/* Stats Strip */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3.5">
          <div className="p-4 rounded-2xl bg-[#041426]/80 border border-white/10 backdrop-blur-md">
            <div className="flex items-center justify-between text-xs text-[#B8C7D9]">
              <span>Total Registered Users</span>
              <Users className="w-4 h-4 text-[#00B7FF]" />
            </div>
            <p className="text-2xl font-black text-white font-mono mt-1">
              {firestoreUsers.length}
            </p>
            <span className="text-[10px] text-emerald-400 flex items-center gap-1 mt-1">
              <CheckCircle2 className="w-3 h-3" /> In Firestore collection
            </span>
          </div>

          <div className="p-4 rounded-2xl bg-[#041426]/80 border border-white/10 backdrop-blur-md">
            <div className="flex items-center justify-between text-xs text-[#B8C7D9]">
              <span>Total Uploaded Files</span>
              <FolderOpen className="w-4 h-4 text-[#FF7A00]" />
            </div>
            <p className="text-2xl font-black text-white font-mono mt-1">
              {totalFilesAcrossAllUsers}
            </p>
            <span className="text-[10px] text-[#FF9500] flex items-center gap-1 mt-1">
              <HardDrive className="w-3 h-3" /> Stored across users
            </span>
          </div>

          <div className="p-4 rounded-2xl bg-[#041426]/80 border border-white/10 backdrop-blur-md">
            <div className="flex items-center justify-between text-xs text-[#B8C7D9]">
              <span>Active Admin Session</span>
              <KeyRound className="w-4 h-4 text-emerald-400" />
            </div>
            <p className="text-sm font-bold text-white font-mono mt-1 truncate">
              {currentUser.email}
            </p>
            <span className="text-[10px] text-white/50 truncate block mt-1">
              Role: {currentUser.role}
            </span>
          </div>

          <div className="p-4 rounded-2xl bg-[#041426]/80 border border-white/10 backdrop-blur-md">
            <div className="flex items-center justify-between text-xs text-[#B8C7D9]">
              <span>Security Rule Scope</span>
              <Lock className="w-4 h-4 text-purple-400" />
            </div>
            <p className="text-xs font-bold text-white mt-1">
              Admin Bypass Mode
            </p>
            <span className="text-[10px] text-purple-300 flex items-center gap-1 mt-1">
              <Database className="w-3 h-3" /> Full DB Read Access
            </span>
          </div>
        </div>

        {/* Main 2-Column Interface: Users List on Left, Selected User Files on Right */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          {/* Column 1: Users List from Firestore */}
          <div className="lg:col-span-7 space-y-4">
            <div className="rounded-2xl bg-[#041426]/90 border border-white/10 p-4 sm:p-5 backdrop-blur-xl shadow-xl">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-4 border-b border-white/10">
                <div>
                  <h2 className="text-base font-bold text-white flex items-center gap-2">
                    <Users className="w-4 h-4 text-[#FF7A00]" />
                    Firestore Users Directory
                  </h2>
                  <p className="text-xs text-[#B8C7D9]">
                    Click any user below to inspect their uploaded files in real-time.
                  </p>
                </div>

                {/* Search Bar */}
                <div className="relative w-full sm:w-56">
                  <Search className="w-3.5 h-3.5 text-white/40 absolute left-3 top-1/2 -translate-y-1/2" />
                  <input
                    type="text"
                    id="admin-search-users-input"
                    value={searchQuery}
                    onChange={e => setSearchQuery(e.target.value)}
                    placeholder="Search by email / name..."
                    className="w-full bg-black/40 border border-white/10 rounded-xl pl-8 pr-3 py-1.5 text-xs text-white placeholder-white/40 focus:outline-none focus:border-[#FF7A00] transition-colors"
                  />
                  {searchQuery && (
                    <button
                      onClick={() => setSearchQuery('')}
                      className="absolute right-2.5 top-1/2 -translate-y-1/2 text-white/40 hover:text-white"
                    >
                      <X className="w-3 h-3" />
                    </button>
                  )}
                </div>
              </div>

              {/* Users List Table / Cards */}
              <div className="divide-y divide-white/5 mt-2">
                {isLoadingFirestoreUsers ? (
                  <div className="py-12 text-center text-xs text-[#B8C7D9] space-y-2">
                    <RefreshCw className="w-6 h-6 text-[#FF7A00] animate-spin mx-auto" />
                    <p>Loading users from Firestore...</p>
                  </div>
                ) : filteredUsers.length === 0 ? (
                  <div className="py-12 text-center text-xs text-[#B8C7D9] space-y-1">
                    <AlertTriangle className="w-6 h-6 text-amber-400 mx-auto" />
                    <p className="font-bold text-white">No users found</p>
                    <p>Try clearing your search query or clicking Refresh.</p>
                  </div>
                ) : (
                  filteredUsers.map(user => {
                    const isSelected = selectedUser?.id === user.id;
                    const fileCount = user.uploadedFiles?.length ?? user.filesCount ?? 0;
                    return (
                      <div
                        key={user.id}
                        id={`admin-user-row-${user.id}`}
                        onClick={() => handleSelectUser(user)}
                        className={`py-3 px-3 rounded-xl cursor-pointer transition-all duration-200 flex items-center justify-between gap-3 group ${
                          isSelected
                            ? 'bg-[#FF7A00]/15 border border-[#FF7A00] shadow-[0_0_15px_rgba(255,122,0,0.25)]'
                            : 'hover:bg-white/5 border border-transparent'
                        }`}
                      >
                        {/* User Avatar & Info */}
                        <div className="flex items-center gap-3 min-w-0 flex-1">
                          <div className="relative w-10 h-10 rounded-xl overflow-hidden bg-black/40 border border-white/20 flex-shrink-0">
                            <img
                              src={user.avatar || 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=150&auto=format&fit=crop&q=80'}
                              alt={user.displayName || user.email}
                              className="w-full h-full object-cover"
                            />
                            {user.id === ADMIN_USER_ID && (
                              <div className="absolute bottom-0 right-0 w-3 h-3 bg-[#FF7A00] border-2 border-black rounded-full" title="Root Admin" />
                            )}
                          </div>

                          <div className="min-w-0 flex-1">
                            <div className="flex items-center gap-2">
                              <span className="text-xs font-bold text-white truncate group-hover:text-[#FF9500] transition-colors">
                                {user.displayName || user.email.split('@')[0]}
                              </span>
                              {user.id === ADMIN_USER_ID ? (
                                <span className="text-[9px] font-bold px-1.5 py-0.2 rounded bg-[#FF7A00]/20 text-[#FF9500] border border-[#FF7A00]/30 font-mono">
                                  ROOT ADMIN
                                </span>
                              ) : (
                                <span className="text-[9px] font-mono px-1.5 py-0.2 rounded bg-white/10 text-white/70">
                                  {user.role || 'USER'}
                                </span>
                              )}
                            </div>

                            {/* Email */}
                            <div className="flex items-center gap-1.5 text-[11px] text-[#B8C7D9] truncate mt-0.5">
                              <Mail className="w-3 h-3 text-[#00B7FF] flex-shrink-0" />
                              <span className="truncate font-mono">{user.email}</span>
                            </div>

                            {/* Account Creation Date */}
                            <div className="flex items-center gap-1.5 text-[10px] text-white/50 mt-0.5">
                              <Calendar className="w-3 h-3 text-[#FF9500] flex-shrink-0" />
                              <span>Created: {formatCreationDate(user.createdAt)}</span>
                            </div>
                          </div>
                        </div>

                        {/* File Count Badge & View Button */}
                        <div className="flex items-center gap-2 flex-shrink-0">
                          <div className="text-right">
                            <div className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full bg-black/40 border border-white/10 text-xs font-bold font-mono">
                              <FolderOpen className="w-3.5 h-3.5 text-[#00B7FF]" />
                              <span className="text-white">{fileCount}</span>
                              <span className="text-white/40 text-[10px] hidden sm:inline">files</span>
                            </div>
                          </div>

                          <div className={`p-1.5 rounded-lg border transition-all ${
                            isSelected
                              ? 'bg-[#FF7A00] text-white border-[#FF7A00]'
                              : 'bg-white/5 text-white/50 border-white/10 group-hover:text-white group-hover:bg-white/10'
                          }`}>
                            <ChevronRight className="w-4 h-4" />
                          </div>
                        </div>
                      </div>
                    );
                  })
                )}
              </div>
            </div>
          </div>

          {/* Column 2: Selected User's Uploaded Files View */}
          <div className="lg:col-span-5 space-y-4">
            <div className="rounded-2xl bg-[#041426]/90 border border-white/10 p-4 sm:p-5 backdrop-blur-xl shadow-xl sticky top-20">
              {selectedUser ? (
                <div className="space-y-4">
                  {/* Selected User Header */}
                  <div className="pb-3 border-b border-white/10">
                    <div className="flex items-center justify-between">
                      <span className="text-[10px] font-bold text-[#FF9500] uppercase tracking-wider font-mono">
                        User Files Explorer
                      </span>
                      <button
                        onClick={() => setSelectedUser(null)}
                        className="text-white/40 hover:text-white text-xs p-1"
                      >
                        <X className="w-4 h-4" />
                      </button>
                    </div>

                    <div className="flex items-center gap-3 mt-2">
                      <img
                        src={selectedUser.avatar || 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=150&auto=format&fit=crop&q=80'}
                        alt={selectedUser.displayName || selectedUser.email}
                        className="w-10 h-10 rounded-xl object-cover border border-white/20"
                      />
                      <div className="min-w-0 flex-1">
                        <p className="text-sm font-bold text-white truncate">
                          {selectedUser.displayName || selectedUser.email}
                        </p>
                        <p className="text-xs text-[#00B7FF] font-mono truncate">
                          {selectedUser.email}
                        </p>
                      </div>
                    </div>

                    <div className="grid grid-cols-2 gap-2 mt-3 pt-3 border-t border-white/5 text-[11px]">
                      <div className="bg-black/30 p-2 rounded-lg border border-white/5">
                        <span className="text-white/40 block text-[9px] uppercase">Account Created</span>
                        <span className="text-white font-medium truncate block">
                          {formatCreationDate(selectedUser.createdAt)}
                        </span>
                      </div>
                      <div className="bg-black/30 p-2 rounded-lg border border-white/5">
                        <span className="text-white/40 block text-[9px] uppercase">Total Uploads</span>
                        <span className="text-[#FF9500] font-bold font-mono">
                          {selectedUserFiles.length} files
                        </span>
                      </div>
                    </div>
                  </div>

                  {/* Files List */}
                  <div className="space-y-2">
                    <div className="flex items-center justify-between text-xs font-bold text-white">
                      <span>Uploaded Files ({selectedUserFiles.length})</span>
                      {isLoadingFiles && (
                        <RefreshCw className="w-3.5 h-3.5 text-[#FF7A00] animate-spin" />
                      )}
                    </div>

                    {isLoadingFiles ? (
                      <div className="py-8 text-center text-xs text-[#B8C7D9]">
                        <RefreshCw className="w-5 h-5 text-[#FF7A00] animate-spin mx-auto mb-2" />
                        Fetching files from Firestore...
                      </div>
                    ) : selectedUserFiles.length === 0 ? (
                      <div className="py-8 text-center text-xs text-[#B8C7D9] bg-black/20 rounded-xl border border-white/5 p-4">
                        <FolderOpen className="w-6 h-6 text-white/30 mx-auto mb-2" />
                        <p className="font-bold text-white">No files uploaded yet</p>
                        <p className="text-[11px] text-white/50 mt-0.5">This user has not uploaded any files to Firestore.</p>
                      </div>
                    ) : (
                      <div className="space-y-2 max-h-[420px] overflow-y-auto pr-1">
                        {selectedUserFiles.map(file => (
                          <div
                            key={file.id}
                            id={`admin-file-item-${file.id}`}
                            className="p-2.5 rounded-xl bg-black/40 border border-white/10 hover:border-white/20 transition-all flex items-center justify-between gap-2.5 group"
                          >
                            <div className="flex items-center gap-2.5 min-w-0 flex-1">
                              {/* Preview thumbnail or icon */}
                              <div
                                onClick={() => setPreviewFile(file)}
                                className="w-10 h-10 rounded-lg bg-black/60 border border-white/10 overflow-hidden flex items-center justify-center cursor-pointer flex-shrink-0 hover:border-[#FF7A00] transition-colors"
                              >
                                {file.url && (file.type?.startsWith('image/') || file.name.match(/\.(jpg|jpeg|png|webp|gif)$/i)) ? (
                                  <img src={file.url} alt={file.name} className="w-full h-full object-cover" />
                                ) : (
                                  getFileIcon(file.type, file.name)
                                )}
                              </div>

                              <div className="min-w-0 flex-1">
                                <p
                                  onClick={() => setPreviewFile(file)}
                                  className="text-xs font-semibold text-white truncate cursor-pointer hover:text-[#FF9500] transition-colors"
                                  title={file.name}
                                >
                                  {file.name}
                                </p>
                                <div className="flex items-center gap-2 text-[10px] text-white/50 mt-0.5">
                                  <span>{file.sizeFormatted || 'Unknown size'}</span>
                                  <span>•</span>
                                  <span>{formatCreationDate(file.createdAt)}</span>
                                </div>
                              </div>
                            </div>

                            {/* Actions */}
                            <div className="flex items-center gap-1">
                              <button
                                onClick={() => setPreviewFile(file)}
                                className="p-1.5 rounded-lg bg-white/5 hover:bg-white/10 text-white/70 hover:text-white transition-colors"
                                title="Preview File"
                              >
                                <Eye className="w-3.5 h-3.5" />
                              </button>
                              <a
                                href={file.url}
                                target="_blank"
                                rel="noopener noreferrer"
                                className="p-1.5 rounded-lg bg-white/5 hover:bg-white/10 text-[#00B7FF] transition-colors"
                                title="Open in new tab"
                              >
                                <ExternalLink className="w-3.5 h-3.5" />
                              </a>
                              <button
                                onClick={() => handleDeleteFile(selectedUser.id, file.id)}
                                className="p-1.5 rounded-lg bg-white/5 hover:bg-red-500/20 text-white/40 hover:text-red-400 transition-colors"
                                title="Delete file"
                              >
                                <Trash2 className="w-3.5 h-3.5" />
                              </button>
                            </div>
                          </div>
                        ))}
                      </div>
                    )}
                  </div>
                </div>
              ) : (
                <div className="py-16 text-center text-xs text-[#B8C7D9] space-y-3">
                  <div className="w-12 h-12 rounded-2xl bg-white/5 border border-white/10 flex items-center justify-center mx-auto text-white/40">
                    <FolderOpen className="w-6 h-6" />
                  </div>
                  <div>
                    <p className="font-bold text-white text-sm">Select a User</p>
                    <p className="text-[11px] text-white/50 max-w-xs mx-auto mt-1">
                      Click any user in the directory on the left to inspect all their uploaded files stored in Firestore.
                    </p>
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>

        {/* File Preview Modal */}
        {previewFile && (
          <div className="fixed inset-0 bg-black/85 backdrop-blur-md z-50 flex items-center justify-center p-4">
            <div className="w-full max-w-2xl bg-[#061B2E] border border-white/20 rounded-2xl p-5 space-y-4 shadow-2xl animate-in zoom-in-95 duration-150">
              <div className="flex items-center justify-between pb-3 border-b border-white/10">
                <div className="flex items-center gap-2 truncate mr-3">
                  {getFileIcon(previewFile.type, previewFile.name)}
                  <h3 className="text-sm font-bold text-white truncate">{previewFile.name}</h3>
                </div>
                <button
                  onClick={() => setPreviewFile(null)}
                  className="p-1 rounded-lg text-white/50 hover:text-white bg-white/5"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>

              {/* Preview Content */}
              <div className="rounded-xl overflow-hidden bg-black/60 border border-white/10 flex items-center justify-center max-h-[400px]">
                {previewFile.url && (previewFile.type?.startsWith('image/') || previewFile.name.match(/\.(jpg|jpeg|png|webp|gif)$/i)) ? (
                  <img
                    src={previewFile.url}
                    alt={previewFile.name}
                    className="max-h-[380px] w-auto object-contain"
                  />
                ) : (
                  <div className="py-16 text-center space-y-3">
                    <div className="w-16 h-16 rounded-2xl bg-white/5 border border-white/10 flex items-center justify-center mx-auto text-[#00B7FF]">
                      <FileText className="w-8 h-8" />
                    </div>
                    <p className="text-sm font-bold text-white">{previewFile.name}</p>
                    <p className="text-xs text-white/50 font-mono">{previewFile.type || 'Binary file'}</p>
                  </div>
                )}
              </div>

              {/* Meta details */}
              <div className="grid grid-cols-3 gap-2 text-xs bg-black/30 p-3 rounded-xl border border-white/5">
                <div>
                  <span className="text-white/40 block text-[10px]">File Size</span>
                  <span className="text-white font-mono">{previewFile.sizeFormatted || 'N/A'}</span>
                </div>
                <div>
                  <span className="text-white/40 block text-[10px]">Uploaded At</span>
                  <span className="text-white">{formatCreationDate(previewFile.createdAt)}</span>
                </div>
                <div>
                  <span className="text-white/40 block text-[10px]">Uploader</span>
                  <span className="text-[#FF9500] truncate block">{previewFile.uploaderEmail || previewFile.userId}</span>
                </div>
              </div>

              {/* Action Buttons */}
              <div className="flex items-center justify-end gap-2 pt-2">
                <a
                  href={previewFile.url}
                  download={previewFile.name}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex items-center gap-1.5 px-4 py-2 rounded-xl bg-gradient-to-r from-[#FF7A00] to-[#FF9500] text-white font-bold text-xs hover:shadow-[0_0_15px_rgba(255,122,0,0.4)] transition-all"
                >
                  <Download className="w-3.5 h-3.5" />
                  <span>Download / Open</span>
                </a>
              </div>
            </div>
          </div>
        )}
      </div>
    );
  }

  // ==========================================
  // VIEW 2: PERSONAL USER DASHBOARD (Normal users)
  // ==========================================
  return (
    <div className="space-y-6 pb-16 animate-in fade-in duration-300">
      {/* User Welcome Card */}
      <div className="rounded-2xl bg-gradient-to-r from-[#008CFF]/15 via-[#041426] to-[#020817] border border-white/10 p-5 shadow-xl">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div className="flex items-center gap-4">
            <img
              src={currentUser.avatar}
              alt={currentUser.displayName}
              className="w-14 h-14 rounded-2xl object-cover border-2 border-[#008CFF]/50 shadow-lg"
            />
            <div>
              <div className="flex items-center gap-2">
                <h1 className="text-xl sm:text-2xl font-black text-white font-['Space_Grotesk']">
                  Welcome back, {currentUser.displayName}!
                </h1>
                <span className="px-2 py-0.5 rounded-full bg-[#008CFF]/20 text-[#00B7FF] text-[10px] font-bold border border-[#008CFF]/30">
                  {currentUser.role}
                </span>
              </div>
              <p className="text-xs text-[#B8C7D9] mt-0.5">
                Personal Dashboard • Connected as <span className="font-mono text-white">{currentUser.email}</span>
              </p>
              <div className="flex items-center gap-3 text-[11px] text-white/50 mt-1.5">
                <span className="flex items-center gap-1">
                  <Calendar className="w-3 h-3 text-[#FF9500]" />
                  Joined: {formatCreationDate(currentUser.createdAt)}
                </span>
                <span>•</span>
                <span className="flex items-center gap-1">
                  <Sparkles className="w-3 h-3 text-[#00B7FF]" />
                  Level {currentUser.level} ({currentUser.xp} XP)
                </span>
              </div>
            </div>
          </div>

          <button
            onClick={handleRefresh}
            disabled={isRefreshing}
            className="flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-white/5 hover:bg-white/10 text-white text-xs font-semibold border border-white/10 self-start sm:self-auto transition-all"
          >
            <RefreshCw className={`w-3.5 h-3.5 text-[#00B7FF] ${isRefreshing ? 'animate-spin' : ''}`} />
            <span>Sync</span>
          </button>
        </div>
      </div>

      {/* Personal Uploads Section */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Upload Zone */}
        <div className="lg:col-span-5 space-y-4">
          <div className="rounded-2xl bg-[#041426]/90 border border-white/10 p-5 backdrop-blur-xl shadow-xl">
            <h2 className="text-base font-bold text-white flex items-center gap-2 pb-3 border-b border-white/10">
              <Upload className="w-4 h-4 text-[#FF7A00]" />
              Upload New File
            </h2>

            {/* Category Selector */}
            <div className="mt-3 space-y-1.5">
              <label className="text-[11px] font-semibold text-white/70">Category</label>
              <div className="grid grid-cols-3 gap-1.5">
                {(['media', 'post', 'document'] as const).map(cat => (
                  <button
                    key={cat}
                    onClick={() => setUploadCategory(cat)}
                    className={`py-1.5 px-2 rounded-xl text-xs font-bold capitalize transition-all ${
                      uploadCategory === cat
                        ? 'bg-[#FF7A00] text-white shadow-md shadow-[#FF7A00]/30'
                        : 'bg-white/5 text-white/60 hover:bg-white/10'
                    }`}
                  >
                    {cat}
                  </button>
                ))}
              </div>
            </div>

            {/* Drag and Drop Box */}
            <div
              onDragOver={e => {
                e.preventDefault();
                setDragActive(true);
              }}
              onDragLeave={() => setDragActive(false)}
              onDrop={e => {
                e.preventDefault();
                setDragActive(false);
                if (e.dataTransfer.files && e.dataTransfer.files[0]) {
                  handleFileUpload(e.dataTransfer.files[0]);
                }
              }}
              className={`mt-4 border-2 border-dashed rounded-2xl p-6 text-center transition-all ${
                dragActive
                  ? 'border-[#FF7A00] bg-[#FF7A00]/10 scale-[1.01]'
                  : 'border-white/15 hover:border-white/30 bg-black/20'
              }`}
            >
              <input
                type="file"
                id="personal-dashboard-file-input"
                className="hidden"
                onChange={e => {
                  if (e.target.files && e.target.files[0]) {
                    handleFileUpload(e.target.files[0]);
                  }
                }}
              />

              <div className="w-12 h-12 rounded-2xl bg-white/5 border border-white/10 flex items-center justify-center mx-auto text-[#FF7A00] mb-3">
                <Upload className={`w-6 h-6 ${isUploading ? 'animate-bounce' : ''}`} />
              </div>

              <p className="text-xs font-bold text-white">
                {isUploading ? 'Uploading file to Firestore...' : 'Drag & drop your file here'}
              </p>
              <p className="text-[11px] text-white/40 mt-1">
                Supports images (PNG, JPG, WebP), archives, documents up to 25MB
              </p>

              <label
                htmlFor="personal-dashboard-file-input"
                className="mt-4 inline-flex items-center gap-1.5 px-4 py-2 rounded-xl bg-gradient-to-r from-[#FF7A00] to-[#FF9500] text-white text-xs font-bold cursor-pointer hover:shadow-[0_0_15px_rgba(255,122,0,0.4)] transition-all active:scale-95"
              >
                <Plus className="w-3.5 h-3.5" />
                <span>Browse Files</span>
              </label>
            </div>
          </div>
        </div>

        {/* My Uploaded Files List */}
        <div className="lg:col-span-7 space-y-4">
          <div className="rounded-2xl bg-[#041426]/90 border border-white/10 p-5 backdrop-blur-xl shadow-xl">
            <div className="flex items-center justify-between pb-3 border-b border-white/10">
              <div>
                <h2 className="text-base font-bold text-white flex items-center gap-2">
                  <FolderOpen className="w-4 h-4 text-[#00B7FF]" />
                  My Uploaded Files ({personalFiles.length})
                </h2>
                <p className="text-xs text-[#B8C7D9]">
                  Files uploaded by your account. Private and locked to your UID.
                </p>
              </div>

              {isLoadingPersonalFiles && (
                <RefreshCw className="w-4 h-4 text-[#00B7FF] animate-spin" />
              )}
            </div>

            {isLoadingPersonalFiles ? (
              <div className="py-12 text-center text-xs text-[#B8C7D9]">
                <RefreshCw className="w-6 h-6 text-[#00B7FF] animate-spin mx-auto mb-2" />
                Loading your files...
              </div>
            ) : personalFiles.length === 0 ? (
              <div className="py-12 text-center text-xs text-[#B8C7D9] space-y-2">
                <FolderOpen className="w-8 h-8 text-white/20 mx-auto" />
                <p className="font-bold text-white">No files uploaded yet</p>
                <p className="text-[11px] text-white/50">Upload an image or document using the form on the left.</p>
              </div>
            ) : (
              <div className="divide-y divide-white/5 mt-2 max-h-[480px] overflow-y-auto pr-1">
                {personalFiles.map(file => (
                  <div
                    key={file.id}
                    className="py-3 px-2 flex items-center justify-between gap-3 hover:bg-white/5 rounded-xl transition-colors group"
                  >
                    <div className="flex items-center gap-3 min-w-0 flex-1">
                      <div className="w-10 h-10 rounded-lg bg-black/40 border border-white/10 overflow-hidden flex items-center justify-center flex-shrink-0">
                        {file.url && (file.type?.startsWith('image/') || file.name.match(/\.(jpg|jpeg|png|webp|gif)$/i)) ? (
                          <img src={file.url} alt={file.name} className="w-full h-full object-cover" />
                        ) : (
                          getFileIcon(file.type, file.name)
                        )}
                      </div>

                      <div className="min-w-0 flex-1">
                        <p className="text-xs font-semibold text-white truncate group-hover:text-[#00B7FF] transition-colors">
                          {file.name}
                        </p>
                        <div className="flex items-center gap-2 text-[10px] text-white/50 mt-0.5">
                          <span>{file.sizeFormatted || 'Unknown size'}</span>
                          <span>•</span>
                          <span>{formatCreationDate(file.createdAt)}</span>
                        </div>
                      </div>
                    </div>

                    <div className="flex items-center gap-1.5 flex-shrink-0">
                      <a
                        href={file.url}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="p-1.5 rounded-lg bg-white/5 hover:bg-white/10 text-[#00B7FF] transition-colors"
                        title="Open File"
                      >
                        <ExternalLink className="w-3.5 h-3.5" />
                      </a>
                      <button
                        onClick={() => handleDeleteFile(currentUser.id, file.id)}
                        className="p-1.5 rounded-lg bg-white/5 hover:bg-red-500/20 text-white/40 hover:text-red-400 transition-colors"
                        title="Delete File"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
