import React from 'react';
import {
  MessageSquare,
  Users,
  Calendar,
  Sparkles,
  ExternalLink,
  Volume2,
  Hash,
  ShieldAlert,
  Crown,
  Radio,
} from 'lucide-react';
import { useStore } from '../context/StoreContext';

export const DiscordPage: React.FC = () => {
  const { discordChannels, discordEvents, triggerConfetti } = useStore();

  const textChannels = discordChannels.filter(c => c.type === 'text');
  const voiceChannels = discordChannels.filter(c => c.type === 'voice');

  return (
    <div className="space-y-8 animate-in fade-in duration-300">
      {/* DISCORD BRAND HERO BANNER */}
      <div className="relative rounded-3xl overflow-hidden bg-[#041426] border border-[#5865F2]/40 shadow-2xl p-6 sm:p-8">
        <div className="absolute top-0 right-0 w-96 h-96 bg-[#5865F2]/15 rounded-full blur-3xl pointer-events-none" />

        <div className="relative z-10 flex flex-col md:flex-row md:items-center justify-between gap-5">
          <div className="flex items-center gap-4">
            <div className="w-16 h-16 sm:w-20 sm:h-20 rounded-2xl bg-[#5865F2] text-white flex items-center justify-center shadow-[0_0_25px_rgba(88,101,242,0.5)] flex-shrink-0">
              <svg viewBox="0 0 24 24" fill="currentColor" className="w-10 h-10">
                <path d="M20.317 4.37a19.791 19.791 0 0 0-4.885-1.515.074.074 0 0 0-.079.037c-.21.375-.444.864-.608 1.25a18.27 18.27 0 0 0-5.487 0 12.64 12.64 0 0 0-.617-1.25.077.077 0 0 0-.079-.037A19.736 19.736 0 0 0 3.677 4.37a.07.07 0 0 0-.032.027C.533 9.046-.32 13.58.099 18.057a.082.082 0 0 0 .031.057 19.9 19.9 0 0 0 5.993 3.03.078.078 0 0 0 .084-.028c.462-.63.874-1.295 1.226-1.994.021-.041.001-.09-.041-.106a13.107 13.107 0 0 1-1.872-.892.077.077 0 0 1-.008-.128 10.2 10.2 0 0 0 .372-.292.074.074 0 0 1 .077-.01c3.929 1.793 8.18 1.793 12.061 0a.074.074 0 0 1 .078.01c.12.098.246.198.373.292a.077.077 0 0 1-.006.127 12.299 12.299 0 0 1-1.873.893.077.077 0 0 0-.041.107c.36.698.772 1.362 1.225 1.993a.076.076 0 0 0 .084.028 19.839 19.839 0 0 0 6.002-3.03.077.077 0 0 0 .032-.054c.5-5.177-.838-9.674-3.549-13.66a.061.061 0 0 0-.031-.028zM8.02 15.33c-1.183 0-2.157-1.085-2.157-2.419 0-1.333.956-2.419 2.157-2.419 1.21 0 2.176 1.096 2.157 2.42 0 1.333-.956 2.418-2.157 2.418zm7.975 0c-1.183 0-2.157-1.085-2.157-2.419 0-1.333.955-2.419 2.157-2.419 1.21 0 2.176 1.096 2.157 2.42 0 1.333-.946 2.418-2.157 2.418z" />
              </svg>
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h1 className="text-2xl sm:text-3xl font-black uppercase text-white font-['Space_Grotesk'] tracking-tight">
                  Sultan Gaming Discord
                </h1>
                <span className="px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-[#5865F2] text-white">
                  PARTNER
                </span>
              </div>
              <p className="text-xs text-[#B8C7D9] mt-0.5 flex items-center gap-3">
                <span className="flex items-center gap-1">
                  <span className="w-2 h-2 rounded-full bg-[#53FC18]" />
                  1,480 Online
                </span>
                <span>•</span>
                <span>5,200+ Total Members</span>
              </p>
            </div>
          </div>

          <a
            href="https://discord.gg"
            target="_blank"
            rel="noreferrer"
            onClick={triggerConfetti}
            className="flex items-center gap-2 px-6 py-3 rounded-full bg-[#5865F2] hover:bg-[#4752C4] text-white font-bold text-xs sm:text-sm tracking-wide shadow-[0_0_20px_rgba(88,101,242,0.5)] hover:scale-105 active:scale-95 transition-all self-start md:self-auto"
          >
            <span>Join Sultan Discord</span>
            <ExternalLink className="w-4 h-4" />
          </a>
        </div>
      </div>

      {/* DISCORD CHANNELS & EVENTS GRID */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left: Channels Directory (7 Cols) */}
        <div className="lg:col-span-7 space-y-4">
          <div className="rounded-3xl bg-[#041426]/90 border border-white/10 p-5 backdrop-blur-xl shadow-xl space-y-4">
            <h3 className="text-sm font-bold uppercase tracking-wider text-[#5865F2] font-['Space_Grotesk'] flex items-center gap-2">
              <Hash className="w-4 h-4" />
              <span>Official Channel Directory</span>
            </h3>

            {/* Text Channels */}
            <div className="space-y-1.5">
              <div className="text-[11px] font-bold text-white/50 uppercase tracking-wider px-2">
                TEXT CHANNELS
              </div>
              {textChannels.map(ch => (
                <div
                  key={ch.id}
                  className="flex items-center justify-between p-2.5 rounded-xl bg-white/5 hover:bg-white/10 border border-white/5 transition-colors group"
                >
                  <div className="flex items-center gap-2">
                    <Hash className="w-4 h-4 text-[#5865F2]" />
                    <div>
                      <p className="text-xs font-bold text-white group-hover:text-[#5865F2] transition-colors">
                        {ch.name}
                      </p>
                      <p className="text-[10px] text-[#B8C7D9]">{ch.description}</p>
                    </div>
                  </div>
                  <span className="text-[10px] px-2 py-0.5 rounded bg-black/40 text-white/50">
                    {ch.category}
                  </span>
                </div>
              ))}
            </div>

            {/* Voice Channels */}
            <div className="space-y-1.5 pt-2 border-t border-white/5">
              <div className="text-[11px] font-bold text-white/50 uppercase tracking-wider px-2">
                VOICE CHANNELS & STAGES
              </div>
              {voiceChannels.map(ch => (
                <div
                  key={ch.id}
                  className="flex items-center justify-between p-2.5 rounded-xl bg-white/5 hover:bg-white/10 border border-white/5 transition-colors group"
                >
                  <div className="flex items-center gap-2">
                    <Volume2 className="w-4 h-4 text-[#53FC18]" />
                    <span className="text-xs font-bold text-white group-hover:text-[#53FC18]">
                      {ch.name}
                    </span>
                  </div>
                  <span className="text-[10px] px-2 py-0.5 rounded bg-[#53FC18]/20 text-[#53FC18] font-mono font-bold">
                    Connected
                  </span>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Right: Upcoming Events (5 Cols) */}
        <div className="lg:col-span-5 space-y-4">
          <div className="rounded-3xl bg-[#041426]/90 border border-white/10 p-5 backdrop-blur-xl shadow-xl space-y-4">
            <h3 className="text-sm font-bold uppercase tracking-wider text-[#FF9500] font-['Space_Grotesk'] flex items-center gap-2">
              <Calendar className="w-4 h-4" />
              <span>Upcoming Community Events</span>
            </h3>

            <div className="space-y-3">
              {discordEvents.map(evt => (
                <div
                  key={evt.id}
                  className="p-4 rounded-2xl bg-white/5 border border-white/10 hover:border-[#FF7A00]/40 transition-all space-y-2"
                >
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-bold text-[#FF9500]">{evt.title}</span>
                    <span className="text-[10px] px-2 py-0.5 rounded-full bg-[#FF7A00]/20 text-[#FF9500] font-mono">
                      {evt.date}
                    </span>
                  </div>
                  <p className="text-xs text-[#B8C7D9]">{evt.description}</p>
                  <div className="pt-2 flex items-center justify-between text-[11px] text-white/50 border-t border-white/5">
                    <span>Hosted on Discord Stage</span>
                    <span className="text-[#00B7FF] font-medium">Set Reminder 🔔</span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
