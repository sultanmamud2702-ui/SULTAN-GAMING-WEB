import React, { useState } from 'react';
import {
  HelpCircle,
  Search,
  ChevronDown,
  MessageSquare,
  Sparkles,
  ThumbsUp,
  ExternalLink,
  Plus,
  Trash2,
  Edit2,
} from 'lucide-react';
import { useStore } from '../context/StoreContext';
import { FAQItem } from '../types';

export const FAQPage: React.FC = () => {
  const { faqs, setCurrentPage, isAdmin, addFAQ, deleteFAQ, triggerConfetti } = useStore();
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('all');
  const [openIds, setOpenIds] = useState<Record<string, boolean>>({
    [faqs[0]?.id || 'faq-1']: true,
  });
  const [helpfulFeedback, setHelpfulFeedback] = useState<Record<string, boolean>>({});

  const categories = ['all', 'General', 'Streams & Schedule', 'Mods & Servers', 'Hardware & Setup', 'Giveaways'];

  const toggleAccordion = (id: string) => {
    setOpenIds(prev => ({
      ...prev,
      [id]: !prev[id],
    }));
  };

  const handleThumbsUp = (id: string, e: React.MouseEvent) => {
    e.stopPropagation();
    setHelpfulFeedback(prev => ({ ...prev, [id]: true }));
    triggerConfetti();
  };

  const filteredFaqs = faqs.filter(faq => {
    const matchesCat =
      selectedCategory === 'all' ||
      faq.category.toLowerCase() === selectedCategory.toLowerCase();
    const matchesSearch =
      !searchQuery.trim() ||
      faq.question.toLowerCase().includes(searchQuery.toLowerCase()) ||
      faq.answer.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesCat && matchesSearch;
  });

  return (
    <div className="space-y-8 animate-in fade-in duration-300">
      {/* Header Banner */}
      <div className="relative rounded-3xl overflow-hidden bg-gradient-to-r from-[#041426] via-[#061B2E] to-[#020817] border border-white/10 p-6 sm:p-8 shadow-xl">
        <div className="absolute top-0 right-0 w-96 h-96 bg-[#00B7FF]/10 rounded-full blur-3xl pointer-events-none" />
        <div className="relative z-10 max-w-2xl">
          <div className="flex items-center gap-2 text-[#00B7FF] text-xs font-bold uppercase tracking-wider mb-2">
            <HelpCircle className="w-4 h-4" />
            <span>KNOWLEDGE BASE & SUPPORT</span>
          </div>
          <h1 className="text-3xl sm:text-4xl font-black uppercase text-white font-['Space_Grotesk'] tracking-tight">
            Frequently Asked Questions
          </h1>
          <p className="text-sm text-[#B8C7D9] mt-2">
            Find answers to common questions about stream schedules, joining Sultan's GTA sessions,
            our Minecraft SMP server, hardware recommendations, and giveaway eligibility.
          </p>
        </div>
      </div>

      {/* Search & Category Filter Bar */}
      <div className="space-y-3">
        <div className="relative">
          <Search className="w-4 h-4 text-[#FF9500] absolute left-3.5 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            id="faq-search-input"
            value={searchQuery}
            onChange={e => setSearchQuery(e.target.value)}
            placeholder="Search questions (e.g. Schedule, GTA 5, Discord, Specs, Server IP)..."
            className="w-full bg-[#041426]/90 border border-white/10 rounded-2xl pl-10 pr-4 py-3 text-xs sm:text-sm text-white placeholder-white/40 focus:outline-none focus:border-[#FF7A00]"
          />
        </div>

        {/* Category Pills */}
        <div className="flex items-center gap-2 overflow-x-auto pb-1 scrollbar-none">
          {categories.map(cat => (
            <button
              key={cat}
              onClick={() => setSelectedCategory(cat)}
              className={`px-4 py-2 rounded-full text-xs font-bold tracking-wide whitespace-nowrap transition-all ${
                selectedCategory === cat
                  ? 'bg-gradient-to-r from-[#FF7A00] to-[#FF9500] text-white shadow-[0_0_15px_rgba(255,122,0,0.4)]'
                  : 'bg-[#041426]/80 text-[#B8C7D9] hover:text-white hover:bg-white/10 border border-white/10'
              }`}
            >
              {cat === 'all' ? 'All Questions' : cat}
            </button>
          ))}
        </div>
      </div>

      {/* Accordion FAQ List */}
      <div className="space-y-3">
        {filteredFaqs.length === 0 ? (
          <div className="py-12 text-center rounded-3xl bg-[#041426]/50 border border-white/10 p-6">
            <HelpCircle className="w-10 h-10 text-white/30 mx-auto mb-2" />
            <p className="text-white font-bold text-sm">No FAQs found matching your query.</p>
            <p className="text-xs text-[#B8C7D9] mt-1">Try clearing your search term or asking in Discord.</p>
          </div>
        ) : (
          filteredFaqs.map(faq => {
            const isOpen = !!openIds[faq.id];
            const isHelpful = !!helpfulFeedback[faq.id];

            return (
              <div
                key={faq.id}
                id={`faq-item-${faq.id}`}
                className={`rounded-2xl border transition-all duration-200 overflow-hidden ${
                  isOpen
                    ? 'bg-[#041426]/90 border-[#FF7A00]/50 shadow-[0_0_20px_rgba(255,122,0,0.15)]'
                    : 'bg-[#041426]/70 border-white/10 hover:border-white/20'
                }`}
              >
                {/* Question Row */}
                <button
                  onClick={() => toggleAccordion(faq.id)}
                  className="w-full flex items-center justify-between p-4 sm:p-5 text-left gap-4"
                >
                  <div className="flex items-center gap-3">
                    <div
                      className={`w-7 h-7 rounded-lg flex items-center justify-center text-xs font-bold transition-colors flex-shrink-0 ${
                        isOpen
                          ? 'bg-[#FF7A00] text-white'
                          : 'bg-white/10 text-white/70'
                      }`}
                    >
                      Q
                    </div>
                    <span className="text-sm sm:text-base font-bold text-white">
                      {faq.question}
                    </span>
                  </div>

                  <div className="flex items-center gap-2 flex-shrink-0">
                    <span className="hidden sm:inline text-[10px] px-2.5 py-1 rounded-full bg-white/5 border border-white/10 text-[#00B7FF] font-medium">
                      {faq.category}
                    </span>
                    <ChevronDown
                      className={`w-4 h-4 text-white/60 transition-transform duration-300 ${
                        isOpen ? 'rotate-180 text-[#FF7A00]' : ''
                      }`}
                    />
                  </div>
                </button>

                {/* Answer Content */}
                {isOpen && (
                  <div className="px-5 pb-5 pt-1 border-t border-white/5 text-xs sm:text-sm text-[#B8C7D9] leading-relaxed space-y-3 animate-in fade-in duration-200">
                    <p className="whitespace-pre-line">{faq.answer}</p>

                    {/* Feedback & Admin bar */}
                    <div className="flex items-center justify-between pt-2 border-t border-white/5 text-xs">
                      <div className="flex items-center gap-2">
                        <span className="text-[11px] text-white/40">Was this helpful?</span>
                        <button
                          onClick={e => handleThumbsUp(faq.id, e)}
                          disabled={isHelpful}
                          className={`flex items-center gap-1 px-2.5 py-1 rounded-lg border text-[11px] transition-colors ${
                            isHelpful
                              ? 'bg-[#53FC18]/20 border-[#53FC18] text-[#53FC18]'
                              : 'bg-white/5 border-white/10 text-white/70 hover:text-white'
                          }`}
                        >
                          <ThumbsUp className="w-3 h-3" />
                          <span>{isHelpful ? 'Helpful!' : 'Yes'}</span>
                        </button>
                      </div>

                      {isAdmin && (
                        <button
                          onClick={() => deleteFAQ(faq.id)}
                          className="text-red-400 hover:text-red-300 text-[11px] flex items-center gap-1"
                        >
                          <Trash2 className="w-3 h-3" /> Delete
                        </button>
                      )}
                    </div>
                  </div>
                )}
              </div>
            );
          })
        )}
      </div>

      {/* DISCORD COMMUNITY SUPPORT BANNER */}
      <div className="p-6 sm:p-8 rounded-3xl bg-gradient-to-r from-[#5865F2]/20 via-[#061B2E] to-[#041426] border border-[#5865F2]/40 backdrop-blur-xl flex flex-col sm:flex-row items-center justify-between gap-5 shadow-2xl">
        <div className="space-y-1 text-center sm:text-left">
          <span className="text-xs font-bold text-[#5865F2] uppercase tracking-wider flex items-center justify-center sm:justify-start gap-1.5">
            <MessageSquare className="w-4 h-4" />
            <span>24/7 Squad Support</span>
          </span>
          <h3 className="text-xl sm:text-2xl font-black text-white font-['Space_Grotesk'] uppercase">
            Still Have Questions?
          </h3>
          <p className="text-xs text-[#B8C7D9] max-w-lg">
            Join the official Sultan Gaming Discord. Connect with our community moderators,
            organize multiplayer parties, and get instant answers.
          </p>
        </div>

        <button
          id="faq-join-discord-cta-btn"
          onClick={() => setCurrentPage('discord')}
          className="px-6 py-3 rounded-full bg-[#5865F2] hover:bg-[#4752C4] text-white font-bold text-xs tracking-wide shadow-[0_0_20px_rgba(88,101,242,0.4)] flex items-center gap-2 hover:scale-105 active:scale-95 transition-all flex-shrink-0"
        >
          <span>Join Sultan Discord</span>
          <ExternalLink className="w-4 h-4" />
        </button>
      </div>
    </div>
  );
};
