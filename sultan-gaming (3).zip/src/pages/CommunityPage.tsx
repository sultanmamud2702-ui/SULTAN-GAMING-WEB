import React, { useState, useRef } from 'react';
import {
  Users,
  Heart,
  MessageSquare,
  Share2,
  Image as ImageIcon,
  BarChart2,
  Send,
  Plus,
  Trash2,
  Sparkles,
  CheckCircle2,
  Crown,
  Flame,
  Upload,
  X,
  Loader2,
} from 'lucide-react';
import { useStore } from '../context/StoreContext';
import { CommunityPost } from '../types';

export const CommunityPage: React.FC = () => {
  const {
    posts,
    addPost,
    toggleLikePost,
    votePoll,
    deletePost,
    games,
    isAdmin,
    triggerConfetti,
    uploadImage,
    currentUser,
  } = useStore();

  const [selectedFilter, setSelectedFilter] = useState<string>('all');
  const [content, setContent] = useState('');
  const [selectedGameTag, setSelectedGameTag] = useState(games[0]?.title || 'GTA 5');
  const [showPollComposer, setShowPollComposer] = useState(false);
  const [pollQuestion, setPollQuestion] = useState('');
  const [pollOptions, setPollOptions] = useState<string[]>(['', '']);
  const [imageUrl, setImageUrl] = useState('');
  const [showImageInput, setShowImageInput] = useState(false);
  const [isUploadingImage, setIsUploadingImage] = useState(false);
  const [imageUploadError, setImageUploadError] = useState<string | null>(null);
  const [isDragOver, setIsDragOver] = useState(false);
  const postFileInputRef = useRef<HTMLInputElement>(null);
  const [commentInputs, setCommentInputs] = useState<Record<string, string>>({});
  const [openComments, setOpenComments] = useState<Record<string, boolean>>({});

  const processPostImage = async (file: File) => {
    if (!file.type.startsWith('image/')) {
      setImageUploadError('Please select a valid image (PNG, JPG, WEBP, GIF).');
      return;
    }
    if (file.size > 10 * 1024 * 1024) {
      setImageUploadError('Image size must be under 10MB.');
      return;
    }

    setImageUploadError(null);
    setIsUploadingImage(true);
    setShowImageInput(true);

    const reader = new FileReader();
    reader.onload = async (e) => {
      const base64 = e.target?.result as string;
      try {
        const uploadRes = await uploadImage(base64, file.name, 'posts');
        if (uploadRes.success && uploadRes.url) {
          setImageUrl(uploadRes.url);
        } else {
          setImageUrl(base64);
        }
      } catch (err) {
        setImageUrl(base64);
      } finally {
        setIsUploadingImage(false);
      }
    };
    reader.readAsDataURL(file);
  };

  // Filter posts
  const filteredPosts = posts.filter(post => {
    if (selectedFilter === 'all') return true;
    return post.gameTag.toLowerCase().includes(selectedFilter.toLowerCase());
  });

  const handleAddPollOption = () => {
    if (pollOptions.length < 5) {
      setPollOptions([...pollOptions, '']);
    }
  };

  const handlePollOptionChange = (index: number, val: string) => {
    const updated = [...pollOptions];
    updated[index] = val;
    setPollOptions(updated);
  };

  const handleSubmitPost = (e: React.FormEvent) => {
    e.preventDefault();
    if (!content.trim() && !imageUrl.trim() && !pollQuestion.trim()) return;

    const validPollOptions = pollOptions.filter(o => o.trim().length > 0);

    addPost({
      gameTag: selectedGameTag,
      content: content.trim(),
      images: imageUrl.trim() ? [imageUrl.trim()] : undefined,
      poll:
        showPollComposer && pollQuestion.trim() && validPollOptions.length >= 2
          ? {
              question: pollQuestion.trim(),
              options: validPollOptions,
            }
          : undefined,
    });

    setContent('');
    setImageUrl('');
    setShowImageInput(false);
    setShowPollComposer(false);
    setPollQuestion('');
    setPollOptions(['', '']);
  };

  const filterTabs = [
    { id: 'all', label: `All (${posts.length})` },
    ...games.map(g => ({
      id: g.title.toLowerCase(),
      label: `${g.title} (${posts.filter(p => p.gameTag.toLowerCase().includes(g.title.toLowerCase())).length})`,
    })),
  ];

  return (
    <div className="space-y-6 animate-in fade-in duration-300">
      {/* Header Banner */}
      <div className="relative rounded-3xl overflow-hidden bg-gradient-to-r from-[#041426] via-[#061B2E] to-[#020817] border border-white/10 p-6 sm:p-8 shadow-xl">
        <div className="absolute top-0 right-0 w-96 h-96 bg-[#0066FF]/10 rounded-full blur-3xl pointer-events-none" />
        <div className="relative z-10 max-w-2xl">
          <div className="flex items-center gap-2 text-[#FF9500] text-xs font-bold uppercase tracking-wider mb-2">
            <Users className="w-4 h-4" />
            <span>SULTAN SQUAD COMMUNITY</span>
          </div>
          <h1 className="text-3xl sm:text-4xl font-black uppercase text-white font-['Space_Grotesk'] tracking-tight">
            Community Hub & Feed
          </h1>
          <p className="text-sm text-[#B8C7D9] mt-2">
            Share your gameplay clips, participate in creator polls, discuss upcoming stream events,
            and interact directly with Sultan and the squad.
          </p>
        </div>
      </div>

      {/* Filter Tabs */}
      <div className="flex items-center gap-2 overflow-x-auto pb-1 scrollbar-none">
        {filterTabs.map(tab => (
          <button
            key={tab.id}
            onClick={() => setSelectedFilter(tab.id)}
            className={`px-4 py-2 rounded-full text-xs font-bold tracking-wide whitespace-nowrap transition-all ${
              selectedFilter === tab.id
                ? 'bg-gradient-to-r from-[#FF7A00] to-[#FF9500] text-white shadow-[0_0_15px_rgba(255,122,0,0.4)]'
                : 'bg-[#041426]/80 text-[#B8C7D9] hover:text-white hover:bg-white/10 border border-white/10'
            }`}
          >
            {tab.label}
          </button>
        ))}
      </div>

      {/* Post Composer Card */}
      <div className="rounded-3xl bg-[#041426]/90 border border-white/10 p-5 backdrop-blur-xl shadow-xl space-y-4">
        <form onSubmit={handleSubmitPost} className="space-y-3">
          <div className="flex items-start gap-3">
            <div className="w-10 h-10 rounded-full bg-gradient-to-br from-[#FF7A00] to-[#FF9500] p-0.5 flex-shrink-0">
              <img
                src={currentUser?.avatar || "https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?auto=format&fit=crop&w=200&q=80"}
                alt={currentUser?.displayName || "Your Avatar"}
                className="w-full h-full object-cover rounded-full"
              />
            </div>

            <div className="flex-1 space-y-2">
              <textarea
                id="community-composer-textarea"
                value={content}
                onChange={e => setContent(e.target.value)}
                placeholder="Post something to Sultan Community (heist clips, setups, questions)..."
                rows={3}
                className="w-full bg-white/5 border border-white/10 rounded-2xl p-3.5 text-sm text-white placeholder-white/40 focus:outline-none focus:border-[#FF7A00]/70 resize-none"
              />

              {/* Image Input field with File Upload & Drag-and-Drop */}
              {showImageInput && (
                <div className="space-y-2 p-3 rounded-2xl bg-white/5 border border-white/10">
                  <div
                    onDragOver={(e) => {
                      e.preventDefault();
                      setIsDragOver(true);
                    }}
                    onDragLeave={() => setIsDragOver(false)}
                    onDrop={(e) => {
                      e.preventDefault();
                      setIsDragOver(false);
                      const file = e.dataTransfer.files?.[0];
                      if (file) processPostImage(file);
                    }}
                    onClick={() => postFileInputRef.current?.click()}
                    className={`cursor-pointer border-2 border-dashed rounded-xl p-3 text-center transition-all ${
                      isDragOver
                        ? 'border-[#FF7A00] bg-[#FF7A00]/10'
                        : 'border-white/15 bg-black/20 hover:border-white/30'
                    }`}
                  >
                    <input
                      ref={postFileInputRef}
                      type="file"
                      accept="image/png,image/jpeg,image/jpg,image/webp,image/gif"
                      className="hidden"
                      onChange={(e) => {
                        const file = e.target.files?.[0];
                        if (file) processPostImage(file);
                      }}
                    />

                    <div className="flex items-center justify-center gap-3">
                      {imageUrl ? (
                        <div className="relative group">
                          <img
                            src={imageUrl}
                            alt="Uploaded post media"
                            className="w-16 h-16 rounded-lg object-cover border border-white/20 shadow-md"
                          />
                          <button
                            type="button"
                            onClick={(e) => {
                              e.stopPropagation();
                              setImageUrl('');
                            }}
                            className="absolute -top-1.5 -right-1.5 p-1 rounded-full bg-red-600 hover:bg-red-500 text-white shadow"
                          >
                            <X className="w-3 h-3" />
                          </button>
                        </div>
                      ) : (
                        <div className="w-10 h-10 rounded-xl bg-white/10 flex items-center justify-center text-[#00B7FF]">
                          <Upload className="w-5 h-5" />
                        </div>
                      )}

                      <div className="text-left flex-1 min-w-0">
                        <p className="text-xs font-semibold text-white flex items-center gap-1.5">
                          {isUploadingImage ? (
                            <>
                              <Loader2 className="w-3.5 h-3.5 text-[#FF7A00] animate-spin" />
                              <span>Uploading screenshot/image...</span>
                            </>
                          ) : (
                            <span>{imageUrl ? 'Change image or drop new file' : 'Click to select image or drag & drop'}</span>
                          )}
                        </p>
                        <p className="text-[10px] text-[#B8C7D9]">Supports PNG, JPG, GIF, WebP up to 10MB</p>
                      </div>
                    </div>
                  </div>

                  {imageUploadError && (
                    <p className="text-[11px] text-red-400">{imageUploadError}</p>
                  )}

                  <div className="flex items-center gap-2 pt-1">
                    <input
                      type="url"
                      value={imageUrl}
                      onChange={e => setImageUrl(e.target.value)}
                      placeholder="Or enter direct image URL (https://...)"
                      className="flex-1 bg-black/40 border border-white/10 rounded-xl px-3 py-1.5 text-xs text-white placeholder-white/30 focus:outline-none focus:border-[#FF7A00]"
                    />
                    {imageUrl && (
                      <button
                        type="button"
                        onClick={() => setImageUrl('')}
                        className="text-xs text-white/50 hover:text-red-400 px-2"
                      >
                        Clear
                      </button>
                    )}
                  </div>
                </div>
              )}

              {/* Poll Composer Box */}
              {showPollComposer && (
                <div className="p-4 rounded-2xl bg-white/5 border border-white/10 space-y-2.5">
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-bold text-[#FF9500] uppercase tracking-wider flex items-center gap-1.5">
                      <BarChart2 className="w-3.5 h-3.5" />
                      Create Community Poll
                    </span>
                    <button
                      type="button"
                      onClick={() => setShowPollComposer(false)}
                      className="text-xs text-white/50 hover:text-white"
                    >
                      Cancel Poll
                    </button>
                  </div>
                  <input
                    type="text"
                    value={pollQuestion}
                    onChange={e => setPollQuestion(e.target.value)}
                    placeholder="Ask a poll question (e.g. Next stream game?)"
                    className="w-full bg-white/5 border border-white/10 rounded-xl px-3 py-2 text-xs text-white placeholder-white/40 focus:outline-none focus:border-[#FF7A00]"
                  />
                  <div className="space-y-2">
                    {pollOptions.map((opt, idx) => (
                      <input
                        key={idx}
                        type="text"
                        value={opt}
                        onChange={e => handlePollOptionChange(idx, e.target.value)}
                        placeholder={`Option ${idx + 1}`}
                        className="w-full bg-white/5 border border-white/10 rounded-xl px-3 py-1.5 text-xs text-white placeholder-white/40 focus:outline-none"
                      />
                    ))}
                  </div>
                  {pollOptions.length < 5 && (
                    <button
                      type="button"
                      onClick={handleAddPollOption}
                      className="text-xs text-[#00B7FF] hover:underline flex items-center gap-1"
                    >
                      <Plus className="w-3.5 h-3.5" /> Add option
                    </button>
                  )}
                </div>
              )}
            </div>
          </div>

          {/* Bottom Bar: Tags & Action Buttons */}
          <div className="flex flex-wrap items-center justify-between gap-3 pt-2 border-t border-white/10">
            <div className="flex items-center gap-2">
              <span className="text-[11px] text-[#B8C7D9] font-medium">Tag Game:</span>
              <select
                value={selectedGameTag}
                onChange={e => setSelectedGameTag(e.target.value)}
                className="bg-white/5 border border-white/10 rounded-xl px-2.5 py-1 text-xs text-white focus:outline-none focus:border-[#FF7A00]"
              >
                {games.map(g => (
                  <option key={g.id} value={g.title} className="bg-[#041426] text-white">
                    {g.title}
                  </option>
                ))}
                <option value="General" className="bg-[#041426] text-white">
                  General / Off-Topic
                </option>
              </select>

              <button
                type="button"
                onClick={() => setShowImageInput(!showImageInput)}
                className={`p-2 rounded-xl border text-xs transition-colors flex items-center gap-1 ${
                  showImageInput
                    ? 'bg-[#008CFF]/20 border-[#008CFF] text-[#00B7FF]'
                    : 'bg-white/5 border-white/10 text-[#B8C7D9] hover:text-white'
                }`}
                title="Add screenshot"
              >
                <ImageIcon className="w-4 h-4" />
                <span className="hidden sm:inline">Image</span>
              </button>

              <button
                type="button"
                onClick={() => setShowPollComposer(!showPollComposer)}
                className={`p-2 rounded-xl border text-xs transition-colors flex items-center gap-1 ${
                  showPollComposer
                    ? 'bg-[#FF7A00]/20 border-[#FF7A00] text-[#FF9500]'
                    : 'bg-white/5 border-white/10 text-[#B8C7D9] hover:text-white'
                }`}
                title="Create poll"
              >
                <BarChart2 className="w-4 h-4" />
                <span className="hidden sm:inline">Poll</span>
              </button>
            </div>

            <button
              type="submit"
              disabled={!content.trim() && !imageUrl.trim() && !pollQuestion.trim()}
              className="flex items-center gap-2 px-5 py-2 rounded-full bg-gradient-to-r from-[#FF7A00] to-[#FF9500] text-white font-bold text-xs tracking-wide shadow-[0_0_15px_rgba(255,122,0,0.4)] disabled:opacity-50 disabled:cursor-not-allowed hover:scale-105 active:scale-95 transition-all"
            >
              <Send className="w-3.5 h-3.5" />
              <span>Post to Squad</span>
            </button>
          </div>
        </form>
      </div>

      {/* Feed Posts List */}
      <div className="space-y-4">
        {filteredPosts.length === 0 ? (
          <div className="py-16 text-center rounded-3xl bg-[#041426]/50 border border-white/10 p-8">
            <Users className="w-12 h-12 text-white/30 mx-auto mb-3" />
            <p className="text-white font-bold">No community posts yet in this category.</p>
            <p className="text-xs text-[#B8C7D9] mt-1">Be the first to create a post above!</p>
          </div>
        ) : (
          filteredPosts.map(post => {
            const isCommentsOpen = openComments[post.id];
            return (
              <div
                key={post.id}
                id={`community-post-${post.id}`}
                className="rounded-3xl bg-[#041426]/80 border border-white/10 hover:border-white/20 p-5 sm:p-6 backdrop-blur-xl transition-all shadow-xl space-y-4"
              >
                {/* Author Info & Game Tag */}
                <div className="flex items-center justify-between gap-3">
                  <div className="flex items-center gap-3">
                    <div className="relative w-11 h-11 rounded-full overflow-hidden bg-white/10 border border-white/20 flex-shrink-0">
                      <img
                        src={post.author.avatar}
                        alt={post.author.name}
                        className="w-full h-full object-cover"
                      />
                    </div>
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="font-bold text-sm text-white">{post.author.name}</span>
                        {post.author.badge && (
                          <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-[#FF7A00]/20 text-[#FF9500] border border-[#FF7A00]/30 flex items-center gap-1">
                            <Crown className="w-3 h-3" />
                            {post.author.badge}
                          </span>
                        )}
                      </div>
                      <div className="flex items-center gap-2 text-[11px] text-[#B8C7D9]">
                        <span>{post.timestamp}</span>
                        <span>•</span>
                        <span className="text-[#00B7FF] font-medium">#{post.gameTag}</span>
                      </div>
                    </div>
                  </div>

                  {/* Actions / Delete for admin */}
                  <div className="flex items-center gap-2">
                    <span className="px-3 py-1 rounded-full text-[11px] font-semibold bg-white/5 border border-white/10 text-white/80">
                      {post.gameTag}
                    </span>
                    {isAdmin && (
                      <button
                        onClick={() => deletePost(post.id)}
                        className="p-1.5 rounded-lg text-red-400 hover:bg-red-500/20 transition-colors"
                        title="Delete Post"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    )}
                  </div>
                </div>

                {/* Post Content */}
                <p className="text-sm text-[#EAF4FF] leading-relaxed whitespace-pre-line">
                  {post.content}
                </p>

                {/* Attached Images */}
                {post.images && post.images.length > 0 && (
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 rounded-2xl overflow-hidden border border-white/10">
                    {post.images.map((img, idx) => (
                      <div key={idx} className="relative max-h-96 overflow-hidden bg-black/40">
                        <img
                          src={img}
                          alt="Post attachment"
                          className="w-full h-full object-cover hover:scale-105 transition-transform duration-300"
                        />
                      </div>
                    ))}
                  </div>
                )}

                {/* Interactive Poll */}
                {post.poll && (
                  <div className="p-4 rounded-2xl bg-[#061B2E] border border-white/10 space-y-3">
                    <div className="flex items-center justify-between">
                      <h4 className="text-xs font-bold text-white uppercase tracking-wider flex items-center gap-1.5">
                        <BarChart2 className="w-4 h-4 text-[#FF9500]" />
                        {post.poll.question}
                      </h4>
                      <span className="text-[11px] text-[#B8C7D9]">
                        {post.poll.totalVotes} total votes
                      </span>
                    </div>

                    <div className="space-y-2">
                      {post.poll.options.map(option => {
                        const total = post.poll?.totalVotes || 0;
                        const pct = total > 0 ? Math.round((option.votes / total) * 100) : 0;
                        const isSelected = post.poll?.userVotedOptionId === option.id;

                        return (
                          <div
                            key={option.id}
                            onClick={() => votePoll(post.id, option.id)}
                            className={`relative overflow-hidden rounded-xl border p-3 cursor-pointer transition-all ${
                              isSelected
                                ? 'border-[#FF7A00] bg-[#FF7A00]/10'
                                : 'border-white/10 bg-white/5 hover:border-white/20'
                            }`}
                          >
                            {/* Percentage progress bar fill */}
                            <div
                              className="absolute top-0 bottom-0 left-0 bg-gradient-to-r from-[#FF7A00]/30 to-[#FF9500]/20 transition-all duration-500"
                              style={{ width: `${pct}%` }}
                            />
                            <div className="relative z-10 flex items-center justify-between text-xs">
                              <span
                                className={`font-semibold ${
                                  isSelected ? 'text-[#FF9500]' : 'text-white'
                                }`}
                              >
                                {option.text}
                              </span>
                              <span className="font-mono font-bold text-white/80">
                                {pct}% ({option.votes})
                              </span>
                            </div>
                          </div>
                        );
                      })}
                    </div>
                  </div>
                )}

                {/* Likes, Comments & Share Bar */}
                <div className="flex items-center justify-between pt-3 border-t border-white/10 text-xs text-[#B8C7D9]">
                  <div className="flex items-center gap-4">
                    {/* Like button */}
                    <button
                      id={`like-post-btn-${post.id}`}
                      onClick={() => toggleLikePost(post.id)}
                      className={`flex items-center gap-1.5 font-bold transition-all ${
                        post.userLiked
                          ? 'text-[#FF2200] scale-105'
                          : 'hover:text-white'
                      }`}
                    >
                      <Heart
                        className={`w-4 h-4 ${
                          post.userLiked ? 'fill-current text-[#FF2200]' : ''
                        }`}
                      />
                      <span>{post.likes}</span>
                    </button>

                    {/* Comments button */}
                    <button
                      onClick={() =>
                        setOpenComments(prev => ({ ...prev, [post.id]: !prev[post.id] }))
                      }
                      className="flex items-center gap-1.5 hover:text-white transition-colors"
                    >
                      <MessageSquare className="w-4 h-4" />
                      <span>{post.commentsCount} Comments</span>
                    </button>
                  </div>

                  <button
                    onClick={() => {
                      triggerConfetti();
                      navigator.clipboard?.writeText(window.location.href);
                    }}
                    className="flex items-center gap-1 hover:text-white transition-colors"
                  >
                    <Share2 className="w-4 h-4" />
                    <span className="hidden sm:inline">Share</span>
                  </button>
                </div>

                {/* Comments Expand Drawer */}
                {isCommentsOpen && (
                  <div className="pt-3 border-t border-white/5 space-y-3 animate-in fade-in duration-200">
                    <div className="flex items-center gap-2">
                      <input
                        type="text"
                        value={commentInputs[post.id] || ''}
                        onChange={e =>
                          setCommentInputs(prev => ({ ...prev, [post.id]: e.target.value }))
                        }
                        placeholder="Write a comment..."
                        className="flex-1 bg-white/5 border border-white/10 rounded-xl px-3 py-1.5 text-xs text-white placeholder-white/40 focus:outline-none focus:border-[#00B7FF]"
                      />
                      <button
                        onClick={() => {
                          if (commentInputs[post.id]?.trim()) {
                            setCommentInputs(prev => ({ ...prev, [post.id]: '' }));
                            triggerConfetti();
                          }
                        }}
                        className="px-3 py-1.5 rounded-xl bg-[#008CFF] text-white text-xs font-bold hover:bg-[#00B7FF]"
                      >
                        Reply
                      </button>
                    </div>
                  </div>
                )}
              </div>
            );
          })
        )}
      </div>
    </div>
  );
};
