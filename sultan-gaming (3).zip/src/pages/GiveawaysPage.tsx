import React, { useState, useEffect } from 'react';
import {
  Gift,
  Trophy,
  Clock,
  Sparkles,
  CheckCircle2,
  Users,
  Flame,
  ShieldCheck,
  Send,
  Lock,
} from 'lucide-react';
import { useStore } from '../context/StoreContext';
import { Giveaway } from '../types';

export const GiveawaysPage: React.FC = () => {
  const { giveaways, enterGiveaway, triggerConfetti } = useStore();

  const [activeGiveaway, setActiveGiveaway] = useState<Giveaway | null>(
    giveaways.find(g => g.status === 'active') || giveaways[0] || null
  );

  const [showEntryModal, setShowEntryModal] = useState(false);
  const [email, setEmail] = useState('');
  const [gamertag, setGamertag] = useState('');
  const [selectedGiveawayToEnter, setSelectedGiveawayToEnter] = useState<Giveaway | null>(null);

  // Countdown timer state
  const [timeLeft, setTimeLeft] = useState({
    days: 4,
    hours: 18,
    minutes: 42,
    seconds: 15,
  });

  useEffect(() => {
    const timer = setInterval(() => {
      setTimeLeft(prev => {
        if (prev.seconds > 0) return { ...prev, seconds: prev.seconds - 1 };
        if (prev.minutes > 0) return { ...prev, minutes: 59, seconds: 59 };
        if (prev.hours > 0) return { ...prev, hours: prev.hours - 1, minutes: 59, seconds: 59 };
        if (prev.days > 0) return { ...prev, days: prev.days - 1, hours: 23, minutes: 59, seconds: 59 };
        return prev;
      });
    }, 1000);
    return () => clearInterval(timer);
  }, []);

  const handleOpenEntry = (giveaway: Giveaway) => {
    setSelectedGiveawayToEnter(giveaway);
    setShowEntryModal(true);
  };

  const handleSubmitEntry = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedGiveawayToEnter || !email || !gamertag) return;

    enterGiveaway(selectedGiveawayToEnter.id, email, gamertag);
    setShowEntryModal(false);
    setEmail('');
    setGamertag('');
  };

  const activeGiveaways = giveaways.filter(g => g.status === 'active');
  const pastGiveaways = giveaways.filter(g => g.status === 'ended');

  return (
    <div className="space-y-8 animate-in fade-in duration-300">
      {/* Header Banner */}
      <div className="relative rounded-3xl overflow-hidden bg-gradient-to-r from-[#041426] via-[#061B2E] to-[#020817] border border-white/10 p-6 sm:p-8 shadow-xl">
        <div className="absolute top-0 right-0 w-96 h-96 bg-[#FF7A00]/10 rounded-full blur-3xl pointer-events-none" />
        <div className="relative z-10 max-w-2xl">
          <div className="flex items-center gap-2 text-[#FF9500] text-xs font-bold uppercase tracking-wider mb-2">
            <Gift className="w-4 h-4" />
            <span>SULTAN SQUAD REWARDS</span>
          </div>
          <h1 className="text-3xl sm:text-4xl font-black uppercase text-white font-['Space_Grotesk'] tracking-tight">
            Official Giveaways
          </h1>
          <p className="text-sm text-[#B8C7D9] mt-2">
            Win exclusive custom PCs, NVIDIA GPUs, official gaming merchandise, in-game Los Santos
            estates, and Steam game keys directly from Sultan.
          </p>
        </div>
      </div>

      {/* FEATURED ACTIVE GIVEAWAY CARD */}
      {activeGiveaway && (
        <section
          id="featured-active-giveaway"
          className="relative rounded-3xl overflow-hidden bg-[#041426]/90 border border-[#FF7A00]/50 shadow-2xl p-6 sm:p-8 backdrop-blur-xl space-y-6"
        >
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-center">
            {/* Left Image with Glow */}
            <div className="lg:col-span-6 relative rounded-2xl overflow-hidden bg-black/40 border border-white/10 group">
              <img
                src={activeGiveaway.image}
                alt={activeGiveaway.title}
                className="w-full h-72 sm:h-96 object-cover group-hover:scale-105 transition-transform duration-700"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-[#020817] via-transparent to-black/20" />

              <div className="absolute top-3 left-3 flex items-center gap-2">
                <span className="px-3 py-1 rounded-full text-xs font-black uppercase bg-[#FF7A00] text-white shadow-[0_0_12px_rgba(255,122,0,0.6)]">
                  LIVE GIVEAWAY
                </span>
                <span className="px-3 py-1 rounded-full text-xs font-bold bg-black/60 backdrop-blur-md text-[#53FC18] border border-white/15">
                  {activeGiveaway.prizeValue}
                </span>
              </div>
            </div>

            {/* Right Info & Countdown */}
            <div className="lg:col-span-6 space-y-5">
              <div className="space-y-2">
                <span className="text-xs font-bold uppercase tracking-wider text-[#FF9500]">
                  {activeGiveaway.edition}
                </span>
                <h2 className="text-2xl sm:text-4xl font-black uppercase text-white font-['Space_Grotesk'] leading-tight">
                  {activeGiveaway.title}
                </h2>
                <p className="text-sm text-[#B8C7D9] leading-relaxed">
                  {activeGiveaway.description}
                </p>
              </div>

              {/* Countdown Timer Blocks */}
              <div className="space-y-2">
                <div className="flex items-center gap-1.5 text-xs text-[#EAF4FF] font-semibold">
                  <Clock className="w-3.5 h-3.5 text-[#FF7A00]" />
                  <span>Giveaway Ends In:</span>
                </div>

                <div className="grid grid-cols-4 gap-2.5 max-w-md">
                  {[
                    { label: 'Days', val: timeLeft.days },
                    { label: 'Hours', val: timeLeft.hours },
                    { label: 'Minutes', val: timeLeft.minutes },
                    { label: 'Seconds', val: timeLeft.seconds },
                  ].map(unit => (
                    <div
                      key={unit.label}
                      className="p-3 rounded-2xl bg-[#061B2E] border border-white/10 text-center shadow-inner"
                    >
                      <span className="block text-xl sm:text-2xl font-black text-white font-mono">
                        {String(unit.val).padStart(2, '0')}
                      </span>
                      <span className="text-[10px] uppercase font-bold text-[#B8C7D9] tracking-wider">
                        {unit.label}
                      </span>
                    </div>
                  ))}
                </div>
              </div>

              {/* Stats & CTA Button */}
              <div className="pt-2 flex flex-wrap items-center justify-between gap-4 border-t border-white/10">
                <div className="flex items-center gap-4 text-xs text-[#B8C7D9]">
                  <div className="flex items-center gap-1.5">
                    <Users className="w-4 h-4 text-[#00B7FF]" />
                    <span className="font-bold text-white">
                      {activeGiveaway.entriesCount.toLocaleString()}
                    </span>{' '}
                    Entries
                  </div>
                  <div className="flex items-center gap-1.5">
                    <Trophy className="w-4 h-4 text-[#FF9500]" />
                    <span className="font-bold text-white">{activeGiveaway.winnersCount}</span>{' '}
                    Winners
                  </div>
                </div>

                {activeGiveaway.isEntered ? (
                  <div className="flex items-center gap-2 px-6 py-3 rounded-full bg-[#53FC18]/20 border border-[#53FC18] text-[#53FC18] font-bold text-xs tracking-wide">
                    <CheckCircle2 className="w-4 h-4" />
                    <span>✓ Entry Confirmed (#SG-94281)</span>
                  </div>
                ) : (
                  <button
                    id="enter-featured-giveaway-btn"
                    onClick={() => handleOpenEntry(activeGiveaway)}
                    className="flex items-center gap-2 px-8 py-3.5 rounded-full bg-gradient-to-r from-[#FF7A00] to-[#FF9500] text-white font-black text-xs sm:text-sm tracking-wide shadow-[0_0_25px_rgba(255,122,0,0.5)] hover:scale-105 active:scale-95 transition-all"
                  >
                    <Sparkles className="w-4 h-4" />
                    <span>Enter Giveaway Now</span>
                  </button>
                )}
              </div>
            </div>
          </div>
        </section>
      )}

      {/* ALL ACTIVE GIVEAWAYS GRID */}
      <section className="space-y-4">
        <h3 className="text-xl font-bold uppercase text-white font-['Space_Grotesk']">
          All Active Giveaways ({activeGiveaways.length})
        </h3>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
          {activeGiveaways.map(g => (
            <div
              key={g.id}
              className="rounded-3xl bg-[#041426]/80 border border-white/10 hover:border-[#FF7A00]/50 backdrop-blur-xl p-5 transition-all duration-300 flex flex-col justify-between"
            >
              <div className="space-y-3">
                <div className="relative h-44 rounded-2xl overflow-hidden bg-black/40 border border-white/10">
                  <img src={g.image} alt={g.title} className="w-full h-full object-cover" />
                  <span className="absolute top-3 left-3 px-3 py-1 rounded-full text-[10px] font-black uppercase bg-[#FF7A00] text-white">
                    {g.prizeValue}
                  </span>
                </div>
                <h4 className="text-base font-bold text-white">{g.title}</h4>
                <p className="text-xs text-[#B8C7D9] line-clamp-2">{g.description}</p>
              </div>

              <div className="pt-4 mt-4 border-t border-white/10 flex items-center justify-between">
                <span className="text-xs text-[#00B7FF] font-semibold">
                  {g.entriesCount.toLocaleString()} Participants
                </span>

                {g.isEntered ? (
                  <span className="text-xs text-[#53FC18] font-bold flex items-center gap-1">
                    <CheckCircle2 className="w-3.5 h-3.5" /> Entered
                  </span>
                ) : (
                  <button
                    onClick={() => handleOpenEntry(g)}
                    className="px-4 py-2 rounded-full bg-white/10 hover:bg-[#FF7A00] text-white text-xs font-bold transition-colors"
                  >
                    Enter
                  </button>
                )}
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* PAST WINNERS HALL OF FAME */}
      {pastGiveaways.length > 0 && (
        <section className="space-y-4 pt-4">
          <div className="flex items-center gap-2">
            <Trophy className="w-5 h-5 text-[#FF9500]" />
            <h3 className="text-xl font-bold uppercase text-white font-['Space_Grotesk']">
              Hall of Winners & Past Giveaways
            </h3>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {pastGiveaways.map(p => (
              <div
                key={p.id}
                className="p-4 rounded-2xl bg-[#041426]/60 border border-white/10 backdrop-blur-md flex items-center justify-between gap-3"
              >
                <div className="flex items-center gap-3">
                  <img src={p.image} alt="" className="w-12 h-12 rounded-xl object-cover" />
                  <div>
                    <h5 className="text-xs font-bold text-white">{p.title}</h5>
                    <p className="text-[11px] text-[#53FC18] font-medium">
                      Winner: {p.winnerName || 'Squad Member'}
                    </p>
                  </div>
                </div>
                <span className="text-[10px] px-2.5 py-1 rounded-full bg-white/5 border border-white/10 text-white/50">
                  Ended
                </span>
              </div>
            ))}
          </div>
        </section>
      )}

      {/* ENTRY MODAL */}
      {showEntryModal && selectedGiveawayToEnter && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md">
          <div className="w-full max-w-md rounded-3xl bg-[#061B2E] border border-white/15 p-6 shadow-2xl space-y-4">
            <div className="flex items-center justify-between pb-2 border-b border-white/10">
              <div className="flex items-center gap-2 text-[#FF9500] font-bold text-xs uppercase">
                <Gift className="w-4 h-4" />
                <span>Giveaway Entry</span>
              </div>
              <button
                onClick={() => setShowEntryModal(false)}
                className="text-xs text-white/50 hover:text-white"
              >
                ✕
              </button>
            </div>

            <div className="space-y-1">
              <h3 className="text-lg font-bold text-white">{selectedGiveawayToEnter.title}</h3>
              <p className="text-xs text-[#B8C7D9]">
                Provide your gaming handle and email. Winners are announced live on stream and
                notified via email.
              </p>
            </div>

            <form onSubmit={handleSubmitEntry} className="space-y-3 pt-2">
              <div>
                <label className="block text-xs font-medium text-[#B8C7D9] mb-1">
                  Email Address
                </label>
                <input
                  type="email"
                  required
                  value={email}
                  onChange={e => setEmail(e.target.value)}
                  placeholder="name@gmail.com"
                  className="w-full bg-white/5 border border-white/10 rounded-xl p-2.5 text-xs text-white focus:outline-none focus:border-[#FF7A00]"
                />
              </div>

              <div>
                <label className="block text-xs font-medium text-[#B8C7D9] mb-1">
                  Gamertag / Discord ID
                </label>
                <input
                  type="text"
                  required
                  value={gamertag}
                  onChange={e => setGamertag(e.target.value)}
                  placeholder="e.g. SultanFan#9999 or PSN: SultanKing"
                  className="w-full bg-white/5 border border-white/10 rounded-xl p-2.5 text-xs text-white focus:outline-none focus:border-[#FF7A00]"
                />
              </div>

              <div className="p-3 rounded-xl bg-white/5 border border-white/10 flex items-center gap-2 text-[11px] text-white/60">
                <ShieldCheck className="w-4 h-4 text-[#53FC18] flex-shrink-0" />
                <span>No purchase necessary. Winner verified with fair RNG draw.</span>
              </div>

              <button
                type="submit"
                className="w-full py-3 rounded-xl bg-gradient-to-r from-[#FF7A00] to-[#FF9500] text-white font-bold text-xs tracking-wide shadow-lg hover:scale-[1.02] active:scale-95 transition-all"
              >
                Confirm & Submit Entry
              </button>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
