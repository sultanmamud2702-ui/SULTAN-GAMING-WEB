import React, { useState } from 'react';
import {
  Laptop,
  Cpu,
  Tv,
  Mic,
  ExternalLink,
  Plus,
  Trash2,
  Edit2,
  CheckCircle2,
  Zap,
  Sparkles,
} from 'lucide-react';
import { useStore } from '../context/StoreContext';
import { PCSpecItem } from '../types';

export const PCSpecsPage: React.FC = () => {
  const { pcSpecs, isAdmin, addPCSpec, deletePCSpec, updatePCSpec, triggerConfetti } = useStore();
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [showAddModal, setShowAddModal] = useState(false);
  const [editingSpec, setEditingSpec] = useState<PCSpecItem | null>(null);

  // Form state
  const [formData, setFormData] = useState<Omit<PCSpecItem, 'id'>>({
    name: '',
    category: 'Core Hardware',
    specs: '',
    description: '',
    image: '',
    buyUrl: '',
    order: pcSpecs.length + 1,
  });

  const categories = ['all', 'Core Hardware', 'Peripherals', 'Streaming & Audio'];

  const filteredSpecs = pcSpecs.filter(spec => {
    if (selectedCategory === 'all') return true;
    return spec.category.toLowerCase() === selectedCategory.toLowerCase();
  });

  const handleSaveSpec = (e: React.FormEvent) => {
    e.preventDefault();
    if (editingSpec) {
      updatePCSpec(editingSpec.id, formData);
    } else {
      addPCSpec(formData);
    }
    setShowAddModal(false);
    setEditingSpec(null);
    setFormData({
      name: '',
      category: 'Core Hardware',
      specs: '',
      description: '',
      image: '',
      buyUrl: '',
      order: pcSpecs.length + 1,
    });
    triggerConfetti();
  };

  const startEdit = (spec: PCSpecItem) => {
    setEditingSpec(spec);
    setFormData({
      name: spec.name,
      category: spec.category,
      specs: spec.specs,
      description: spec.description,
      image: spec.image,
      buyUrl: spec.buyUrl,
      order: spec.order,
    });
    setShowAddModal(true);
  };

  return (
    <div className="space-y-8 animate-in fade-in duration-300">
      {/* Header Banner */}
      <div className="relative rounded-3xl overflow-hidden bg-gradient-to-r from-[#041426] via-[#061B2E] to-[#020817] border border-white/10 p-6 sm:p-8 shadow-xl">
        <div className="absolute top-0 right-0 w-96 h-96 bg-[#00B7FF]/10 rounded-full blur-3xl pointer-events-none" />
        <div className="relative z-10 flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div className="max-w-2xl">
            <div className="flex items-center gap-2 text-[#00B7FF] text-xs font-bold uppercase tracking-wider mb-2">
              <Laptop className="w-4 h-4" />
              <span>BATTLESTATION & HARDWARE</span>
            </div>
            <h1 className="text-3xl sm:text-4xl font-black uppercase text-white font-['Space_Grotesk'] tracking-tight">
              PC Specs & Setup
            </h1>
            <p className="text-sm text-[#B8C7D9] mt-2">
              Sultan's custom high-performance rig engineered for ultra 4K 144FPS streaming,
              instant video rendering, and Los Santos roleplay dominance.
            </p>
          </div>

          {isAdmin && (
            <button
              onClick={() => {
                setEditingSpec(null);
                setFormData({
                  name: '',
                  category: 'Core Hardware',
                  specs: '',
                  description: '',
                  image: '',
                  buyUrl: '',
                  order: pcSpecs.length + 1,
                });
                setShowAddModal(true);
              }}
              className="flex items-center gap-2 px-5 py-2.5 rounded-full bg-gradient-to-r from-[#FF7A00] to-[#FF9500] text-white font-bold text-xs tracking-wide shadow-lg hover:scale-105 transition-all self-start md:self-auto"
            >
              <Plus className="w-4 h-4" />
              <span>Add Hardware Spec</span>
            </button>
          )}
        </div>
      </div>

      {/* Category Tabs */}
      <div className="flex items-center gap-2 overflow-x-auto pb-1 scrollbar-none">
        {categories.map(cat => (
          <button
            key={cat}
            onClick={() => setSelectedCategory(cat)}
            className={`px-4 py-2 rounded-full text-xs font-bold tracking-wide whitespace-nowrap transition-all ${
              selectedCategory === cat
                ? 'bg-gradient-to-r from-[#0066FF] to-[#008CFF] text-white shadow-[0_0_15px_rgba(0,140,255,0.4)]'
                : 'bg-[#041426]/80 text-[#B8C7D9] hover:text-white hover:bg-white/10 border border-white/10'
            }`}
          >
            {cat === 'all' ? 'All Hardware' : cat}
          </button>
        ))}
      </div>

      {/* Specs Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-5">
        {filteredSpecs.map(spec => (
          <div
            key={spec.id}
            id={`pc-spec-card-${spec.id}`}
            className="group rounded-3xl bg-[#041426]/85 border border-white/10 hover:border-[#00B7FF]/60 backdrop-blur-xl p-5 transition-all duration-300 hover:-translate-y-1.5 hover:shadow-[0_0_25px_rgba(0,183,255,0.2)] flex flex-col justify-between"
          >
            <div>
              {/* Image & Category Pill */}
              <div className="relative h-48 rounded-2xl overflow-hidden bg-black/50 border border-white/10 mb-4">
                <img
                  src={spec.image}
                  alt={spec.name}
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                />
                <span className="absolute top-3 left-3 px-3 py-1 rounded-full text-[10px] font-bold uppercase tracking-wider bg-black/70 backdrop-blur-md text-[#00B7FF] border border-white/15">
                  {spec.category}
                </span>

                {isAdmin && (
                  <div className="absolute top-3 right-3 flex items-center gap-1.5">
                    <button
                      onClick={() => startEdit(spec)}
                      className="p-1.5 rounded-lg bg-black/70 text-white hover:bg-[#FF7A00] transition-colors"
                      title="Edit"
                    >
                      <Edit2 className="w-3.5 h-3.5" />
                    </button>
                    <button
                      onClick={() => deletePCSpec(spec.id)}
                      className="p-1.5 rounded-lg bg-black/70 text-red-400 hover:bg-red-500 hover:text-white transition-colors"
                      title="Delete"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                )}
              </div>

              {/* Title & Technical Specs */}
              <h3 className="text-base font-bold text-white group-hover:text-[#00B7FF] transition-colors">
                {spec.name}
              </h3>
              <p className="text-xs font-semibold text-[#FF9500] mt-0.5">
                {spec.specs}
              </p>

              {/* Description */}
              <p className="text-xs text-[#B8C7D9] mt-2.5 leading-relaxed">
                {spec.description}
              </p>
            </div>

            {/* Buy / View Link */}
            {spec.buyUrl && (
              <div className="pt-4 mt-4 border-t border-white/10 flex items-center justify-between">
                <a
                  href={spec.buyUrl}
                  target="_blank"
                  rel="noreferrer"
                  className="inline-flex items-center gap-1.5 text-xs font-bold text-[#00B7FF] hover:text-white transition-colors group/link"
                >
                  <span>View Product Details</span>
                  <ExternalLink className="w-3.5 h-3.5 group-hover/link:translate-x-0.5 transition-transform" />
                </a>
                <span className="text-[10px] text-white/40">Verified Rig</span>
              </div>
            )}
          </div>
        ))}
      </div>

      {/* Add / Edit Spec Modal */}
      {showAddModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md">
          <div className="w-full max-w-lg rounded-3xl bg-[#061B2E] border border-white/15 p-6 shadow-2xl space-y-4">
            <h3 className="text-lg font-bold text-white">
              {editingSpec ? 'Edit Hardware Component' : 'Add New Hardware Component'}
            </h3>

            <form onSubmit={handleSaveSpec} className="space-y-3">
              <div>
                <label className="block text-xs text-[#B8C7D9] mb-1">Component Name</label>
                <input
                  type="text"
                  required
                  value={formData.name}
                  onChange={e => setFormData({ ...formData, name: e.target.value })}
                  placeholder="e.g. GPU, CPU, RAM"
                  className="w-full bg-white/5 border border-white/10 rounded-xl p-2.5 text-xs text-white focus:outline-none focus:border-[#FF7A00]"
                />
              </div>

              <div>
                <label className="block text-xs text-[#B8C7D9] mb-1">Category</label>
                <select
                  value={formData.category}
                  onChange={e => setFormData({ ...formData, category: e.target.value })}
                  className="w-full bg-white/5 border border-white/10 rounded-xl p-2.5 text-xs text-white focus:outline-none focus:border-[#FF7A00]"
                >
                  <option value="Core Hardware" className="bg-[#061B2E]">Core Hardware</option>
                  <option value="Peripherals" className="bg-[#061B2E]">Peripherals</option>
                  <option value="Streaming & Audio" className="bg-[#061B2E]">Streaming & Audio</option>
                </select>
              </div>

              <div>
                <label className="block text-xs text-[#B8C7D9] mb-1">Technical Specs</label>
                <input
                  type="text"
                  required
                  value={formData.specs}
                  onChange={e => setFormData({ ...formData, specs: e.target.value })}
                  placeholder="e.g. NVIDIA GeForce RTX 4090 24GB"
                  className="w-full bg-white/5 border border-white/10 rounded-xl p-2.5 text-xs text-white focus:outline-none focus:border-[#FF7A00]"
                />
              </div>

              <div>
                <label className="block text-xs text-[#B8C7D9] mb-1">Description</label>
                <textarea
                  rows={2}
                  value={formData.description}
                  onChange={e => setFormData({ ...formData, description: e.target.value })}
                  placeholder="Performance summary..."
                  className="w-full bg-white/5 border border-white/10 rounded-xl p-2.5 text-xs text-white focus:outline-none focus:border-[#FF7A00]"
                />
              </div>

              <div>
                <label className="block text-xs text-[#B8C7D9] mb-1">Image URL</label>
                <input
                  type="url"
                  required
                  value={formData.image}
                  onChange={e => setFormData({ ...formData, image: e.target.value })}
                  placeholder="https://..."
                  className="w-full bg-white/5 border border-white/10 rounded-xl p-2.5 text-xs text-white focus:outline-none focus:border-[#FF7A00]"
                />
              </div>

              <div>
                <label className="block text-xs text-[#B8C7D9] mb-1">Product / Store URL</label>
                <input
                  type="url"
                  value={formData.buyUrl}
                  onChange={e => setFormData({ ...formData, buyUrl: e.target.value })}
                  placeholder="https://amazon.com/..."
                  className="w-full bg-white/5 border border-white/10 rounded-xl p-2.5 text-xs text-white focus:outline-none focus:border-[#FF7A00]"
                />
              </div>

              <div className="flex items-center justify-end gap-2 pt-3 border-t border-white/10">
                <button
                  type="button"
                  onClick={() => setShowAddModal(false)}
                  className="px-4 py-2 rounded-xl bg-white/5 text-xs text-white hover:bg-white/10"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 rounded-xl bg-[#FF7A00] text-xs font-bold text-white hover:bg-[#FF9500]"
                >
                  {editingSpec ? 'Save Changes' : 'Create Component'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
