import React, { useState } from 'react';
import {
  Gamepad2,
  Play,
  Copy,
  Check,
  Users,
  Calendar,
  Sparkles,
  ExternalLink,
  ChevronRight,
  Eye,
  MessageSquare,
} from 'lucide-react';
import { useStore } from '../context/StoreContext';
import { Game, PageId } from '../types';

interface GameDetailPageProps {
  gameSlug: string;
}

export const GameDetailPage: React.FC<GameDetailPageProps> = ({ gameSlug }) => {
  const { games, videos, posts, setCurrentPage, triggerConfetti } = useStore();
  const [copied, setCopied] = useState(false);

  const game = games.find(g => g.slug === gameSlug) || games[0];

  if (!game) {
    return (
      <div className="py-20 text-center text-white">
        <p>Game not found.</p>
        <button onClick={() => setCurrentPage('home')} className="text-[#FF9500] underline mt-2">
          Return Home
        </button>
      </div>
    );
  }

  const relatedVideos = videos.filter(v => v.gameSlug === game.slug || v.title.toLowerCase().includes(game.title.toLowerCase()));
  const relatedPosts = posts.filter(p => p.gameTag.toLowerCase().includes(game.title.toLowerCase()) || p.gameTag.toLowerCase().includes(game.slug));

  const copyServerIP = (ip: string) => {
    navigator.clipboard?.writeText(ip);
    setCopied(true);
    triggerConfetti();
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="space-y-8 animate-in fade-in duration-300">
      {/* GAME HERO BANNER */}
      <div className="relative rounded-3xl overflow-hidden bg-[#041426] border border-white/15 shadow-2xl">
        {/* Banner with dark gradient */}
        <div className="relative h-64 sm:h-80 w-full overflow-hidden bg-black/60">
          <img
            src={game.banner}
            alt={game.title}
            className="w-full h-full object-cover"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-[#041426] via-[#041426]/50 to-transparent" />
          <div className="absolute inset-0 bg-gradient-to-r from-[#020817] via-transparent to-transparent" />

          {/* Floating Game Logo */}
          <div className="absolute bottom-6 left-6 flex items-end gap-4 z-10">
            <div className="w-16 h-16 sm:w-20 sm:h-20 rounded-2xl bg-black/70 backdrop-blur-md border border-white/20 p-2 shadow-2xl flex items-center justify-center flex-shrink-0">
              <img src={game.logo} alt="" className="w-full h-full object-contain" />
            </div>
            <div>
              <span className="text-xs font-bold uppercase tracking-wider text-[#FF9500] bg-black/60 px-3 py-1 rounded-full backdrop-blur-md">
                {game.genre}
              </span>
              <h1 className="text-2xl sm:text-4xl font-black uppercase text-white font-['Space_Grotesk'] mt-1 tracking-tight">
                {game.title}
              </h1>
            </div>
          </div>
        </div>

        {/* Info & Tags Bar */}
        <div className="p-6 flex flex-wrap items-center justify-between gap-4 border-t border-white/10">
          <div className="flex flex-wrap items-center gap-2">
            {game.tags.map(tag => (
              <span
                key={tag}
                className="px-3 py-1 rounded-full text-xs font-semibold bg-white/5 border border-white/10 text-[#B8C7D9]"
              >
                #{tag}
              </span>
            ))}
          </div>

          <div className="flex items-center gap-3">
            <button
              onClick={() => setCurrentPage('community')}
              className="px-4 py-2 rounded-full bg-white/10 hover:bg-white/20 text-white text-xs font-bold transition-colors"
            >
              Discuss in Community
            </button>
            <button
              onClick={() => setCurrentPage('youtube')}
              className="px-5 py-2 rounded-full bg-[#FF7A00] hover:bg-[#FF9500] text-white text-xs font-bold shadow-md transition-colors"
            >
              Watch Game Series
            </button>
          </div>
        </div>
      </div>

      {/* OVERVIEW & SERVER DETAILS */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left: Description & Features (8 Cols) */}
        <div className="lg:col-span-8 rounded-3xl bg-[#041426]/80 border border-white/10 p-6 backdrop-blur-xl shadow-xl space-y-4">
          <h2 className="text-lg font-bold text-white uppercase font-['Space_Grotesk']">
            About {game.title} on Sultan Gaming
          </h2>
          <p className="text-sm text-[#B8C7D9] leading-relaxed">
            {game.description}
          </p>

          <div className="pt-4 border-t border-white/10 space-y-3">
            <h3 className="text-xs font-bold text-[#FF9500] uppercase tracking-wider">
              Stream & Community Highlights
            </h3>
            <ul className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs text-white/80">
              <li className="flex items-center gap-2 p-2 rounded-xl bg-white/5">
                <span className="w-1.5 h-1.5 rounded-full bg-[#FF7A00]" />
                Viewer lobbies hosted every Friday live
              </li>
              <li className="flex items-center gap-2 p-2 rounded-xl bg-white/5">
                <span className="w-1.5 h-1.5 rounded-full bg-[#00B7FF]" />
                Custom mods and optimized graphics shaders
              </li>
              <li className="flex items-center gap-2 p-2 rounded-xl bg-white/5">
                <span className="w-1.5 h-1.5 rounded-full bg-[#53FC18]" />
                In-game events with hardware prize giveaways
              </li>
              <li className="flex items-center gap-2 p-2 rounded-xl bg-white/5">
                <span className="w-1.5 h-1.5 rounded-full bg-[#E1306C]" />
                Dedicated voice lounges on Sultan Discord
              </li>
            </ul>
          </div>
        </div>

        {/* Right: Join & Server Card (4 Cols) */}
        <div className="lg:col-span-4 rounded-3xl bg-[#061B2E] border border-white/15 p-6 shadow-xl space-y-4 flex flex-col justify-between">
          <div className="space-y-3">
            <span className="text-xs font-bold text-[#00B7FF] uppercase tracking-wider">
              MULTI-PLAYER SQUAD
            </span>
            <h3 className="text-base font-bold text-white">Join Sultan's Server</h3>
            <p className="text-xs text-[#B8C7D9]">
              Connect to our dedicated game servers or participate in open heist parties.
            </p>

            {/* Server IP Copy Box */}
            <div className="p-3 rounded-2xl bg-black/50 border border-white/10 flex items-center justify-between gap-2">
              <div className="truncate">
                <p className="text-[10px] text-white/40 uppercase">Server Address / IP</p>
                <p className="text-xs font-mono font-bold text-[#53FC18] truncate">
                  play.sultangaming.com
                </p>
              </div>
              <button
                onClick={() => copyServerIP('play.sultangaming.com')}
                className="p-2 rounded-xl bg-white/10 hover:bg-white/20 text-white transition-colors flex-shrink-0"
                title="Copy IP"
              >
                {copied ? <Check className="w-4 h-4 text-[#53FC18]" /> : <Copy className="w-4 h-4" />}
              </button>
            </div>
          </div>

          <button
            onClick={() => setCurrentPage('discord')}
            className="w-full py-3 rounded-2xl bg-[#5865F2] hover:bg-[#4752C4] text-white font-bold text-xs flex items-center justify-center gap-2 shadow-lg transition-colors"
          >
            <span>Join Discord Party</span>
            <ExternalLink className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>

      {/* RELATED VIDEOS */}
      {relatedVideos.length > 0 && (
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="text-lg font-bold uppercase text-white font-['Space_Grotesk']">
              {game.title} Videos & Series
            </h3>
            <button
              onClick={() => setCurrentPage('youtube')}
              className="text-xs text-[#00B7FF] hover:underline"
            >
              View YouTube Channel →
            </button>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
            {relatedVideos.map(v => (
              <div
                key={v.id}
                onClick={() => setCurrentPage('youtube')}
                className="group rounded-2xl bg-[#041426]/80 border border-white/10 hover:border-[#FF7A00]/50 p-3 cursor-pointer transition-all"
              >
                <div className="relative h-40 rounded-xl overflow-hidden bg-black mb-2.5">
                  <img src={v.thumbnail} alt="" className="w-full h-full object-cover group-hover:scale-105 transition-transform" />
                  <span className="absolute bottom-2 right-2 text-[10px] bg-black/80 font-mono px-1.5 py-0.5 rounded text-white">
                    {v.duration}
                  </span>
                </div>
                <h4 className="text-xs font-bold text-white group-hover:text-[#FF9500] truncate">
                  {v.title}
                </h4>
                <p className="text-[11px] text-[#B8C7D9] mt-0.5">{v.views} • {v.uploadDate}</p>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* RELATED COMMUNITY POSTS */}
      {relatedPosts.length > 0 && (
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="text-lg font-bold uppercase text-white font-['Space_Grotesk']">
              Community Posts for {game.title}
            </h3>
            <button
              onClick={() => setCurrentPage('community')}
              className="text-xs text-[#FF9500] hover:underline"
            >
              View Community Hub →
            </button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {relatedPosts.map(p => (
              <div
                key={p.id}
                onClick={() => setCurrentPage('community')}
                className="p-4 rounded-2xl bg-[#041426]/75 border border-white/10 hover:border-white/20 cursor-pointer transition-all space-y-2"
              >
                <div className="flex items-center gap-2">
                  <img src={p.author.avatar} alt="" className="w-8 h-8 rounded-full object-cover" />
                  <div>
                    <span className="text-xs font-bold text-white">{p.author.name}</span>
                    <span className="text-[10px] text-white/40 block">{p.timestamp}</span>
                  </div>
                </div>
                <p className="text-xs text-[#EAF4FF] line-clamp-2">{p.content}</p>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};
