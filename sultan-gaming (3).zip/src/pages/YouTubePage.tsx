import React, { useState } from 'react';
import {
  Youtube,
  RefreshCw,
  Play,
  Eye,
  Calendar,
  ExternalLink,
  Sparkles,
  CheckCircle2,
  Filter,
} from 'lucide-react';
import { useStore } from '../context/StoreContext';
import { VideoItem } from '../types';

export const YouTubePage: React.FC = () => {
  const {
    videos,
    playlists,
    syncYouTubeData,
    isSyncingPlatform,
    platforms,
    triggerConfetti,
    hasRole,
  } = useStore();

  const [selectedPlaylist, setSelectedPlaylist] = useState<string>('all');
  const [activeVideoModal, setActiveVideoModal] = useState<VideoItem | null>(null);

  const youtubePlatform = platforms.find(p => p.type === 'youtube');
  const isAdmin = hasRole(['ADMIN', 'SUPER_ADMIN']);

  const filteredVideos = videos.filter(video => {
    if (selectedPlaylist === 'all') return true;
    return video.gameSlug === selectedPlaylist;
  });

  const handleSync = async () => {
    await syncYouTubeData(youtubePlatform?.url || 'https://youtube.com/@SultanGaming');
  };

  return (
    <div className="space-y-8 animate-in fade-in duration-300">
      {/* CHANNEL HERO HEADER */}
      <div className="relative rounded-3xl overflow-hidden bg-[#041426] border border-[#FF0000]/40 shadow-2xl">
        {/* Banner Image */}
        <div className="relative h-44 sm:h-56 w-full overflow-hidden bg-gradient-to-r from-red-950 via-[#061B2E] to-black">
          <img
            src="https://images.unsplash.com/photo-1542751371-adc38448a05e?auto=format&fit=crop&w=1600&q=80"
            alt="YouTube Banner"
            className="w-full h-full object-cover opacity-40"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-[#041426] via-transparent to-black/40" />

          {/* Red Ambient Glow */}
          <div className="absolute top-0 right-1/4 w-80 h-80 bg-[#FF0000]/20 rounded-full blur-3xl pointer-events-none" />
        </div>

        {/* Channel Details Info Bar */}
        <div className="p-6 sm:p-8 -mt-16 sm:-mt-20 relative z-10 flex flex-col md:flex-row md:items-end justify-between gap-5">
          <div className="flex items-center gap-4">
            <div className="w-20 h-20 sm:w-24 sm:h-24 rounded-2xl bg-black border-2 border-[#FF0000] overflow-hidden p-1 shadow-2xl flex-shrink-0">
              <img
                src={youtubePlatform?.avatar || 'https://images.unsplash.com/photo-1566492031773-4f4e44671857?auto=format&fit=crop&w=200&q=80'}
                alt="Sultan Gaming"
                className="w-full h-full object-cover rounded-xl"
              />
            </div>

            <div>
              <div className="flex items-center gap-2">
                <h1 className="text-2xl sm:text-3xl font-black uppercase text-white font-['Space_Grotesk'] tracking-tight">
                  Sultan Gaming
                </h1>
                <CheckCircle2 className="w-5 h-5 text-[#FF0000] fill-current text-white" />
              </div>

              <p className="text-xs text-[#B8C7D9] mt-0.5">
                @SultanGaming • {youtubePlatform?.followers || '250K+ Subscribers'} • 1,240+ Videos
              </p>

              <p className="text-xs text-white/70 max-w-xl mt-2 line-clamp-2">
                Daily GTA 5 Online stunts, funny moments, Minecraft survival series, and high-energy multiplayer streams.
              </p>
            </div>
          </div>

          {/* Action Buttons */}
          <div className="flex flex-wrap items-center gap-3">
            {isAdmin && (
              <button
                id="sync-youtube-data-btn"
                onClick={handleSync}
                disabled={isSyncingPlatform}
                className="flex items-center gap-2 px-4 py-2.5 rounded-full bg-white/10 hover:bg-white/20 border border-white/15 text-white text-xs font-bold transition-all disabled:opacity-50"
              >
                <RefreshCw className={`w-3.5 h-3.5 ${isSyncingPlatform ? 'animate-spin text-[#00B7FF]' : ''}`} />
                <span>{isSyncingPlatform ? 'Syncing...' : 'Admin Sync YouTube'}</span>
              </button>
            )}

            <a
              href={youtubePlatform?.url || 'https://youtube.com/@SultanGaming'}
              target="_blank"
              rel="noreferrer"
              className="flex items-center gap-2 px-6 py-2.5 rounded-full bg-[#FF0000] hover:bg-red-600 text-white text-xs font-black tracking-wide shadow-[0_0_20px_rgba(255,0,0,0.5)] hover:scale-105 active:scale-95 transition-all"
            >
              <Youtube className="w-4 h-4 fill-current" />
              <span>Subscribe {youtubePlatform?.followers || '250K+'}</span>
            </a>
          </div>
        </div>
      </div>

      {/* PLAYLIST FILTER TABS */}
      <div className="space-y-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2 text-white font-bold text-sm uppercase tracking-wider font-['Space_Grotesk']">
            <Filter className="w-4 h-4 text-[#FF0000]" />
            <span>Playlists & Categories</span>
          </div>
          <span className="text-xs text-[#B8C7D9]">{filteredVideos.length} Videos</span>
        </div>

        <div className="flex items-center gap-2 overflow-x-auto pb-1 scrollbar-none">
          <button
            onClick={() => setSelectedPlaylist('all')}
            className={`px-4 py-2 rounded-full text-xs font-bold tracking-wide whitespace-nowrap transition-all ${
              selectedPlaylist === 'all'
                ? 'bg-[#FF0000] text-white shadow-[0_0_15px_rgba(255,0,0,0.4)]'
                : 'bg-[#041426]/80 text-[#B8C7D9] hover:text-white hover:bg-white/10 border border-white/10'
            }`}
          >
            All Videos ({videos.length})
          </button>

          {playlists.map(pl => (
            <button
              key={pl.id}
              onClick={() => setSelectedPlaylist(pl.slug)}
              className={`px-4 py-2 rounded-full text-xs font-bold tracking-wide whitespace-nowrap transition-all ${
                selectedPlaylist === pl.slug
                  ? 'bg-[#FF0000] text-white shadow-[0_0_15px_rgba(255,0,0,0.4)]'
                  : 'bg-[#041426]/80 text-[#B8C7D9] hover:text-white hover:bg-white/10 border border-white/10'
              }`}
            >
              {pl.title} ({pl.videoCount})
            </button>
          ))}
        </div>
      </div>

      {/* VIDEOS GRID */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-5">
        {filteredVideos.map(video => (
          <div
            key={video.id}
            id={`yt-video-card-${video.id}`}
            onClick={() => setActiveVideoModal(video)}
            className="group rounded-2xl bg-[#041426]/80 border border-white/10 hover:border-[#FF0000]/60 backdrop-blur-xl p-3 cursor-pointer transition-all duration-300 hover:-translate-y-1.5 hover:shadow-[0_0_25px_rgba(255,0,0,0.2)] flex flex-col justify-between"
          >
            <div>
              {/* Thumbnail Container */}
              <div className="relative h-44 rounded-xl overflow-hidden bg-black/60 mb-3">
                <img
                  src={video.thumbnail}
                  alt={video.title}
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                />
                <div className="absolute inset-0 bg-black/20 group-hover:bg-black/0 transition-colors" />

                {/* Duration Badge */}
                <span className="absolute bottom-2 right-2 px-2 py-0.5 rounded bg-black/85 text-[10px] font-mono text-white font-bold">
                  {video.duration}
                </span>

                {/* Play icon overlay on hover */}
                <div className="absolute inset-0 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity">
                  <div className="w-12 h-12 rounded-full bg-[#FF0000] text-white flex items-center justify-center shadow-lg transform group-hover:scale-110 transition-transform">
                    <Play className="w-5 h-5 fill-current ml-0.5" />
                  </div>
                </div>
              </div>

              {/* Title & Metadata */}
              <h3 className="text-sm font-bold text-white group-hover:text-[#FF9500] line-clamp-2 transition-colors">
                {video.title}
              </h3>
            </div>

            <div className="pt-3 mt-3 border-t border-white/5 flex items-center justify-between text-[11px] text-[#B8C7D9]">
              <span className="flex items-center gap-1">
                <Eye className="w-3.5 h-3.5 text-[#00B7FF]" />
                {video.views}
              </span>
              <span className="flex items-center gap-1">
                <Calendar className="w-3.5 h-3.5 text-white/40" />
                {video.uploadDate}
              </span>
            </div>
          </div>
        ))}
      </div>

      {/* VIDEO PLAYER POPUP MODAL */}
      {activeVideoModal && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-md animate-in fade-in duration-200"
          onClick={() => setActiveVideoModal(null)}
        >
          <div
            className="w-full max-w-3xl rounded-3xl bg-[#041426] border border-white/20 p-5 shadow-2xl space-y-4"
            onClick={e => e.stopPropagation()}
          >
            <div className="flex items-center justify-between pb-2 border-b border-white/10">
              <div className="flex items-center gap-2">
                <Youtube className="w-5 h-5 text-[#FF0000]" />
                <span className="text-xs font-bold uppercase text-white font-['Space_Grotesk']">
                  Sultan Gaming Player
                </span>
              </div>
              <button
                onClick={() => setActiveVideoModal(null)}
                className="text-white/60 hover:text-white text-xs px-2 py-1 rounded bg-white/10"
              >
                ✕ Close
              </button>
            </div>

            {/* Video Player Mock */}
            <div className="relative aspect-video rounded-2xl overflow-hidden bg-black flex items-center justify-center border border-white/10">
              <img
                src={activeVideoModal.thumbnail}
                alt=""
                className="absolute inset-0 w-full h-full object-cover opacity-60"
              />
              <div className="relative z-10 text-center space-y-3 p-4">
                <div className="w-16 h-16 rounded-full bg-[#FF0000] text-white mx-auto flex items-center justify-center shadow-[0_0_30px_rgba(255,0,0,0.8)] cursor-pointer hover:scale-110 transition-transform">
                  <Play className="w-8 h-8 fill-current ml-1" />
                </div>
                <p className="text-xs text-white/80 font-mono">Playing high quality stream stream...</p>
              </div>
            </div>

            <div className="space-y-1">
              <h3 className="text-base font-bold text-white">{activeVideoModal.title}</h3>
              <p className="text-xs text-[#B8C7D9]">
                {activeVideoModal.views} • Uploaded {activeVideoModal.uploadDate} • Game: {activeVideoModal.gameSlug}
              </p>
            </div>

            <div className="pt-2 flex items-center justify-between">
              <a
                href={activeVideoModal.url}
                target="_blank"
                rel="noreferrer"
                className="inline-flex items-center gap-2 px-5 py-2.5 rounded-full bg-[#FF0000] text-white font-bold text-xs hover:bg-red-600 transition-colors"
              >
                <span>Watch on YouTube App</span>
                <ExternalLink className="w-3.5 h-3.5" />
              </a>
              <span className="text-xs text-white/40">Sultan Gaming Video Hub</span>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
