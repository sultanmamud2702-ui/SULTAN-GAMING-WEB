import React, { useState, useEffect, useRef } from 'react';
import {
  Radio,
  Users,
  Heart,
  Send,
  Sparkles,
  ExternalLink,
  Flame,
  Volume2,
  Maximize2,
  Gift,
  Crown,
} from 'lucide-react';
import { useStore } from '../context/StoreContext';

interface ChatMessage {
  id: string;
  user: string;
  badge?: string;
  color: string;
  message: string;
  time: string;
}

export const KickPage: React.FC = () => {
  const { platforms, triggerConfetti } = useStore();
  const kickPlatform = platforms.find(p => p.type === 'kick');

  const [chatMessages, setChatMessages] = useState<ChatMessage[]>([
    { id: '1', user: 'LosSantosDrifter', badge: 'VIP', color: '#53FC18', message: 'That getaway drift was unreal Sultan!! 🔥', time: '18:02' },
    { id: '2', user: 'MinecraftKing', badge: 'SUB 6M', color: '#00B7FF', message: 'W stream lets do the vault drill next', time: '18:03' },
    { id: '3', user: 'SultanFan99', badge: 'MOD', color: '#FF7A00', message: 'Remember to enter the luxury mansion giveaway in the tab guys!', time: '18:03' },
    { id: '4', user: 'TurboGamer', color: '#B8C7D9', message: 'Poggers 2.4k viewers lets goooo', time: '18:04' },
    { id: '5', user: 'ViperX', badge: 'SUB 1Y', color: '#53FC18', message: 'SULTAN SQUAD ON TOP 👑', time: '18:04' },
  ]);

  const [inputMsg, setInputMsg] = useState('');
  const chatEndRef = useRef<HTMLDivElement>(null);

  // Auto-scroll chat
  useEffect(() => {
    chatEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [chatMessages]);

  // Periodic mock spectator messages
  useEffect(() => {
    const names = ['DriftPro', 'GamerGirl99', 'ShadowRacer', 'HeistMaster', 'Alex_GTA', 'PixelCraft'];
    const msgs = [
      'GGS in the chat!!',
      'Can you play Palworld tomorrow??',
      'The graphics look super crisp',
      'W streamer Sultan!! 💚',
      'Lets go Sultan Squad!!',
    ];

    const interval = setInterval(() => {
      const randomName = names[Math.floor(Math.random() * names.length)];
      const randomMsg = msgs[Math.floor(Math.random() * msgs.length)];
      const newMsg: ChatMessage = {
        id: `chat-${Date.now()}`,
        user: randomName,
        color: '#53FC18',
        message: randomMsg,
        time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      };
      setChatMessages(prev => [...prev.slice(-25), newMsg]);
    }, 5500);

    return () => clearInterval(interval);
  }, []);

  const handleSendChat = (e: React.FormEvent) => {
    e.preventDefault();
    if (!inputMsg.trim()) return;

    const userMsg: ChatMessage = {
      id: `chat-${Date.now()}`,
      user: 'You (Squad Member)',
      badge: 'FAN',
      color: '#FF9500',
      message: inputMsg.trim(),
      time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    };

    setChatMessages(prev => [...prev, userMsg]);
    setInputMsg('');
    triggerConfetti();
  };

  return (
    <div className="space-y-8 animate-in fade-in duration-300">
      {/* KICK BRAND HERO BANNER */}
      <div className="relative rounded-3xl overflow-hidden bg-[#041426] border border-[#53FC18]/40 shadow-2xl p-6 sm:p-8">
        <div className="absolute top-0 right-0 w-96 h-96 bg-[#53FC18]/15 rounded-full blur-3xl pointer-events-none" />

        <div className="relative z-10 flex flex-col md:flex-row md:items-center justify-between gap-5">
          <div className="flex items-center gap-4">
            <div className="w-16 h-16 sm:w-20 sm:h-20 rounded-2xl bg-[#53FC18] text-black font-black text-3xl font-mono flex items-center justify-center shadow-[0_0_25px_rgba(83,252,24,0.5)] flex-shrink-0">
              K
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h1 className="text-2xl sm:text-3xl font-black uppercase text-white font-['Space_Grotesk'] tracking-tight">
                  Sultan Gaming on Kick
                </h1>
                <span className="px-2.5 py-0.5 rounded-full text-[10px] font-black uppercase bg-[#53FC18] text-black flex items-center gap-1 animate-pulse">
                  <span className="w-1.5 h-1.5 rounded-full bg-black" />
                  LIVE
                </span>
              </div>
              <p className="text-xs text-[#B8C7D9] mt-0.5">
                {kickPlatform?.followers || '12.4K+ Followers'} • High Bitrate 1080p60 Uncensored Gaming Livestreams
              </p>
            </div>
          </div>

          <a
            href="https://kick.com"
            target="_blank"
            rel="noreferrer"
            className="flex items-center gap-2 px-6 py-3 rounded-full bg-[#53FC18] hover:bg-[#46d614] text-black font-black text-xs sm:text-sm tracking-wide shadow-[0_0_20px_rgba(83,252,24,0.5)] hover:scale-105 active:scale-95 transition-all self-start md:self-auto"
          >
            <span>Follow on Kick</span>
            <ExternalLink className="w-4 h-4" />
          </a>
        </div>
      </div>

      {/* LIVE STREAM THEATER & CHAT LAYOUT */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left: Stream Video Player (8 Cols) */}
        <div className="lg:col-span-8 space-y-4">
          <div className="relative rounded-3xl overflow-hidden bg-black border border-white/15 aspect-video shadow-2xl flex flex-col justify-between p-4 group">
            {/* Mock Live Gameplay Stream Background */}
            <img
              src="https://images.unsplash.com/photo-1542751371-adc38448a05e?auto=format&fit=crop&w=1600&q=80"
              alt="Live Stream"
              className="absolute inset-0 w-full h-full object-cover opacity-80"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-black/40" />

            {/* Stream Top Overlay Bar */}
            <div className="relative z-10 flex items-center justify-between">
              <div className="flex items-center gap-2">
                <span className="px-3 py-1 rounded-full text-xs font-black uppercase bg-[#53FC18] text-black shadow-[0_0_10px_#53FC18]">
                  LIVE NOW
                </span>
                <span className="px-2.5 py-1 rounded-full text-xs font-bold bg-black/60 backdrop-blur-md text-white border border-white/10 flex items-center gap-1.5">
                  <Users className="w-3.5 h-3.5 text-[#53FC18]" />
                  2,410 Viewers
                </span>
              </div>

              <div className="flex items-center gap-2">
                <button className="p-2 rounded-full bg-black/60 text-white hover:bg-white/20 backdrop-blur-md">
                  <Volume2 className="w-4 h-4" />
                </button>
                <button className="p-2 rounded-full bg-black/60 text-white hover:bg-white/20 backdrop-blur-md">
                  <Maximize2 className="w-4 h-4" />
                </button>
              </div>
            </div>

            {/* Stream Bottom Overlay Info */}
            <div className="relative z-10 space-y-1">
              <span className="text-xs font-bold text-[#53FC18] uppercase tracking-wider">
                GTA 5 Online • Los Santos High Roller DLC
              </span>
              <h3 className="text-lg sm:text-xl font-bold text-white">
                GTA 5 - $2,000,000 Heist with Sultan Squad Viewers! [Live Q&A + Keys]
              </h3>
            </div>
          </div>

          {/* Stream Controls & Details Card */}
          <div className="p-5 rounded-2xl bg-[#041426]/90 border border-white/10 flex flex-wrap items-center justify-between gap-4">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-full bg-gradient-to-tr from-[#53FC18] to-emerald-400 p-0.5">
                <img
                  src="https://images.unsplash.com/photo-1566492031773-4f4e44671857?auto=format&fit=crop&w=200&q=80"
                  alt=""
                  className="w-full h-full rounded-full object-cover"
                />
              </div>
              <div>
                <p className="text-sm font-bold text-white">Sultan Gaming</p>
                <p className="text-xs text-[#53FC18]">Streaming Grand Theft Auto V</p>
              </div>
            </div>

            <div className="flex items-center gap-2">
              <button
                onClick={triggerConfetti}
                className="flex items-center gap-1.5 px-4 py-2 rounded-full bg-[#53FC18]/20 border border-[#53FC18] text-[#53FC18] font-bold text-xs hover:bg-[#53FC18] hover:text-black transition-all"
              >
                <Gift className="w-3.5 h-3.5" />
                <span>Gift Sub</span>
              </button>
              <button
                onClick={triggerConfetti}
                className="flex items-center gap-1.5 px-4 py-2 rounded-full bg-[#FF7A00] text-white font-bold text-xs shadow-md hover:scale-105 transition-transform"
              >
                <Heart className="w-3.5 h-3.5 fill-current" />
                <span>Donate</span>
              </button>
            </div>
          </div>
        </div>

        {/* Right: Simulated Live Stream Chat (4 Cols) */}
        <div className="lg:col-span-4 rounded-3xl bg-[#041426]/95 border border-white/15 p-4 flex flex-col h-[520px] shadow-2xl backdrop-blur-xl">
          <div className="flex items-center justify-between pb-3 border-b border-white/10">
            <div className="flex items-center gap-2">
              <span className="w-2 h-2 rounded-full bg-[#53FC18] animate-ping" />
              <span className="text-xs font-bold uppercase text-white font-['Space_Grotesk']">
                Kick Stream Chat
              </span>
            </div>
            <span className="text-[11px] text-[#B8C7D9] font-mono">Slow Mode: 3s</span>
          </div>

          {/* Messages stream */}
          <div className="flex-1 overflow-y-auto space-y-2.5 py-3 pr-1 text-xs">
            {chatMessages.map(msg => (
              <div key={msg.id} className="p-2 rounded-xl bg-white/5 hover:bg-white/10 transition-colors">
                <div className="flex items-center gap-1.5 mb-0.5">
                  {msg.badge && (
                    <span className="px-1.5 py-0.2 rounded text-[9px] font-black bg-[#53FC18] text-black">
                      {msg.badge}
                    </span>
                  )}
                  <span className="font-bold" style={{ color: msg.color }}>
                    {msg.user}:
                  </span>
                  <span className="text-[10px] text-white/30 ml-auto">{msg.time}</span>
                </div>
                <p className="text-[#EAF4FF] pl-1 break-words">{msg.message}</p>
              </div>
            ))}
            <div ref={chatEndRef} />
          </div>

          {/* Chat Input */}
          <form onSubmit={handleSendChat} className="pt-2 border-t border-white/10 flex items-center gap-2">
            <input
              type="text"
              value={inputMsg}
              onChange={e => setInputMsg(e.target.value)}
              placeholder="Send message to Sultan Squad..."
              className="flex-1 bg-white/5 border border-white/10 rounded-xl px-3 py-2 text-xs text-white placeholder-white/40 focus:outline-none focus:border-[#53FC18]"
            />
            <button
              type="submit"
              className="p-2 rounded-xl bg-[#53FC18] text-black font-bold hover:bg-[#46d614] transition-colors"
            >
              <Send className="w-4 h-4" />
            </button>
          </form>
        </div>
      </div>
    </div>
  );
};
