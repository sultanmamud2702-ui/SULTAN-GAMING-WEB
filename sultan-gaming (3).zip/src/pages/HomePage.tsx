import React, { useState, useEffect } from 'react';
import {
  ChevronLeft,
  ChevronRight,
  Play,
  ArrowRight,
  Radio,
  Gamepad2,
  Tv,
  Users,
  Flame,
  ExternalLink,
  Sparkles,
} from 'lucide-react';
import { useStore } from '../context/StoreContext';
import { PageId } from '../types';

export const HomePage: React.FC = () => {
  const {
    heroSlides,
    platforms,
    games,
    setCurrentPage,
    triggerConfetti,
  } = useStore();

  const [currentSlideIndex, setCurrentSlideIndex] = useState(0);
  const [isPaused, setIsPaused] = useState(false);

  const activeSlides = heroSlides.filter(s => s.active);

  // Auto slide
  useEffect(() => {
    if (activeSlides.length <= 1 || isPaused) return;
    const interval = setInterval(() => {
      setCurrentSlideIndex(prev => (prev + 1) % activeSlides.length);
    }, 6000);
    return () => clearInterval(interval);
  }, [activeSlides.length, isPaused]);

  const nextSlide = () => {
    setCurrentSlideIndex(prev => (prev + 1) % activeSlides.length);
  };

  const prevSlide = () => {
    setCurrentSlideIndex(prev => (prev - 1 + activeSlides.length) % activeSlides.length);
  };

  const currentSlide = activeSlides[currentSlideIndex] || activeSlides[0];

  const getPlatformCardStyle = (type: string) => {
    switch (type) {
      case 'youtube':
        return {
          cardClass: 'hover:border-[#FF0000]/60 hover:shadow-[0_0_25px_rgba(255,0,0,0.25)]',
          badgeBg: 'bg-[#FF0000]',
          accentText: 'text-[#FF0000]',
        };
      case 'kick':
        return {
          cardClass: 'hover:border-[#53FC18]/60 hover:shadow-[0_0_25px_rgba(83,252,24,0.25)]',
          badgeBg: 'bg-[#53FC18] text-black',
          accentText: 'text-[#53FC18]',
        };
      case 'discord':
        return {
          cardClass: 'hover:border-[#5865F2]/60 hover:shadow-[0_0_25px_rgba(88,101,242,0.25)]',
          badgeBg: 'bg-[#5865F2]',
          accentText: 'text-[#5865F2]',
        };
      case 'instagram':
        return {
          cardClass: 'hover:border-[#E1306C]/60 hover:shadow-[0_0_25px_rgba(225,48,108,0.25)]',
          badgeBg: 'bg-gradient-to-tr from-[#FD1D1D] to-[#833AB4]',
          accentText: 'text-[#E1306C]',
        };
      default:
        return {
          cardClass: 'hover:border-[#008CFF]/60',
          badgeBg: 'bg-[#008CFF]',
          accentText: 'text-[#008CFF]',
        };
    }
  };

  return (
    <div className="space-y-8 animate-in fade-in duration-300">
      {/* HERO SECTION - CINEMATIC CAROUSEL */}
      {currentSlide && (
        <section
          id="hero-carousel-section"
          className="relative w-full rounded-3xl overflow-hidden border border-white/15 shadow-2xl bg-[#041426]"
          onMouseEnter={() => setIsPaused(true)}
          onMouseLeave={() => setIsPaused(false)}
        >
          {/* Background Image with Dark Vignette and Gradient Overlay */}
          <div className="relative min-h-[360px] sm:min-h-[440px] md:min-h-[500px] flex items-center p-6 sm:p-10 md:p-12 overflow-hidden">
            <img
              src={currentSlide.bgImage}
              alt={currentSlide.title}
              className="absolute inset-0 w-full h-full object-cover object-center scale-105 transition-transform duration-1000 ease-out"
            />
            {/* Dark & Orange-Blue Ambient Glows */}
            <div className="absolute inset-0 bg-gradient-to-r from-[#020817] via-[#020817]/70 to-transparent" />
            <div className="absolute inset-0 bg-gradient-to-t from-[#020817] via-transparent to-black/30" />
            <div className="absolute -top-24 -left-24 w-96 h-96 bg-[#FF7A00]/20 rounded-full blur-[100px] pointer-events-none" />
            <div className="absolute -bottom-24 -right-24 w-96 h-96 bg-[#0066FF]/20 rounded-full blur-[100px] pointer-events-none" />

            {/* Los Santos Signature Script Watermark */}
            <div className="absolute top-6 right-8 text-3xl sm:text-5xl md:text-6xl font-serif italic text-white/10 select-none pointer-events-none tracking-widest">
              Los Santos
            </div>

            {/* Hero Content */}
            <div className="relative z-10 max-w-2xl space-y-4">
              {/* Category Pill with Orange Dot */}
              <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-black/60 border border-white/15 backdrop-blur-md">
                <span className="w-2 h-2 rounded-full bg-[#FF7A00] shadow-[0_0_8px_#FF7A00] animate-pulse" />
                <span className="text-[11px] sm:text-xs font-bold uppercase tracking-wider text-[#EAF4FF] font-['Space_Grotesk']">
                  {currentSlide.category}
                </span>
              </div>

              {/* Main Headline */}
              <h1 className="text-3xl sm:text-5xl md:text-6xl font-black uppercase tracking-tight text-white leading-none font-['Space_Grotesk']">
                <span className="block italic">{currentSlide.title}</span>
                <span className="block text-transparent bg-clip-text bg-gradient-to-r from-[#FF7A00] via-[#FF9500] to-[#FFB000] drop-shadow-[0_0_20px_rgba(255,122,0,0.5)]">
                  {currentSlide.titleHighlight}
                </span>
              </h1>

              {/* Subheading / Description */}
              <p className="text-sm sm:text-base text-[#B8C7D9] font-medium max-w-xl leading-relaxed">
                {currentSlide.description}
              </p>

              {/* Action Buttons */}
              <div className="flex flex-wrap items-center gap-3.5 pt-2">
                <button
                  id="hero-primary-btn"
                  onClick={() => setCurrentPage(currentSlide.primaryBtnUrl as PageId)}
                  className="flex items-center gap-2 px-6 py-3 rounded-full bg-gradient-to-r from-[#FF7A00] to-[#FF9500] text-white font-bold text-xs sm:text-sm tracking-wide shadow-[0_0_20px_rgba(255,122,0,0.5)] hover:scale-105 active:scale-95 transition-all group"
                >
                  <Play className="w-4 h-4 fill-current group-hover:scale-110 transition-transform" />
                  <span>{currentSlide.primaryBtnText}</span>
                  <ChevronRight className="w-4 h-4 group-hover:translate-x-0.5 transition-transform" />
                </button>

                <button
                  id="hero-secondary-btn"
                  onClick={() => setCurrentPage(currentSlide.secondaryBtnUrl as PageId)}
                  className="flex items-center gap-2 px-6 py-3 rounded-full bg-[#041426]/80 border border-white/20 text-[#EAF4FF] font-bold text-xs sm:text-sm tracking-wide hover:bg-white/10 hover:border-white/40 active:scale-95 backdrop-blur-md transition-all group"
                >
                  <span>{currentSlide.secondaryBtnText}</span>
                  <ChevronRight className="w-4 h-4 text-[#00B7FF] group-hover:translate-x-0.5 transition-transform" />
                </button>
              </div>

              {/* Pagination Dots */}
              <div className="flex items-center gap-2 pt-4">
                {activeSlides.map((_, idx) => (
                  <button
                    key={idx}
                    onClick={() => setCurrentSlideIndex(idx)}
                    className={`h-2 rounded-full transition-all duration-300 ${
                      idx === currentSlideIndex
                        ? 'w-8 bg-[#FF7A00] shadow-[0_0_8px_#FF7A00]'
                        : 'w-2 bg-white/30 hover:bg-white/60'
                    }`}
                    aria-label={`Go to slide ${idx + 1}`}
                  />
                ))}
              </div>
            </div>

            {/* Left & Right Arrow Navigation */}
            <button
              id="hero-prev-slide-btn"
              onClick={prevSlide}
              className="absolute left-3 sm:left-4 top-1/2 -translate-y-1/2 z-20 p-2.5 rounded-full bg-black/50 border border-white/15 text-white/80 hover:text-white hover:bg-black/80 hover:scale-110 backdrop-blur-md transition-all"
              aria-label="Previous slide"
            >
              <ChevronLeft className="w-5 h-5" />
            </button>

            <button
              id="hero-next-slide-btn"
              onClick={nextSlide}
              className="absolute right-3 sm:right-4 top-1/2 -translate-y-1/2 z-20 p-2.5 rounded-full bg-black/50 border border-white/15 text-white/80 hover:text-white hover:bg-black/80 hover:scale-110 backdrop-blur-md transition-all"
              aria-label="Next slide"
            >
              <ChevronRight className="w-5 h-5" />
            </button>
          </div>
        </section>
      )}

      {/* POPULAR PLATFORMS SECTION */}
      <section id="popular-platforms-section" className="space-y-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <h2 className="text-xl sm:text-2xl font-black text-white uppercase tracking-tight font-['Space_Grotesk']">
              Popular Platforms
            </h2>
          </div>
          <button
            id="view-all-platforms-btn"
            onClick={() => setCurrentPage('youtube')}
            className="flex items-center gap-1 text-xs font-semibold text-[#00B7FF] hover:text-[#008CFF] group"
          >
            <span>View all</span>
            <ArrowRight className="w-3.5 h-3.5 group-hover:translate-x-1 transition-transform" />
          </button>
        </div>

        {/* Platforms Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          {platforms.map(platform => {
            const style = getPlatformCardStyle(platform.type);
            return (
              <div
                key={platform.id}
                id={`popular-platform-card-${platform.id}`}
                onClick={() => setCurrentPage(platform.type as PageId)}
                className={`relative flex items-center justify-between p-4 rounded-2xl bg-[#041426]/75 border border-white/10 backdrop-blur-md cursor-pointer transition-all duration-300 group hover:-translate-y-1 ${style.cardClass}`}
              >
                <div className="flex items-center gap-3.5">
                  {/* Platform Logo Box */}
                  <div
                    className={`w-12 h-12 rounded-xl flex items-center justify-center p-2.5 shadow-md flex-shrink-0 ${style.badgeBg}`}
                  >
                    {platform.type === 'youtube' && (
                      <svg viewBox="0 0 24 24" fill="currentColor" className="w-6 h-6 text-white">
                        <path d="M23.498 6.186a3.016 3.016 0 0 0-2.122-2.136C19.505 3.545 12 3.545 12 3.545s-7.505 0-9.377.505A3.017 3.017 0 0 0 .502 6.186C0 8.07 0 12 0 12s0 3.93.502 5.814a3.016 3.016 0 0 0 2.122 2.136c1.871.505 9.376.505 9.376.505s7.505 0 9.377-.505a3.015 3.015 0 0 0 2.122-2.136C24 15.93 24 12 24 12s0-3.93-.502-5.814zM9.545 15.568V8.432L15.818 12l-6.273 3.568z" />
                      </svg>
                    )}
                    {platform.type === 'kick' && (
                      <span className="font-black text-xl font-mono text-black">K</span>
                    )}
                    {platform.type === 'discord' && (
                      <svg viewBox="0 0 24 24" fill="currentColor" className="w-6 h-6 text-white">
                        <path d="M20.317 4.37a19.791 19.791 0 0 0-4.885-1.515.074.074 0 0 0-.079.037c-.21.375-.444.864-.608 1.25a18.27 18.27 0 0 0-5.487 0 12.64 12.64 0 0 0-.617-1.25.077.077 0 0 0-.079-.037A19.736 19.736 0 0 0 3.677 4.37a.07.07 0 0 0-.032.027C.533 9.046-.32 13.58.099 18.057a.082.082 0 0 0 .031.057 19.9 19.9 0 0 0 5.993 3.03.078.078 0 0 0 .084-.028c.462-.63.874-1.295 1.226-1.994.021-.041.001-.09-.041-.106a13.107 13.107 0 0 1-1.872-.892.077.077 0 0 1-.008-.128 10.2 10.2 0 0 0 .372-.292.074.074 0 0 1 .077-.01c3.929 1.793 8.18 1.793 12.061 0a.074.074 0 0 1 .078.01c.12.098.246.198.373.292a.077.077 0 0 1-.006.127 12.299 12.299 0 0 1-1.873.893.077.077 0 0 0-.041.107c.36.698.772 1.362 1.225 1.993a.076.076 0 0 0 .084.028 19.839 19.839 0 0 0 6.002-3.03.077.077 0 0 0 .032-.054c.5-5.177-.838-9.674-3.549-13.66a.061.061 0 0 0-.031-.028zM8.02 15.33c-1.183 0-2.157-1.085-2.157-2.419 0-1.333.956-2.419 2.157-2.419 1.21 0 2.176 1.096 2.157 2.42 0 1.333-.956 2.418-2.157 2.418zm7.975 0c-1.183 0-2.157-1.085-2.157-2.419 0-1.333.955-2.419 2.157-2.419 1.21 0 2.176 1.096 2.157 2.42 0 1.333-.946 2.418-2.157 2.418z" />
                      </svg>
                    )}
                    {platform.type === 'instagram' && (
                      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="w-6 h-6 text-white">
                        <rect x="2" y="2" width="20" height="20" rx="5" ry="5" />
                        <path d="M16 11.37A4 4 0 1 1 12.63 8 4 4 0 0 1 16 11.37z" />
                        <line x1="17.5" y1="6.5" x2="17.51" y2="6.5" />
                      </svg>
                    )}
                  </div>

                  {/* Info */}
                  <div>
                    <h3 className="text-sm font-bold text-white group-hover:text-white flex items-center gap-1.5">
                      <span>{platform.name}</span>
                      {platform.liveStatus && (
                        <span className="flex h-2 w-2 relative">
                          <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-[#53FC18] opacity-75" />
                          <span className="relative inline-flex rounded-full h-2 w-2 bg-[#53FC18]" />
                        </span>
                      )}
                    </h3>
                    <p className="text-xs text-[#B8C7D9] font-medium">{platform.followers}</p>
                  </div>
                </div>

                <ChevronRight className="w-4 h-4 text-white/40 group-hover:text-white group-hover:translate-x-1 transition-all" />
              </div>
            );
          })}
        </div>
      </section>

      {/* FEATURED GAMES SECTION */}
      <section id="featured-games-section" className="space-y-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <h2 className="text-xl sm:text-2xl font-black text-white uppercase tracking-tight font-['Space_Grotesk']">
              Featured Games
            </h2>
          </div>
          <button
            id="view-all-games-btn"
            onClick={() => setCurrentPage('game-gta-5-online')}
            className="flex items-center gap-1 text-xs font-semibold text-[#00B7FF] hover:text-[#008CFF] group"
          >
            <span>View all</span>
            <ArrowRight className="w-3.5 h-3.5 group-hover:translate-x-1 transition-transform" />
          </button>
        </div>

        {/* Games Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          {games.map(game => (
            <div
              key={game.id}
              id={`featured-game-card-${game.slug}`}
              onClick={() => setCurrentPage(`game-${game.slug}` as PageId)}
              className="group relative rounded-2xl overflow-hidden bg-[#041426]/80 border border-white/10 hover:border-[#FF7A00]/70 backdrop-blur-md cursor-pointer transition-all duration-300 hover:-translate-y-1.5 hover:shadow-[0_0_30px_rgba(255,122,0,0.2)]"
            >
              {/* Game Banner Image */}
              <div className="relative h-44 sm:h-48 w-full overflow-hidden bg-black/60">
                <img
                  src={game.banner}
                  alt={game.title}
                  className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500 ease-out"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-[#041426] via-transparent to-black/20" />

                {/* Floating Game Logo */}
                <div className="absolute top-3 left-3 w-8 h-8 rounded-lg bg-black/60 backdrop-blur-md border border-white/20 p-1 flex items-center justify-center">
                  <img
                    src={game.logo}
                    alt=""
                    className="w-full h-full object-contain"
                    onError={e => {
                      (e.target as HTMLElement).style.display = 'none';
                    }}
                  />
                </div>
              </div>

              {/* Game Info Bottom */}
              <div className="p-4 flex items-center justify-between gap-2">
                <div>
                  <h3 className="text-sm sm:text-base font-bold text-white group-hover:text-[#FF9500] transition-colors">
                    {game.title}
                  </h3>
                  <p className="text-xs text-[#B8C7D9] font-medium mt-0.5">
                    {game.shortDescription}
                  </p>
                </div>

                <div className="w-8 h-8 rounded-full bg-white/5 group-hover:bg-[#FF7A00] flex items-center justify-center text-white/60 group-hover:text-white transition-all flex-shrink-0">
                  <ChevronRight className="w-4 h-4 group-hover:translate-x-0.5 transition-transform" />
                </div>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* QUICK COMMUNITY & GIVEAWAY PROMO TEASER */}
      <section className="grid grid-cols-1 md:grid-cols-2 gap-4 pt-2">
        {/* Giveaway Card */}
        <div
          onClick={() => setCurrentPage('giveaways')}
          className="p-6 rounded-3xl bg-gradient-to-br from-[#FF7A00]/20 via-[#061B2E] to-[#041426] border border-[#FF7A00]/40 hover:border-[#FF7A00] backdrop-blur-xl cursor-pointer transition-all hover:scale-[1.01] shadow-xl group"
        >
          <div className="flex items-center gap-2 text-[#FF9500] text-xs font-bold uppercase tracking-wider mb-2">
            <Sparkles className="w-4 h-4" />
            <span>COMMUNITY GIVEAWAY</span>
          </div>
          <h3 className="text-xl sm:text-2xl font-black text-white font-['Space_Grotesk'] uppercase">
            Luxury Mansions Edition
          </h3>
          <p className="text-xs text-[#B8C7D9] mt-1 line-clamp-2">
            Win a Los Santos luxury estate with 10-car garage, pool complex, and personal cinema.
          </p>
          <div className="mt-4 inline-flex items-center gap-2 px-4 py-2 rounded-full bg-[#FF7A00] text-white font-bold text-xs shadow-[0_0_12px_rgba(255,122,0,0.5)] group-hover:scale-105 transition-transform">
            <span>Enter Giveaway</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </div>
        </div>

        {/* Live Stream Kick Hub */}
        <div
          onClick={() => setCurrentPage('kick')}
          className="p-6 rounded-3xl bg-gradient-to-br from-[#53FC18]/20 via-[#061B2E] to-[#041426] border border-[#53FC18]/40 hover:border-[#53FC18] backdrop-blur-xl cursor-pointer transition-all hover:scale-[1.01] shadow-xl group"
        >
          <div className="flex items-center gap-2 text-[#53FC18] text-xs font-bold uppercase tracking-wider mb-2">
            <span className="w-2 h-2 rounded-full bg-[#53FC18] animate-ping" />
            <span>KICK LIVE STREAM</span>
          </div>
          <h3 className="text-xl sm:text-2xl font-black text-white font-['Space_Grotesk'] uppercase">
            Sultan Gaming Live Now
          </h3>
          <p className="text-xs text-[#B8C7D9] mt-1 line-clamp-2">
            Join the Sultan Squad for live GTA 5 races, viewer heists, and daily game giveaways!
          </p>
          <div className="mt-4 inline-flex items-center gap-2 px-4 py-2 rounded-full bg-[#53FC18] text-black font-black text-xs shadow-[0_0_12px_rgba(83,252,24,0.5)] group-hover:scale-105 transition-transform">
            <span>Watch Live Stream</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </div>
        </div>
      </section>
    </div>
  );
};
