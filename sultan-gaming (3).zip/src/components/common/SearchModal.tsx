import React, { useState, useEffect, useRef } from 'react';
import { Search, X, Gamepad2, Tv, Users, Gift, HelpCircle, Laptop, ArrowRight, Sparkles } from 'lucide-react';
import { useStore } from '../../context/StoreContext';
import { PageId } from '../../types';

export const SearchModal: React.FC = () => {
  const {
    isSearchOpen,
    closeSearch,
    setCurrentPage,
    games,
    platforms,
    videos,
    posts,
    giveaways,
    faqs,
    pcSpecs,
  } = useStore();

  const [query, setQuery] = useState('');
  const [activeCategory, setActiveCategory] = useState<'all' | 'games' | 'videos' | 'community' | 'giveaways' | 'faq' | 'specs'>('all');
  const inputRef = useRef<HTMLInputElement>(null);

  // Keyboard shortcut listener
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if ((e.metaKey || e.ctrlKey) && e.key === 'k') {
        e.preventDefault();
        if (isSearchOpen) closeSearch();
        else useStore().openSearch();
      }
      if (e.key === 'Escape' && isSearchOpen) {
        closeSearch();
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isSearchOpen, closeSearch]);

  useEffect(() => {
    if (isSearchOpen) {
      setTimeout(() => inputRef.current?.focus(), 50);
    } else {
      setQuery('');
    }
  }, [isSearchOpen]);

  if (!isSearchOpen) return null;

  const q = query.toLowerCase().trim();

  // Search Results
  const matchedGames = games.filter(
    g => !q || g.title.toLowerCase().includes(q) || g.genre.toLowerCase().includes(q) || g.tags.some(t => t.toLowerCase().includes(q))
  );

  const matchedPlatforms = platforms.filter(
    p => !q || p.name.toLowerCase().includes(q) || p.description.toLowerCase().includes(q)
  );

  const matchedVideos = videos.filter(
    v => !q || v.title.toLowerCase().includes(q) || v.gameSlug.toLowerCase().includes(q)
  );

  const matchedPosts = posts.filter(
    p => !q || p.content.toLowerCase().includes(q) || p.gameTag.toLowerCase().includes(q) || p.author.name.toLowerCase().includes(q)
  );

  const matchedGiveaways = giveaways.filter(
    g => !q || g.title.toLowerCase().includes(q) || g.edition.toLowerCase().includes(q)
  );

  const matchedFaqs = faqs.filter(
    f => !q || f.question.toLowerCase().includes(q) || f.answer.toLowerCase().includes(q)
  );

  const matchedSpecs = pcSpecs.filter(
    s => !q || s.name.toLowerCase().includes(q) || s.specs.toLowerCase().includes(q) || s.description.toLowerCase().includes(q)
  );

  const totalResults =
    (activeCategory === 'all' || activeCategory === 'games' ? matchedGames.length : 0) +
    (activeCategory === 'all' || activeCategory === 'videos' ? matchedVideos.length : 0) +
    (activeCategory === 'all' || activeCategory === 'community' ? matchedPosts.length : 0) +
    (activeCategory === 'all' || activeCategory === 'giveaways' ? matchedGiveaways.length : 0) +
    (activeCategory === 'all' || activeCategory === 'faq' ? matchedFaqs.length : 0) +
    (activeCategory === 'all' || activeCategory === 'specs' ? matchedSpecs.length : 0);

  const handleSelect = (page: PageId) => {
    setCurrentPage(page);
    closeSearch();
  };

  return (
    <div
      id="global-search-modal"
      className="fixed inset-0 z-50 flex items-start justify-center pt-16 sm:pt-24 px-4 bg-black/80 backdrop-blur-md animate-in fade-in duration-200"
      onClick={closeSearch}
    >
      <div
        className="w-full max-w-3xl rounded-3xl bg-[#041426]/95 border border-white/15 p-4 sm:p-6 shadow-2xl backdrop-blur-2xl flex flex-col max-h-[80vh] overflow-hidden"
        onClick={e => e.stopPropagation()}
      >
        {/* Search Input Bar */}
        <div className="relative flex items-center border-b border-white/10 pb-3">
          <Search className="w-5 h-5 text-[#FF9500] absolute left-2" />
          <input
            ref={inputRef}
            type="text"
            id="global-search-modal-input"
            value={query}
            onChange={e => setQuery(e.target.value)}
            placeholder="Search Sultan Gaming (GTA 5, Minecraft, Giveaways, PC Specs, Videos...)"
            className="w-full bg-transparent pl-10 pr-10 text-white placeholder-white/40 text-sm sm:text-base focus:outline-none"
          />
          {query && (
            <button
              onClick={() => setQuery('')}
              className="p-1 rounded-full text-white/50 hover:text-white mr-2"
            >
              <X className="w-4 h-4" />
            </button>
          )}
          <button
            onClick={closeSearch}
            className="px-2 py-1 rounded-lg bg-white/5 text-[11px] text-[#B8C7D9] hover:bg-white/10"
          >
            ESC
          </button>
        </div>

        {/* Filter chips */}
        <div className="flex items-center gap-1.5 py-3 overflow-x-auto text-xs scrollbar-none">
          {[
            { id: 'all', label: 'All' },
            { id: 'games', label: 'Games', count: matchedGames.length },
            { id: 'videos', label: 'Videos', count: matchedVideos.length },
            { id: 'community', label: 'Community', count: matchedPosts.length },
            { id: 'giveaways', label: 'Giveaways', count: matchedGiveaways.length },
            { id: 'specs', label: 'PC Specs', count: matchedSpecs.length },
            { id: 'faq', label: 'FAQ', count: matchedFaqs.length },
          ].map(cat => (
            <button
              key={cat.id}
              onClick={() => setActiveCategory(cat.id as any)}
              className={`px-3 py-1 rounded-full font-medium whitespace-nowrap transition-colors flex items-center gap-1 ${
                activeCategory === cat.id
                  ? 'bg-gradient-to-r from-[#FF7A00] to-[#FF9500] text-white shadow-sm'
                  : 'bg-white/5 text-[#B8C7D9] hover:text-white hover:bg-white/10'
              }`}
            >
              <span>{cat.label}</span>
              {cat.count !== undefined && (
                <span className="text-[10px] opacity-70">({cat.count})</span>
              )}
            </button>
          ))}
        </div>

        {/* Results List */}
        <div className="flex-1 overflow-y-auto space-y-4 py-2 pr-1">
          {totalResults === 0 ? (
            <div className="py-12 text-center text-white/50 text-sm">
              <p>No matches found for "{query}".</p>
              <p className="text-xs text-white/30 mt-1">Try searching "GTA", "giveaway", "RTX 4090", or "Minecraft".</p>
            </div>
          ) : (
            <>
              {/* Games Category */}
              {(activeCategory === 'all' || activeCategory === 'games') && matchedGames.length > 0 && (
                <div className="space-y-1.5">
                  <div className="text-[11px] font-bold text-[#FF9500] uppercase tracking-wider px-2">
                    Games ({matchedGames.length})
                  </div>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                    {matchedGames.map(g => (
                      <div
                        key={g.id}
                        onClick={() => handleSelect(`game-${g.slug}` as PageId)}
                        className="flex items-center gap-3 p-2.5 rounded-2xl bg-white/5 hover:bg-white/10 border border-white/5 hover:border-[#FF7A00]/40 cursor-pointer transition-all group"
                      >
                        <img
                          src={g.coverImage}
                          alt={g.title}
                          className="w-12 h-12 rounded-xl object-cover"
                        />
                        <div className="flex-1 min-w-0">
                          <h4 className="text-xs font-bold text-white group-hover:text-[#FF9500] truncate">
                            {g.title}
                          </h4>
                          <p className="text-[11px] text-[#B8C7D9] truncate">{g.shortDescription}</p>
                          <span className="text-[10px] text-white/40">{g.genre}</span>
                        </div>
                        <ArrowRight className="w-4 h-4 text-white/30 group-hover:text-[#FF7A00] group-hover:translate-x-0.5 transition-all" />
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* Videos */}
              {(activeCategory === 'all' || activeCategory === 'videos') && matchedVideos.length > 0 && (
                <div className="space-y-1.5 pt-2">
                  <div className="text-[11px] font-bold text-[#00B7FF] uppercase tracking-wider px-2">
                    Videos & Streams ({matchedVideos.length})
                  </div>
                  <div className="space-y-1.5">
                    {matchedVideos.map(v => (
                      <div
                        key={v.id}
                        onClick={() => handleSelect(v.platform as PageId)}
                        className="flex items-center gap-3 p-2 rounded-2xl bg-white/5 hover:bg-white/10 border border-white/5 hover:border-[#008CFF]/40 cursor-pointer transition-all group"
                      >
                        <div className="relative w-16 h-10 rounded-lg overflow-hidden flex-shrink-0">
                          <img src={v.thumbnail} alt={v.title} className="w-full h-full object-cover" />
                          <span className="absolute bottom-0.5 right-0.5 text-[9px] bg-black/80 px-1 rounded font-mono text-white">
                            {v.duration}
                          </span>
                        </div>
                        <div className="flex-1 min-w-0">
                          <h4 className="text-xs font-semibold text-white group-hover:text-[#00B7FF] truncate">
                            {v.title}
                          </h4>
                          <p className="text-[11px] text-white/50">{v.views} • {v.uploadDate}</p>
                        </div>
                        <span className="text-[10px] font-bold uppercase px-2 py-0.5 rounded bg-white/10 text-white/70">
                          {v.platform}
                        </span>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* Giveaways */}
              {(activeCategory === 'all' || activeCategory === 'giveaways') && matchedGiveaways.length > 0 && (
                <div className="space-y-1.5 pt-2">
                  <div className="text-[11px] font-bold text-[#FF9500] uppercase tracking-wider px-2">
                    Giveaways ({matchedGiveaways.length})
                  </div>
                  {matchedGiveaways.map(g => (
                    <div
                      key={g.id}
                      onClick={() => handleSelect('giveaways')}
                      className="flex items-center gap-3 p-2.5 rounded-2xl bg-[#FF7A00]/10 border border-[#FF7A00]/30 hover:border-[#FF7A00] cursor-pointer transition-all group"
                    >
                      <Gift className="w-6 h-6 text-[#FF9500] flex-shrink-0" />
                      <div className="flex-1 min-w-0">
                        <h4 className="text-xs font-bold text-white group-hover:text-[#FF9500]">
                          {g.title}: {g.edition}
                        </h4>
                        <p className="text-[11px] text-[#B8C7D9] line-clamp-1">{g.description}</p>
                      </div>
                      <span className="text-xs font-bold text-[#FF9500] bg-black/40 px-2.5 py-1 rounded-full">
                        Enter to Win
                      </span>
                    </div>
                  ))}
                </div>
              )}

              {/* PC Specs */}
              {(activeCategory === 'all' || activeCategory === 'specs') && matchedSpecs.length > 0 && (
                <div className="space-y-1.5 pt-2">
                  <div className="text-[11px] font-bold text-[#53FC18] uppercase tracking-wider px-2">
                    Hardware & Specs ({matchedSpecs.length})
                  </div>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                    {matchedSpecs.map(s => (
                      <div
                        key={s.id}
                        onClick={() => handleSelect('pc-specs')}
                        className="flex items-center gap-3 p-2 rounded-2xl bg-white/5 hover:bg-white/10 border border-white/5 hover:border-[#53FC18]/40 cursor-pointer transition-all group"
                      >
                        <img src={s.image} alt={s.name} className="w-10 h-10 rounded-lg object-cover" />
                        <div className="flex-1 min-w-0">
                          <h4 className="text-xs font-bold text-white group-hover:text-[#53FC18] truncate">
                            {s.name}
                          </h4>
                          <p className="text-[10px] text-white/50 truncate">{s.specs}</p>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* FAQ */}
              {(activeCategory === 'all' || activeCategory === 'faq') && matchedFaqs.length > 0 && (
                <div className="space-y-1.5 pt-2">
                  <div className="text-[11px] font-bold text-[#B8C7D9] uppercase tracking-wider px-2">
                    FAQ & Help ({matchedFaqs.length})
                  </div>
                  {matchedFaqs.map(f => (
                    <div
                      key={f.id}
                      onClick={() => handleSelect('faq')}
                      className="p-2.5 rounded-2xl bg-white/5 hover:bg-white/10 border border-white/5 cursor-pointer transition-all"
                    >
                      <h4 className="text-xs font-semibold text-white">{f.question}</h4>
                      <p className="text-[11px] text-[#B8C7D9] line-clamp-1 mt-0.5">{f.answer}</p>
                    </div>
                  ))}
                </div>
              )}
            </>
          )}
        </div>

        {/* Quick Footer hint */}
        <div className="pt-2 border-t border-white/10 flex items-center justify-between text-[11px] text-white/40">
          <span>Tip: Navigate using shortcuts and arrows</span>
          <span>Sultan Gaming Hub</span>
        </div>
      </div>
    </div>
  );
};
