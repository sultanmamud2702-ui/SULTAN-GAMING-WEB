import React, { useState } from 'react';
import {
  X,
  ShieldCheck,
  CheckCircle2,
  Crown,
  User as UserIcon,
  Lock,
  ArrowRight,
  AlertCircle,
  LogIn,
  UserPlus,
  Mail,
  RefreshCw,
  Copy,
  Check,
} from 'lucide-react';
import { useStore } from '../../context/StoreContext';
import { BrandLogo } from './BrandLogo';
import { UserRole } from '../../types';

export const AuthModal: React.FC = () => {
  const {
    authModalOpen,
    setAuthModalOpen,
    signInWithEmail,
    signUpWithEmail,
    signInWithGoogle,
    resendVerificationEmail,
    devSwitchRole,
    currentUser,
  } = useStore();

  const [activeTab, setActiveTab] = useState<'signin' | 'signup' | 'test-roles'>('signin');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [verificationEmail, setVerificationEmail] = useState<string | null>(null);
  const [resendStatus, setResendStatus] = useState<string | null>(null);
  const [copiedDomain, setCopiedDomain] = useState(false);
  const [isLoading, setIsLoading] = useState(false);

  if (!authModalOpen) return null;

  const handleTabChange = (tab: 'signin' | 'signup' | 'test-roles') => {
    setActiveTab(tab);
    setErrorMessage(null);
    setVerificationEmail(null);
    setResendStatus(null);
  };

  const handleGoogleSignIn = async () => {
    setErrorMessage(null);
    setResendStatus(null);
    setIsLoading(true);
    const result = await signInWithGoogle();
    setIsLoading(false);
    if (!result.success) {
      setErrorMessage(result.error || 'Failed to sign in with Google.');
    }
  };

  const handleSignIn = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMessage(null);
    setResendStatus(null);

    if (!email.trim() || !password) {
      setErrorMessage('Please enter both email and password');
      return;
    }

    setIsLoading(true);
    const result = await signInWithEmail(email, password);
    setIsLoading(false);

    if (result.requiresVerification) {
      // If a user logs in and their email is not verified, block access and show the verification screen
      setVerificationEmail(result.email || email.trim());
      setErrorMessage(null);
    } else if (!result.success) {
      setErrorMessage(result.error || 'Email or password is incorrect');
    } else {
      setEmail('');
      setPassword('');
      setVerificationEmail(null);
    }
  };

  const handleSignUp = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMessage(null);
    setResendStatus(null);

    if (!email.trim() || !password) {
      setErrorMessage('Please enter both email and password');
      return;
    }

    if (password.length < 6) {
      setErrorMessage('Password should be at least 6 characters');
      return;
    }

    setIsLoading(true);
    const result = await signUpWithEmail(email, password);
    setIsLoading(false);

    if (result.requiresVerification) {
      // Show verification screen with message and Login button
      setVerificationEmail(result.email || email.trim());
      setErrorMessage(null);
    } else if (!result.success) {
      setErrorMessage(result.error || 'Failed to create account');
    }
  };

  const handleResend = async () => {
    if (!verificationEmail) return;
    setIsLoading(true);
    setResendStatus(null);
    const result = await resendVerificationEmail(verificationEmail, password || undefined);
    setIsLoading(false);
    if (result.success) {
      setResendStatus('Verification email resent successfully!');
    } else {
      setResendStatus(result.error || 'Could not resend email.');
    }
  };

  const handleSwitchRole = async (role: UserRole) => {
    setIsLoading(true);
    await devSwitchRole(role);
    setIsLoading(false);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md animate-in fade-in duration-200">
      <div
        className="relative w-full max-w-lg bg-[#061B2E] border border-white/15 rounded-3xl p-6 sm:p-8 shadow-2xl overflow-hidden"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Ambient Top Glow */}
        <div className="absolute top-0 left-1/2 -translate-x-1/2 w-64 h-32 bg-gradient-to-b from-[#FF7A00]/20 to-transparent blur-3xl pointer-events-none" />

        {/* Close Button */}
        <button
          id="close-auth-modal-btn"
          onClick={() => {
            setAuthModalOpen(false);
            setErrorMessage(null);
            setVerificationEmail(null);
          }}
          className="absolute top-5 right-5 p-2 rounded-full bg-white/5 hover:bg-white/10 text-white/70 hover:text-white transition-colors"
          aria-label="Close modal"
        >
          <X className="w-5 h-5" />
        </button>

        {/* VERIFICATION SCREEN */}
        {verificationEmail ? (
          <div className="flex flex-col items-center text-center py-2 animate-in fade-in zoom-in-95 duration-200">
            {/* Animated Mail Icon Badge */}
            <div className="relative mb-5">
              <div className="w-20 h-20 rounded-3xl bg-gradient-to-br from-[#FF7A00]/20 to-[#FF9500]/10 border border-[#FF7A00]/30 flex items-center justify-center text-[#FF9500] shadow-[0_0_30px_rgba(255,122,0,0.25)]">
                <Mail className="w-10 h-10 text-[#FF9500] animate-bounce" />
              </div>
              <div className="absolute -bottom-1.5 -right-1.5 w-7 h-7 rounded-full bg-[#008CFF] border-2 border-[#061B2E] flex items-center justify-center text-white shadow">
                <CheckCircle2 className="w-4 h-4 text-white" />
              </div>
            </div>

            <h3 className="text-2xl font-black text-white mb-2">Verify Your Email</h3>

            {/* Mandatory Message Container */}
            <div className="p-4 rounded-2xl bg-[#041426] border border-white/15 text-[#EAF4FF] text-sm leading-relaxed mb-6 max-w-md shadow-inner">
              <p>
                We have sent you a verification email to{' '}
                <span className="font-bold text-[#FF9500] underline break-all">{verificationEmail}</span>.
                Please verify it and log in.
              </p>
            </div>

            {resendStatus && (
              <div className="mb-4 text-xs font-medium text-[#00B7FF] bg-[#008CFF]/10 border border-[#008CFF]/30 px-3 py-2 rounded-xl">
                {resendStatus}
              </div>
            )}

            {/* Login Button on verification screen */}
            <button
              id="verification-login-btn"
              type="button"
              onClick={() => {
                setVerificationEmail(null);
                setActiveTab('signin');
                setErrorMessage(null);
              }}
              className="w-full py-3.5 rounded-xl bg-gradient-to-r from-[#FF7A00] to-[#FF9500] text-white font-bold text-sm hover:shadow-[0_0_20px_rgba(255,122,0,0.5)] transition-all flex items-center justify-center gap-2 active:scale-[0.98]"
            >
              <LogIn className="w-4 h-4" />
              <span>Login</span>
            </button>

            {/* Resend option */}
            <div className="mt-4 flex items-center justify-center gap-3">
              <button
                id="resend-verification-email-btn"
                type="button"
                onClick={handleResend}
                disabled={isLoading}
                className="text-xs text-[#B8C7D9] hover:text-white flex items-center gap-1.5 transition-colors"
              >
                <RefreshCw className={`w-3 h-3 ${isLoading ? 'animate-spin' : ''}`} />
                <span>Didn't receive email? Resend</span>
              </button>
            </div>
          </div>
        ) : (
          <>
            {/* Header */}
            <div className="flex flex-col items-center text-center mb-6">
              <BrandLogo size="md" />
              <h3 className="text-xl font-bold text-white mt-4">
                {activeTab === 'signup'
                  ? 'Create Sultan Gaming Account'
                  : activeTab === 'signin'
                  ? 'Sign In to Sultan Gaming'
                  : 'Role-Based Access Control'}
              </h3>
              <p className="text-xs text-[#B8C7D9] mt-1 max-w-xs">
                {activeTab === 'signup'
                  ? 'Sign up with email and password to enter giveaways and join the community.'
                  : activeTab === 'signin'
                  ? 'Sign in to access your dashboard, participate in events, and chat.'
                  : 'Test server-side permissions and role switching instantly.'}
              </p>
            </div>

            {/* Navigation Tabs */}
            <div className="flex p-1 rounded-2xl bg-[#041426] border border-white/10 mb-6">
              <button
                id="auth-tab-signin-btn"
                type="button"
                onClick={() => handleTabChange('signin')}
                className={`flex-1 py-2 text-xs font-semibold rounded-xl transition-all flex items-center justify-center gap-1.5 ${
                  activeTab === 'signin'
                    ? 'bg-gradient-to-r from-[#FF7A00] to-[#FF9500] text-white shadow-md'
                    : 'text-[#B8C7D9] hover:text-white'
                }`}
              >
                <LogIn className="w-3.5 h-3.5" />
                <span>Sign In</span>
              </button>

              <button
                id="auth-tab-signup-btn"
                type="button"
                onClick={() => handleTabChange('signup')}
                className={`flex-1 py-2 text-xs font-semibold rounded-xl transition-all flex items-center justify-center gap-1.5 ${
                  activeTab === 'signup'
                    ? 'bg-gradient-to-r from-[#FF7A00] to-[#FF9500] text-white shadow-md'
                    : 'text-[#B8C7D9] hover:text-white'
                }`}
              >
                <UserPlus className="w-3.5 h-3.5" />
                <span>Sign Up</span>
              </button>

              <button
                id="auth-tab-test-roles-btn"
                type="button"
                onClick={() => handleTabChange('test-roles')}
                className={`flex-1 py-2 text-xs font-semibold rounded-xl transition-all flex items-center justify-center gap-1.5 ${
                  activeTab === 'test-roles'
                    ? 'bg-gradient-to-r from-[#008CFF] to-[#00B7FF] text-white shadow-md'
                    : 'text-[#B8C7D9] hover:text-white'
                }`}
              >
                <Crown className="w-3.5 h-3.5" />
                <span>Roles</span>
              </button>
            </div>

            {/* Error Message Box */}
            {errorMessage && (
              <div
                id="auth-error-alert"
                className="mb-5 p-3.5 rounded-2xl bg-red-500/10 border border-red-500/30 text-red-400 text-xs font-medium space-y-2 animate-in fade-in slide-in-from-top-1 duration-150"
              >
                <div className="flex items-start gap-2.5">
                  <AlertCircle className="w-4 h-4 flex-shrink-0 text-red-400 mt-0.5" />
                  <span className="flex-1 leading-relaxed">{errorMessage}</span>
                </div>

                {errorMessage.includes('Authorized Domains') && typeof window !== 'undefined' && (
                  <div className="pt-2 border-t border-red-500/20 flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-2">
                    <span className="font-mono text-[11px] bg-black/40 px-2 py-1 rounded text-white/90 truncate">
                      {window.location.hostname}
                    </span>
                    <button
                      type="button"
                      onClick={() => {
                        if (navigator.clipboard) {
                          navigator.clipboard.writeText(window.location.hostname);
                          setCopiedDomain(true);
                          setTimeout(() => setCopiedDomain(false), 2000);
                        }
                      }}
                      className="px-2.5 py-1 rounded-lg bg-red-500/20 hover:bg-red-500/30 text-white text-[11px] font-semibold flex items-center justify-center gap-1.5 transition-colors"
                    >
                      {copiedDomain ? <Check className="w-3.5 h-3.5 text-green-400" /> : <Copy className="w-3.5 h-3.5" />}
                      <span>{copiedDomain ? 'Domain Copied!' : 'Copy Domain'}</span>
                    </button>
                  </div>
                )}
              </div>
            )}

            {/* Tab 1: SIGN IN */}
            {activeTab === 'signin' && (
              <div className="space-y-4">
                {/* Continue with Google */}
                <button
                  id="auth-google-signin-btn"
                  type="button"
                  onClick={handleGoogleSignIn}
                  disabled={isLoading}
                  className="w-full py-3 px-4 rounded-xl bg-white hover:bg-gray-100 text-gray-900 font-semibold text-sm shadow-md transition-all flex items-center justify-center gap-3 active:scale-[0.98] disabled:opacity-50"
                >
                  <svg className="w-5 h-5 flex-shrink-0" viewBox="0 0 24 24">
                    <path
                      fill="#4285F4"
                      d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"
                    />
                    <path
                      fill="#34A853"
                      d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"
                    />
                    <path
                      fill="#FBBC05"
                      d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.06H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.94l2.85-2.22.81-.63z"
                    />
                    <path
                      fill="#EA4335"
                      d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.06l3.66 2.84c.87-2.6 3.3-4.52 6.16-4.52z"
                    />
                  </svg>
                  <span>{isLoading ? 'Connecting to Google...' : 'Continue with Google'}</span>
                </button>

                {/* Divider */}
                <div className="relative my-3 flex items-center justify-center">
                  <div className="border-t border-white/10 w-full" />
                  <span className="bg-[#061B2E] px-3 text-[11px] font-semibold text-[#B8C7D9] uppercase tracking-wider">
                    or sign in with email
                  </span>
                  <div className="border-t border-white/10 w-full" />
                </div>

                <form onSubmit={handleSignIn} className="space-y-4">
                  <div>
                    <label className="block text-xs font-semibold text-[#B8C7D9] mb-1.5">Email Address</label>
                    <input
                      type="email"
                      id="auth-signin-email"
                      required
                      value={email}
                      onChange={(e) => {
                        setEmail(e.target.value);
                        if (errorMessage) setErrorMessage(null);
                      }}
                      placeholder="you@example.com"
                      className="w-full px-4 py-2.5 rounded-xl bg-[#041426] border border-white/15 text-white placeholder-white/30 text-sm focus:outline-none focus:border-[#FF7A00] transition-colors"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-[#B8C7D9] mb-1.5">Password</label>
                    <input
                      type="password"
                      id="auth-signin-password"
                      required
                      value={password}
                      onChange={(e) => {
                        setPassword(e.target.value);
                        if (errorMessage) setErrorMessage(null);
                      }}
                      placeholder="••••••••"
                      className="w-full px-4 py-2.5 rounded-xl bg-[#041426] border border-white/15 text-white placeholder-white/30 text-sm focus:outline-none focus:border-[#FF7A00] transition-colors"
                    />
                  </div>

                  <button
                    type="submit"
                    id="auth-submit-signin-btn"
                    disabled={isLoading}
                    className="w-full py-3 rounded-xl bg-gradient-to-r from-[#FF7A00] to-[#FF9500] text-white font-bold text-sm hover:shadow-[0_0_20px_rgba(255,122,0,0.5)] transition-all flex items-center justify-center gap-2 active:scale-[0.98] disabled:opacity-50"
                  >
                    <span>{isLoading ? 'Signing In...' : 'Sign In with Email'}</span>
                    <ArrowRight className="w-4 h-4" />
                  </button>

                  <div className="text-center pt-2">
                    <p className="text-xs text-[#B8C7D9]">
                      Don't have an account?{' '}
                      <button
                        type="button"
                        id="switch-to-signup-link"
                        onClick={() => handleTabChange('signup')}
                        className="text-[#FF9500] font-semibold hover:underline"
                      >
                        Create one now
                      </button>
                    </p>
                  </div>
                </form>
              </div>
            )}

            {/* Tab 2: SIGN UP */}
            {activeTab === 'signup' && (
              <div className="space-y-4">
                {/* Continue with Google */}
                <button
                  id="auth-google-signup-btn"
                  type="button"
                  onClick={handleGoogleSignIn}
                  disabled={isLoading}
                  className="w-full py-3 px-4 rounded-xl bg-white hover:bg-gray-100 text-gray-900 font-semibold text-sm shadow-md transition-all flex items-center justify-center gap-3 active:scale-[0.98] disabled:opacity-50"
                >
                  <svg className="w-5 h-5 flex-shrink-0" viewBox="0 0 24 24">
                    <path
                      fill="#4285F4"
                      d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"
                    />
                    <path
                      fill="#34A853"
                      d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"
                    />
                    <path
                      fill="#FBBC05"
                      d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.06H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.94l2.85-2.22.81-.63z"
                    />
                    <path
                      fill="#EA4335"
                      d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.06l3.66 2.84c.87-2.6 3.3-4.52 6.16-4.52z"
                    />
                  </svg>
                  <span>{isLoading ? 'Connecting to Google...' : 'Continue with Google'}</span>
                </button>

                {/* Divider */}
                <div className="relative my-3 flex items-center justify-center">
                  <div className="border-t border-white/10 w-full" />
                  <span className="bg-[#061B2E] px-3 text-[11px] font-semibold text-[#B8C7D9] uppercase tracking-wider">
                    or register with email
                  </span>
                  <div className="border-t border-white/10 w-full" />
                </div>

                <form onSubmit={handleSignUp} className="space-y-4">
                  <div>
                    <label className="block text-xs font-semibold text-[#B8C7D9] mb-1.5">Email Address</label>
                    <input
                      type="email"
                      id="auth-signup-email"
                      required
                      value={email}
                      onChange={(e) => {
                        setEmail(e.target.value);
                        if (errorMessage) setErrorMessage(null);
                      }}
                      placeholder="you@example.com"
                      className="w-full px-4 py-2.5 rounded-xl bg-[#041426] border border-white/15 text-white placeholder-white/30 text-sm focus:outline-none focus:border-[#FF7A00] transition-colors"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-[#B8C7D9] mb-1.5">Password</label>
                    <input
                      type="password"
                      id="auth-signup-password"
                      required
                      value={password}
                      onChange={(e) => {
                        setPassword(e.target.value);
                        if (errorMessage) setErrorMessage(null);
                      }}
                      placeholder="At least 6 characters"
                      className="w-full px-4 py-2.5 rounded-xl bg-[#041426] border border-white/15 text-white placeholder-white/30 text-sm focus:outline-none focus:border-[#FF7A00] transition-colors"
                    />
                  </div>

                  <button
                    type="submit"
                    id="auth-submit-signup-btn"
                    disabled={isLoading}
                    className="w-full py-3 rounded-xl bg-gradient-to-r from-[#FF7A00] to-[#FF9500] text-white font-bold text-sm hover:shadow-[0_0_20px_rgba(255,122,0,0.5)] transition-all flex items-center justify-center gap-2 active:scale-[0.98] disabled:opacity-50"
                  >
                    <span>{isLoading ? 'Creating Account...' : 'Create Account with Email'}</span>
                    <ArrowRight className="w-4 h-4" />
                  </button>

                  <div className="text-center pt-2">
                    <p className="text-xs text-[#B8C7D9]">
                      Already have an account?{' '}
                      <button
                        type="button"
                        id="switch-to-signin-link"
                        onClick={() => handleTabChange('signin')}
                        className="text-[#FF9500] font-semibold hover:underline"
                      >
                        Sign in
                      </button>
                    </p>
                  </div>
                </form>
              </div>
            )}

            {/* Tab 3: ROLE SWITCHER (RBAC) */}
            {activeTab === 'test-roles' && (
              <div className="space-y-3">
                <p className="text-xs text-[#B8C7D9] mb-2">
                  Test server-side Role-Based Access Control (RBAC) instantly:
                </p>

                {/* Super Admin */}
                <button
                  id="auth-role-super-admin-btn"
                  type="button"
                  onClick={() => handleSwitchRole('SUPER_ADMIN')}
                  className={`w-full p-3 rounded-2xl border text-left flex items-center justify-between transition-all ${
                    currentUser?.role === 'SUPER_ADMIN'
                      ? 'bg-[#FF7A00]/15 border-[#FF7A00] shadow-[0_0_15px_rgba(255,122,0,0.2)]'
                      : 'bg-[#041426] border-white/10 hover:border-white/20'
                  }`}
                >
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-[#FF7A00] to-[#FF2200] flex items-center justify-center text-white font-bold shadow">
                      <Crown className="w-5 h-5" />
                    </div>
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="text-sm font-bold text-white">Sultan (Owner)</span>
                        <span className="px-2 py-0.5 rounded-full text-[9px] font-bold bg-[#FF7A00]/20 text-[#FF9500] border border-[#FF7A00]/30">
                          SUPER ADMIN
                        </span>
                      </div>
                      <p className="text-[11px] text-[#B8C7D9]">Full CMS, user management, site settings, security logs</p>
                    </div>
                  </div>
                  {currentUser?.role === 'SUPER_ADMIN' && <CheckCircle2 className="w-5 h-5 text-[#FF9500]" />}
                </button>

                {/* Moderator */}
                <button
                  id="auth-role-admin-btn"
                  type="button"
                  onClick={() => handleSwitchRole('ADMIN')}
                  className={`w-full p-3 rounded-2xl border text-left flex items-center justify-between transition-all ${
                    currentUser?.role === 'ADMIN'
                      ? 'bg-[#008CFF]/15 border-[#00B7FF] shadow-[0_0_15px_rgba(0,183,255,0.2)]'
                      : 'bg-[#041426] border-white/10 hover:border-white/20'
                  }`}
                >
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-[#008CFF] to-[#00B7FF] flex items-center justify-center text-white font-bold shadow">
                      <ShieldCheck className="w-5 h-5" />
                    </div>
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="text-sm font-bold text-white">Alex (Mod Lead)</span>
                        <span className="px-2 py-0.5 rounded-full text-[9px] font-bold bg-[#008CFF]/20 text-[#00B7FF] border border-[#008CFF]/30">
                          ADMIN / MOD
                        </span>
                      </div>
                      <p className="text-[11px] text-[#B8C7D9]">Post moderation, giveaway draws, FAQ & PC specs</p>
                    </div>
                  </div>
                  {currentUser?.role === 'ADMIN' && <CheckCircle2 className="w-5 h-5 text-[#00B7FF]" />}
                </button>

                {/* Regular Gamer */}
                <button
                  id="auth-role-user-btn"
                  type="button"
                  onClick={() => handleSwitchRole('USER')}
                  className={`w-full p-3 rounded-2xl border text-left flex items-center justify-between transition-all ${
                    currentUser?.role === 'USER'
                      ? 'bg-[#53FC18]/15 border-[#53FC18] shadow-[0_0_15px_rgba(83,252,24,0.2)]'
                      : 'bg-[#041426] border-white/10 hover:border-white/20'
                  }`}
                >
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-gray-700 to-gray-900 flex items-center justify-center text-[#53FC18] font-bold border border-white/10">
                      <UserIcon className="w-5 h-5" />
                    </div>
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="text-sm font-bold text-white">Marcus Vance</span>
                        <span className="px-2 py-0.5 rounded-full text-[9px] font-bold bg-white/10 text-white/80">
                          COMMUNITY USER
                        </span>
                      </div>
                      <p className="text-[11px] text-[#B8C7D9]">Community posts, comments, poll voting, giveaways</p>
                    </div>
                  </div>
                  {currentUser?.role === 'USER' && <CheckCircle2 className="w-5 h-5 text-[#53FC18]" />}
                </button>
              </div>
            )}
          </>
        )}

        {/* Security badge */}
        <div className="mt-6 pt-4 border-t border-white/10 flex items-center justify-center gap-2 text-[11px] text-[#B8C7D9]">
          <Lock className="w-3.5 h-3.5 text-[#53FC18]" />
          <span>Firebase Authentication Secured</span>
        </div>
      </div>
    </div>
  );
};
