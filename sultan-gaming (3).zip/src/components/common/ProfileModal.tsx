import React, { useState, useRef } from 'react';
import { X, ShieldCheck, Crown, Sparkles, User as UserIcon, Trash2, LogOut, Check, Edit3, Award, Upload, Image as ImageIcon, Loader2 } from 'lucide-react';
import { useStore } from '../../context/StoreContext';

export const ProfileModal: React.FC = () => {
  const { profileModalOpen, setProfileModalOpen, currentUser, updateUserProfile, deleteAccount, logout, uploadImage } = useStore();
  const [isEditing, setIsEditing] = useState(false);
  const [displayName, setDisplayName] = useState(currentUser?.displayName || '');
  const [username, setUsername] = useState(currentUser?.username || '');
  const [bio, setBio] = useState(currentUser?.bio || '');
  const [avatar, setAvatar] = useState(currentUser?.avatar || '');
  const [confirmDelete, setConfirmDelete] = useState(false);
  const [isSaving, setIsSaving] = useState(false);
  const [isUploadingAvatar, setIsUploadingAvatar] = useState(false);
  const [avatarUploadError, setAvatarUploadError] = useState<string | null>(null);
  const [isDragOver, setIsDragOver] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  if (!profileModalOpen || !currentUser) return null;

  const processAvatarFile = async (file: File) => {
    if (!file.type.startsWith('image/')) {
      setAvatarUploadError('Please select a valid image file (PNG, JPG, JPEG, WEBP, GIF).');
      return;
    }
    if (file.size > 10 * 1024 * 1024) {
      setAvatarUploadError('Avatar file size must be less than 10MB.');
      return;
    }

    setAvatarUploadError(null);
    setIsUploadingAvatar(true);

    const reader = new FileReader();
    reader.onload = async (e) => {
      const base64 = e.target?.result as string;
      try {
        const uploadRes = await uploadImage(base64, file.name, 'avatars');
        if (uploadRes.success && uploadRes.url) {
          setAvatar(uploadRes.url);
        } else {
          // Fallback to local base64 preview if backend network fails
          setAvatar(base64);
        }
      } catch (err: any) {
        setAvatar(base64);
      } finally {
        setIsUploadingAvatar(false);
      }
    };
    reader.readAsDataURL(file);
  };

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSaving(true);
    await updateUserProfile({
      displayName,
      username,
      bio,
      avatar,
    });
    setIsSaving(false);
    setIsEditing(false);
  };

  const nextLevelXP = currentUser.level * 5000;
  const currentLevelXP = currentUser.xp % 5000;
  const xpPercent = Math.min(100, Math.round((currentLevelXP / 5000) * 100));

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md animate-in fade-in duration-200">
      <div
        className="relative w-full max-w-lg bg-[#061B2E] border border-white/15 rounded-3xl p-6 sm:p-8 shadow-2xl overflow-hidden"
        onClick={e => e.stopPropagation()}
      >
        {/* Ambient Top Glow */}
        <div className="absolute top-0 left-1/2 -translate-x-1/2 w-64 h-32 bg-gradient-to-b from-[#008CFF]/20 to-transparent blur-3xl pointer-events-none" />

        {/* Close Button */}
        <button
          id="close-profile-modal-btn"
          onClick={() => setProfileModalOpen(false)}
          className="absolute top-5 right-5 p-2 rounded-full bg-white/5 hover:bg-white/10 text-white/70 hover:text-white transition-colors"
          aria-label="Close profile modal"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Profile Card Header */}
        <div className="flex items-center gap-4 mb-6">
          <div className="relative">
            <img
              src={currentUser.avatar}
              alt={currentUser.displayName}
              className="w-16 h-16 rounded-2xl object-cover border-2 border-white/20 shadow-xl"
            />
            {currentUser.role === 'SUPER_ADMIN' ? (
              <div className="absolute -bottom-1 -right-1 w-6 h-6 rounded-full bg-gradient-to-tr from-[#FF7A00] to-[#FF9500] flex items-center justify-center text-white border-2 border-[#061B2E]">
                <Crown className="w-3.5 h-3.5" />
              </div>
            ) : currentUser.role === 'ADMIN' ? (
              <div className="absolute -bottom-1 -right-1 w-6 h-6 rounded-full bg-[#008CFF] flex items-center justify-center text-white border-2 border-[#061B2E]">
                <ShieldCheck className="w-3.5 h-3.5" />
              </div>
            ) : (
              <div className="absolute -bottom-1 -right-1 w-6 h-6 rounded-full bg-[#53FC18] flex items-center justify-center text-black font-bold text-[10px] border-2 border-[#061B2E]">
                {currentUser.level}
              </div>
            )}
          </div>

          <div className="flex-1 min-w-0">
            <div className="flex items-center gap-2">
              <h3 className="text-lg font-bold text-white truncate">{currentUser.displayName}</h3>
              {currentUser.verified && (
                <span className="w-4 h-4 rounded-full bg-[#00B7FF] flex items-center justify-center text-white text-[9px] font-bold">
                  ✓
                </span>
              )}
            </div>
            <p className="text-xs text-[#B8C7D9] font-mono">@{currentUser.username}</p>
            <div className="mt-1 flex items-center gap-2">
              <span
                className={`px-2 py-0.5 rounded-full text-[10px] font-bold border ${
                  currentUser.role === 'SUPER_ADMIN'
                    ? 'bg-[#FF7A00]/20 text-[#FF9500] border-[#FF7A00]/30'
                    : currentUser.role === 'ADMIN'
                    ? 'bg-[#008CFF]/20 text-[#00B7FF] border-[#008CFF]/30'
                    : 'bg-white/10 text-white/80 border-white/10'
                }`}
              >
                {currentUser.role.replace('_', ' ')}
              </span>
              <span className="text-[11px] text-[#53FC18] font-bold">Level {currentUser.level}</span>
            </div>
          </div>
        </div>

        {/* Level / XP Bar */}
        <div className="p-3.5 rounded-2xl bg-[#041426] border border-white/10 mb-6">
          <div className="flex justify-between text-xs font-semibold mb-1.5">
            <span className="text-white flex items-center gap-1.5">
              <Award className="w-4 h-4 text-[#FF9500]" />
              Gamer XP Progress
            </span>
            <span className="text-[#00B7FF] font-mono">{currentUser.xp.toLocaleString()} XP</span>
          </div>
          <div className="w-full h-2 rounded-full bg-white/10 overflow-hidden">
            <div
              className="h-full bg-gradient-to-r from-[#FF7A00] via-[#FF9500] to-[#00B7FF] transition-all duration-500 rounded-full"
              style={{ width: `${xpPercent}%` }}
            />
          </div>
          <div className="flex justify-between text-[10px] text-white/50 mt-1">
            <span>Level {currentUser.level}</span>
            <span>Next Level: {nextLevelXP.toLocaleString()} XP</span>
          </div>
        </div>

        {/* Activity Stats */}
        <div className="grid grid-cols-3 gap-3 mb-6">
          <div className="p-3 rounded-2xl bg-white/5 border border-white/10 text-center">
            <span className="block text-lg font-black text-white">{currentUser.postsCount}</span>
            <span className="text-[10px] text-[#B8C7D9] uppercase tracking-wider font-semibold">Posts</span>
          </div>
          <div className="p-3 rounded-2xl bg-white/5 border border-white/10 text-center">
            <span className="block text-lg font-black text-white">{currentUser.commentsCount}</span>
            <span className="text-[10px] text-[#B8C7D9] uppercase tracking-wider font-semibold">Comments</span>
          </div>
          <div className="p-3 rounded-2xl bg-white/5 border border-white/10 text-center">
            <span className="block text-lg font-black text-[#FF9500]">{currentUser.giveawaysEnteredCount}</span>
            <span className="text-[10px] text-[#B8C7D9] uppercase tracking-wider font-semibold">Giveaways</span>
          </div>
        </div>

        {/* Edit Profile Form vs View */}
        {isEditing ? (
          <form onSubmit={handleSave} className="space-y-3 mb-6">
            <div>
              <label className="block text-xs font-semibold text-[#B8C7D9] mb-1">Display Name</label>
              <input
                type="text"
                value={displayName}
                onChange={e => setDisplayName(e.target.value)}
                className="w-full px-3.5 py-2 rounded-xl bg-[#041426] border border-white/15 text-white text-xs focus:outline-none focus:border-[#FF7A00]"
              />
            </div>
            <div>
              <label className="block text-xs font-semibold text-[#B8C7D9] mb-1">Username</label>
              <input
                type="text"
                value={username}
                onChange={e => setUsername(e.target.value)}
                className="w-full px-3.5 py-2 rounded-xl bg-[#041426] border border-white/15 text-white text-xs focus:outline-none focus:border-[#FF7A00]"
              />
            </div>
            <div>
              <label className="block text-xs font-semibold text-[#B8C7D9] mb-1">Bio</label>
              <textarea
                value={bio}
                onChange={e => setBio(e.target.value)}
                rows={2}
                className="w-full px-3.5 py-2 rounded-xl bg-[#041426] border border-white/15 text-white text-xs focus:outline-none focus:border-[#FF7A00]"
              />
            </div>
            <div>
              <label className="block text-xs font-semibold text-[#B8C7D9] mb-1">Avatar Picture</label>
              
              {/* Drag and Drop / File Upload Area */}
              <div
                onDragOver={(e) => {
                  e.preventDefault();
                  setIsDragOver(true);
                }}
                onDragLeave={() => setIsDragOver(false)}
                onDrop={(e) => {
                  e.preventDefault();
                  setIsDragOver(false);
                  const file = e.dataTransfer.files?.[0];
                  if (file) processAvatarFile(file);
                }}
                onClick={() => fileInputRef.current?.click()}
                className={`relative cursor-pointer border-2 border-dashed rounded-2xl p-3.5 text-center transition-all ${
                  isDragOver
                    ? 'border-[#FF7A00] bg-[#FF7A00]/10'
                    : 'border-white/15 bg-[#041426]/80 hover:border-white/30 hover:bg-[#041426]'
                }`}
              >
                <input
                  ref={fileInputRef}
                  type="file"
                  accept="image/png,image/jpeg,image/jpg,image/webp,image/gif"
                  className="hidden"
                  onChange={(e) => {
                    const file = e.target.files?.[0];
                    if (file) processAvatarFile(file);
                  }}
                />

                <div className="flex items-center justify-center gap-3">
                  {avatar ? (
                    <img
                      src={avatar}
                      alt="Avatar Preview"
                      className="w-10 h-10 rounded-xl object-cover border border-white/20 shadow-md shrink-0"
                    />
                  ) : (
                    <div className="w-10 h-10 rounded-xl bg-white/10 flex items-center justify-center text-white/50 shrink-0">
                      <ImageIcon className="w-5 h-5" />
                    </div>
                  )}

                  <div className="text-left flex-1 min-w-0">
                    <p className="text-xs font-semibold text-white flex items-center gap-1.5">
                      {isUploadingAvatar ? (
                        <>
                          <Loader2 className="w-3.5 h-3.5 text-[#FF7A00] animate-spin" />
                          <span>Uploading image...</span>
                        </>
                      ) : (
                        <>
                          <Upload className="w-3.5 h-3.5 text-[#FF7A00]" />
                          <span>Click to upload or drag & drop</span>
                        </>
                      )}
                    </p>
                    <p className="text-[10px] text-[#B8C7D9]">PNG, JPG, WEBP, GIF up to 10MB</p>
                  </div>
                </div>
              </div>

              {avatarUploadError && (
                <p className="text-[11px] text-red-400 mt-1">{avatarUploadError}</p>
              )}

              {/* Or direct URL */}
              <div className="mt-2">
                <input
                  type="url"
                  placeholder="Or enter direct image URL (https://...)"
                  value={avatar}
                  onChange={e => setAvatar(e.target.value)}
                  className="w-full px-3.5 py-2 rounded-xl bg-[#041426] border border-white/15 text-white text-xs focus:outline-none focus:border-[#FF7A00]"
                />
              </div>
            </div>
            <div className="flex gap-2 pt-2">
              <button
                type="button"
                onClick={() => setIsEditing(false)}
                className="flex-1 py-2 rounded-xl bg-white/10 text-white text-xs font-semibold hover:bg-white/15"
              >
                Cancel
              </button>
              <button
                type="submit"
                disabled={isSaving}
                className="flex-1 py-2 rounded-xl bg-gradient-to-r from-[#FF7A00] to-[#FF9500] text-white text-xs font-bold hover:shadow-lg"
              >
                {isSaving ? 'Saving...' : 'Save Changes'}
              </button>
            </div>
          </form>
        ) : (
          <div className="mb-6">
            <div className="p-3.5 rounded-2xl bg-white/5 border border-white/10">
              <span className="text-[10px] text-[#FF9500] uppercase font-bold tracking-wider">Bio</span>
              <p className="text-xs text-[#EAF4FF] mt-1">{currentUser.bio || 'No bio provided.'}</p>
            </div>
          </div>
        )}

        {/* Footer Actions */}
        <div className="flex items-center justify-between pt-4 border-t border-white/10">
          {!isEditing && (
            <button
              id="profile-edit-btn"
              onClick={() => setIsEditing(true)}
              className="flex items-center gap-1.5 px-3 py-2 rounded-xl bg-white/5 hover:bg-white/10 text-white text-xs font-semibold transition-colors"
            >
              <Edit3 className="w-3.5 h-3.5 text-[#00B7FF]" />
              Edit Profile
            </button>
          )}

          <div className="flex items-center gap-2 ml-auto">
            {confirmDelete ? (
              <div className="flex items-center gap-2">
                <span className="text-[11px] text-red-400">Permanently delete?</span>
                <button
                  id="confirm-delete-account-btn"
                  onClick={deleteAccount}
                  className="px-2.5 py-1.5 rounded-lg bg-red-600 text-white text-xs font-bold hover:bg-red-700"
                >
                  Yes, Delete
                </button>
                <button
                  onClick={() => setConfirmDelete(false)}
                  className="px-2.5 py-1.5 rounded-lg bg-white/10 text-white text-xs"
                >
                  Cancel
                </button>
              </div>
            ) : (
              currentUser.role !== 'SUPER_ADMIN' && (
                <button
                  id="profile-delete-account-btn"
                  onClick={() => setConfirmDelete(true)}
                  className="p-2 rounded-xl text-red-400/80 hover:text-red-400 hover:bg-red-500/10 transition-colors"
                  title="Delete Account"
                >
                  <Trash2 className="w-4 h-4" />
                </button>
              )
            )}

            <button
              id="profile-logout-btn"
              onClick={() => {
                logout();
                setProfileModalOpen(false);
              }}
              className="flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-red-500/10 hover:bg-red-500/20 text-red-400 text-xs font-semibold border border-red-500/20 transition-colors"
            >
              <LogOut className="w-3.5 h-3.5" />
              Sign Out
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
