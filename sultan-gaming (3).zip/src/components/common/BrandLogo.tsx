import React from 'react';

interface BrandLogoProps {
  size?: 'sm' | 'md' | 'lg' | 'xl';
  showText?: boolean;
  className?: string;
  theme?: 'orange' | 'kick' | 'discord' | 'insta';
}

export const BrandLogo: React.FC<BrandLogoProps> = ({
  size = 'md',
  showText = true,
  className = '',
  theme = 'orange',
}) => {
  const iconDimensions = {
    sm: 'w-6 h-6',
    md: 'w-8 h-8',
    lg: 'w-10 h-10',
    xl: 'w-14 h-14',
  }[size];

  const textSize = {
    sm: 'text-sm',
    md: 'text-lg',
    lg: 'text-xl',
    xl: 'text-3xl',
  }[size];

  const themeGlow = {
    orange: 'from-[#FF7A00] to-[#FFB000]',
    kick: 'from-[#53FC18] to-[#22C55E]',
    discord: 'from-[#5865F2] to-[#818CF8]',
    insta: 'from-[#E1306C] to-[#FD1D1D]',
  }[theme];

  return (
    <div className={`flex items-center gap-2.5 select-none cursor-pointer group ${className}`}>
      {/* Crown Icon Container */}
      <div
        className={`relative ${iconDimensions} flex items-center justify-center rounded-xl bg-gradient-to-br ${themeGlow} p-1.5 shadow-lg group-hover:scale-105 transition-transform duration-300`}
        style={{
          boxShadow: theme === 'orange' ? '0 0 16px rgba(255, 122, 0, 0.45)' : undefined,
        }}
      >
        <svg
          viewBox="0 0 24 24"
          fill="currentColor"
          className="w-full h-full text-white drop-shadow"
        >
          {/* Sultan 5-point Crown */}
          <path d="M2.5 19h19a1 1 0 0 0 1-1v-2.5a1 1 0 0 0-.6-.92L18.5 13l-3.5 4.5-3-9-3 9L5.5 13l-3.4 1.58A1 1 0 0 0 1.5 15.5V18a1 1 0 0 0 1 1z" />
          <path d="M4 19h16v2H4z" opacity="0.8" />
          <circle cx="2" cy="14" r="1.2" />
          <circle cx="5.5" cy="11.5" r="1.2" />
          <circle cx="12" cy="7" r="1.5" />
          <circle cx="18.5" cy="11.5" r="1.2" />
          <circle cx="22" cy="14" r="1.2" />
        </svg>
      </div>

      {showText && (
        <div className="flex flex-col leading-tight">
          <span
            className={`font-black tracking-wider uppercase font-['Space_Grotesk'] text-white ${textSize} group-hover:text-[#FF9500] transition-colors`}
          >
            SULTAN
          </span>
          <span className="text-[10px] sm:text-xs font-bold tracking-[0.25em] text-[#FF9500] uppercase font-['Space_Grotesk']">
            GAMING
          </span>
        </div>
      )}
    </div>
  );
};
