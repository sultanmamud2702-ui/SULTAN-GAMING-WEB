import React, { useState, useRef, useEffect } from 'react';
import {
  Search,
  Bell,
  Menu,
  X,
  ShieldCheck,
  ChevronDown,
  Sparkles,
  Gamepad2,
  Tv,
  Users,
  Gift,
  HelpCircle,
  Laptop,
  LogIn,
  Crown,
  User as UserIcon,
  LogOut,
  Settings,
  LayoutDashboard,
} from 'lucide-react';
import { useStore } from '../../context/StoreContext';
import { BrandLogo } from '../common/BrandLogo';
import { PageId } from '../../types';
import { ADMIN_USER_ID } from '../../lib/firebase';

export const Header: React.FC = () => {
  const {
    currentPage,
    setCurrentPage,
    openSearch,
    unreadCount,
    notifications,
    markNotificationAsRead,
    markAllNotificationsAsRead,
    isAdmin,
    mobileMenuOpen,
    setMobileMenuOpen,
    games,
    currentUser,
    isAuthenticated,
    userRole,
    setAuthModalOpen,
    setProfileModalOpen,
    logout,
  } = useStore();

  const [showNotifications, setShowNotifications] = useState(false);
  const [showGamesDropdown, setShowGamesDropdown] = useState(false);
  const [showUserMenu, setShowUserMenu] = useState(false);
  const notifRef = useRef<HTMLDivElement>(null);
  const userRef = useRef<HTMLDivElement>(null);
  const gamesDropdownRef = useRef<HTMLDivElement>(null);

  // Close dropdowns on outside click
  useEffect(() => {
    const handleClickOutside = (e: MouseEvent) => {
      if (notifRef.current && !notifRef.current.contains(e.target as Node)) {
        setShowNotifications(false);
      }
      if (userRef.current && !userRef.current.contains(e.target as Node)) {
        setShowUserMenu(false);
      }
      if (gamesDropdownRef.current && !gamesDropdownRef.current.contains(e.target as Node)) {
        setShowGamesDropdown(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const navItems: { label: string; page: PageId; hasDropdown?: boolean }[] = [
    { label: 'Home', page: 'home' },
    { label: 'Games', page: 'home', hasDropdown: true },
    { label: 'Platforms', page: 'youtube' },
    { label: 'Community', page: 'community' },
    { label: 'Giveaways', page: 'giveaways' },
    { label: 'FAQ', page: 'faq' },
  ];

  return (
    <header className="sticky top-0 z-40 w-full bg-[#020817]/80 backdrop-blur-xl border-b border-white/10 px-4 lg:px-8 py-3 transition-all">
      <div className="max-w-[1700px] mx-auto flex items-center justify-between gap-4">
        {/* Left: Mobile Menu Toggle & Brand Logo */}
        <div className="flex items-center gap-3">
          <button
            id="mobile-menu-toggle-btn"
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            className="p-2 lg:hidden rounded-xl bg-white/5 border border-white/10 text-white hover:bg-white/10 transition-colors"
            aria-label="Toggle navigation menu"
          >
            {mobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
          </button>

          <div onClick={() => setCurrentPage('home')}>
            <BrandLogo size="md" />
          </div>
        </div>

        {/* Center: Desktop Navigation Pills */}
        <nav className="hidden md:flex items-center gap-1.5 p-1 rounded-full bg-[#041426]/70 border border-white/10 backdrop-blur-md">
          {navItems.map(item => {
            const isActive =
              item.page === currentPage ||
              (item.hasDropdown && currentPage.startsWith('game-'));

            if (item.hasDropdown) {
              return (
                <div key={item.label} className="relative" ref={gamesDropdownRef}>
                  <button
                    id="nav-games-dropdown-btn"
                    onClick={() => setShowGamesDropdown(!showGamesDropdown)}
                    className={`flex items-center gap-1.5 px-4 py-1.5 text-xs font-semibold rounded-full transition-all duration-200 ${
                      isActive
                        ? 'bg-gradient-to-r from-[#FF7A00] to-[#FF9500] text-white shadow-[0_0_15px_rgba(255,122,0,0.5)]'
                        : 'text-[#B8C7D9] hover:text-white hover:bg-white/5'
                    }`}
                  >
                    <span>{item.label}</span>
                    <ChevronDown className="w-3 h-3 opacity-70" />
                  </button>

                  {/* Games Dropdown */}
                  {showGamesDropdown && (
                    <div className="absolute top-full mt-2 left-0 w-60 rounded-2xl bg-[#061B2E]/95 backdrop-blur-xl border border-white/15 p-2 shadow-2xl z-50 animate-in fade-in slide-in-from-top-2 duration-150">
                      <div className="text-[10px] font-bold text-[#FF9500] uppercase tracking-wider px-3 py-1">
                        Featured Games
                      </div>
                      {games.map(game => (
                        <button
                          key={game.id}
                          id={`header-game-link-${game.slug}`}
                          onClick={() => {
                            setCurrentPage(`game-${game.slug}` as PageId);
                            setShowGamesDropdown(false);
                          }}
                          className="w-full flex items-center gap-2.5 px-3 py-2 rounded-xl text-left hover:bg-white/10 text-sm text-[#EAF4FF] transition-colors"
                        >
                          <img
                            src={game.logo}
                            alt={game.title}
                            className="w-5 h-5 object-contain"
                            onError={(e) => {
                              (e.target as HTMLElement).style.display = 'none';
                            }}
                          />
                          <span className="font-medium truncate">{game.title}</span>
                        </button>
                      ))}
                      <div className="border-t border-white/10 my-1 pt-1">
                        <button
                          id="header-all-games-btn"
                          onClick={() => {
                            setCurrentPage('home');
                            setShowGamesDropdown(false);
                          }}
                          className="w-full text-center text-xs text-[#00B7FF] hover:underline py-1"
                        >
                          View All on Home
                        </button>
                      </div>
                    </div>
                  )}
                </div>
              );
            }

            return (
              <button
                key={item.label}
                id={`nav-link-${item.page}`}
                onClick={() => setCurrentPage(item.page)}
                className={`px-4 py-1.5 text-xs font-semibold rounded-full transition-all duration-200 ${
                  isActive
                    ? 'bg-gradient-to-r from-[#FF7A00] to-[#FF9500] text-white shadow-[0_0_15px_rgba(255,122,0,0.5)]'
                    : 'text-[#B8C7D9] hover:text-white hover:bg-white/5'
                }`}
              >
                {item.label}
              </button>
            );
          })}
        </nav>

        {/* Right: Search, Notifications & Auth / User Profile */}
        <div className="flex items-center gap-2.5">
          {/* Global Search Bar */}
          <button
            id="global-search-header-btn"
            onClick={openSearch}
            className="flex items-center gap-2.5 px-3.5 py-1.5 rounded-full bg-[#041426]/80 border border-white/10 text-[#B8C7D9] hover:text-white hover:border-[#008CFF]/50 transition-all text-xs group"
          >
            <Search className="w-3.5 h-3.5 text-[#00B7FF] group-hover:scale-110 transition-transform" />
            <span className="hidden sm:inline">Search games, videos...</span>
            <span className="hidden lg:inline text-[10px] px-1.5 py-0.5 rounded bg-white/10 font-mono text-white/60">
              ⌘K
            </span>
          </button>

          {/* Notifications Dropdown */}
          <div className="relative" ref={notifRef}>
            <button
              id="header-notifications-btn"
              onClick={() => setShowNotifications(!showNotifications)}
              className="relative p-2 rounded-full bg-[#041426] border border-white/10 text-white hover:bg-white/10 hover:border-[#FF7A00]/50 transition-all"
              aria-label="View notifications"
            >
              <Bell className="w-4 h-4 text-[#EAF4FF]" />
              {unreadCount > 0 && (
                <span className="absolute -top-1 -right-1 flex h-4 min-w-[16px] items-center justify-center rounded-full bg-gradient-to-r from-[#FF7A00] to-[#FF2200] px-1 text-[9px] font-bold text-white shadow-[0_0_8px_rgba(255,122,0,0.8)] animate-pulse">
                  {unreadCount}
                </span>
              )}
            </button>

            {/* Notifications Popover */}
            {showNotifications && (
              <div className="absolute right-0 top-full mt-2.5 w-80 sm:w-96 rounded-2xl bg-[#061B2E]/95 backdrop-blur-2xl border border-white/15 p-4 shadow-2xl z-50 animate-in fade-in slide-in-from-top-2 duration-150">
                <div className="flex items-center justify-between pb-3 border-b border-white/10">
                  <div className="flex items-center gap-2">
                    <span className="font-bold text-white text-sm">Notifications</span>
                    {unreadCount > 0 && (
                      <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-[#FF7A00]/20 text-[#FF9500] border border-[#FF7A00]/30">
                        {unreadCount} new
                      </span>
                    )}
                  </div>
                  {unreadCount > 0 && (
                    <button
                      id="mark-all-notifications-read-btn"
                      onClick={markAllNotificationsAsRead}
                      className="text-[11px] text-[#00B7FF] hover:underline"
                    >
                      Mark all as read
                    </button>
                  )}
                </div>

                <div className="max-h-72 overflow-y-auto divide-y divide-white/5 py-1">
                  {notifications.length === 0 ? (
                    <div className="py-6 text-center text-xs text-[#B8C7D9]">No notifications yet</div>
                  ) : (
                    notifications.map(n => (
                      <div
                        key={n.id}
                        onClick={() => {
                          markNotificationAsRead(n.id);
                          if (n.linkPage) {
                            setCurrentPage(n.linkPage);
                            setShowNotifications(false);
                          }
                        }}
                        className={`py-2.5 px-2 rounded-xl flex items-start gap-3 cursor-pointer transition-colors ${
                          n.read ? 'opacity-70 hover:bg-white/5' : 'bg-white/5 hover:bg-white/10'
                        }`}
                      >
                        <div className="w-2 h-2 rounded-full mt-1.5 bg-[#FF7A00] flex-shrink-0" />
                        <div className="flex-1">
                          <p className="text-xs font-semibold text-white">{n.title}</p>
                          <p className="text-[11px] text-[#B8C7D9] mt-0.5 line-clamp-2">{n.message}</p>
                          <span className="text-[10px] text-white/40 mt-1 inline-block">{n.time}</span>
                        </div>
                      </div>
                    ))
                  )}
                </div>
              </div>
            )}
          </div>

          {/* User Profile / Auth Button */}
          {isAuthenticated && currentUser ? (
            <div className="relative" ref={userRef}>
              <button
                id="header-user-profile-btn"
                onClick={() => setShowUserMenu(!showUserMenu)}
                className="relative flex items-center gap-2 p-1 pl-1.5 pr-2.5 rounded-full bg-[#041426] border border-white/15 hover:border-[#FF7A00]/60 transition-all group"
              >
                <div className="relative w-7 h-7 rounded-full overflow-hidden border border-white/20">
                  <img src={currentUser.avatar} alt={currentUser.displayName} className="w-full h-full object-cover" />
                </div>
                <div className="hidden sm:flex flex-col items-start text-left">
                  <span className="text-xs font-bold text-white max-w-[90px] truncate leading-none">
                    {currentUser.displayName}
                  </span>
                  <span className="text-[9px] font-bold text-[#FF9500] leading-none mt-0.5">
                    {currentUser.role === 'SUPER_ADMIN' ? 'OWNER' : currentUser.role === 'ADMIN' ? 'MOD' : `LVL ${currentUser.level}`}
                  </span>
                </div>
                <ChevronDown className="w-3 h-3 text-[#B8C7D9] group-hover:text-white transition-colors" />
              </button>

              {/* User Dropdown */}
              {showUserMenu && (
                <div className="absolute right-0 top-full mt-2.5 w-64 rounded-2xl bg-[#061B2E]/95 backdrop-blur-2xl border border-white/15 p-3 shadow-2xl z-50 animate-in fade-in slide-in-from-top-2 duration-150">
                  <div className="flex items-center gap-3 p-2 rounded-xl bg-white/5 mb-2">
                    <img
                      src={currentUser.avatar}
                      alt={currentUser.displayName}
                      className="w-10 h-10 rounded-xl object-cover border border-white/20"
                    />
                    <div className="min-w-0 flex-1">
                      <p className="text-xs font-bold text-white truncate">{currentUser.displayName}</p>
                      <p className="text-[10px] text-[#B8C7D9] truncate">@{currentUser.username}</p>
                      <span
                        className={`inline-block mt-0.5 px-1.5 py-0.2 text-[9px] font-bold rounded-full ${
                          currentUser.role === 'SUPER_ADMIN'
                            ? 'bg-[#FF7A00]/20 text-[#FF9500]'
                            : currentUser.role === 'ADMIN'
                            ? 'bg-[#008CFF]/20 text-[#00B7FF]'
                            : 'bg-white/10 text-white/80'
                        }`}
                      >
                        {currentUser.role.replace('_', ' ')}
                      </span>
                    </div>
                  </div>

                  <div className="space-y-1">
                    <button
                      id="menu-view-dashboard-btn"
                      onClick={() => {
                        setCurrentPage('dashboard');
                        setShowUserMenu(false);
                      }}
                      className={`w-full flex items-center justify-between px-3 py-2 rounded-xl text-xs font-semibold transition-colors ${
                        currentPage === 'dashboard'
                          ? 'bg-[#008CFF]/20 text-[#00B7FF] border border-[#008CFF]/40'
                          : 'text-[#EAF4FF] hover:bg-white/10'
                      }`}
                    >
                      <span className="flex items-center gap-2">
                        {currentUser.id === ADMIN_USER_ID ? (
                          <ShieldCheck className="w-4 h-4 text-[#FF7A00]" />
                        ) : (
                          <LayoutDashboard className="w-4 h-4 text-[#00B7FF]" />
                        )}
                        {currentUser.id === ADMIN_USER_ID ? 'Admin Dashboard' : 'My Dashboard'}
                      </span>
                      {currentUser.id === ADMIN_USER_ID && (
                        <span className="text-[9px] bg-[#FF7A00]/20 text-[#FF9500] px-1.5 py-0.5 rounded font-mono font-bold">
                          ADMIN
                        </span>
                      )}
                    </button>

                    <button
                      id="menu-view-profile-btn"
                      onClick={() => {
                        setProfileModalOpen(true);
                        setShowUserMenu(false);
                      }}
                      className="w-full flex items-center gap-2 px-3 py-2 rounded-xl text-xs text-[#EAF4FF] hover:bg-white/10 transition-colors"
                    >
                      <UserIcon className="w-4 h-4 text-[#00B7FF]" />
                      My Profile & XP
                    </button>

                    {(userRole === 'SUPER_ADMIN' || userRole === 'ADMIN') && (
                      <button
                        id="menu-open-admin-cms-btn"
                        onClick={() => {
                          setCurrentPage('admin');
                          setShowUserMenu(false);
                        }}
                        className={`w-full flex items-center justify-between px-3 py-2 rounded-xl text-xs font-semibold transition-colors ${
                          currentPage === 'admin'
                            ? 'bg-gradient-to-r from-[#FF7A00] to-[#FF9500] text-white'
                            : 'text-[#FF9500] hover:bg-white/10'
                        }`}
                      >
                        <span className="flex items-center gap-2">
                          <ShieldCheck className="w-4 h-4 text-[#FF9500]" />
                          Admin CMS & RBAC
                        </span>
                        <span className="text-[9px] bg-white/20 px-1.5 py-0.5 rounded font-mono">/admin</span>
                      </button>
                    )}

                    <button
                      id="menu-role-switcher-btn"
                      onClick={() => {
                        setAuthModalOpen(true);
                        setShowUserMenu(false);
                      }}
                      className="w-full flex items-center gap-2 px-3 py-2 rounded-xl text-xs text-[#B8C7D9] hover:text-white hover:bg-white/5 transition-colors"
                    >
                      <Crown className="w-4 h-4 text-[#FF7A00]" />
                      Switch Role (RBAC)
                    </button>

                    <div className="border-t border-white/10 my-1 pt-1">
                      <button
                        id="menu-header-logout-btn"
                        onClick={() => {
                          logout();
                          setShowUserMenu(false);
                        }}
                        className="w-full flex items-center gap-2 px-3 py-2 rounded-xl text-xs text-red-400 hover:bg-red-500/10 transition-colors"
                      >
                        <LogOut className="w-4 h-4" />
                        Sign Out
                      </button>
                    </div>
                  </div>
                </div>
              )}
            </div>
          ) : (
            <button
              id="header-login-btn"
              onClick={() => setAuthModalOpen(true)}
              className="flex items-center gap-1.5 px-4 py-1.5 rounded-full bg-gradient-to-r from-[#FF7A00] to-[#FF9500] text-white font-bold text-xs hover:shadow-[0_0_15px_rgba(255,122,0,0.6)] transition-all active:scale-95"
            >
              <LogIn className="w-3.5 h-3.5" />
              <span>Sign In</span>
            </button>
          )}
        </div>
      </div>
    </header>
  );
};
