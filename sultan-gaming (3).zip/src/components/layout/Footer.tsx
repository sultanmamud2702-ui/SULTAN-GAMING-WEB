import React from 'react';
import { Youtube, Instagram, ShieldCheck, Heart, Crown } from 'lucide-react';
import { useStore } from '../../context/StoreContext';
import { BrandLogo } from '../common/BrandLogo';
import { PageId } from '../../types';

export const Footer: React.FC = () => {
  const { settings, setCurrentPage, platforms } = useStore();

  const getPlatformIcon = (type: string) => {
    switch (type) {
      case 'youtube':
        return (
          <div className="w-7 h-7 rounded-lg bg-[#FF0000] flex items-center justify-center text-white shadow-md hover:scale-110 transition-transform">
            <svg viewBox="0 0 24 24" fill="currentColor" className="w-4 h-4">
              <path d="M23.498 6.186a3.016 3.016 0 0 0-2.122-2.136C19.505 3.545 12 3.545 12 3.545s-7.505 0-9.377.505A3.017 3.017 0 0 0 .502 6.186C0 8.07 0 12 0 12s0 3.93.502 5.814a3.016 3.016 0 0 0 2.122 2.136c1.871.505 9.376.505 9.376.505s7.505 0 9.377-.505a3.015 3.015 0 0 0 2.122-2.136C24 15.93 24 12 24 12s0-3.93-.502-5.814zM9.545 15.568V8.432L15.818 12l-6.273 3.568z" />
            </svg>
          </div>
        );
      case 'kick':
        return (
          <div className="w-7 h-7 rounded-lg bg-[#53FC18] flex items-center justify-center text-black font-black text-xs font-mono shadow-md hover:scale-110 transition-transform">
            K
          </div>
        );
      case 'discord':
        return (
          <div className="w-7 h-7 rounded-lg bg-[#5865F2] flex items-center justify-center text-white shadow-md hover:scale-110 transition-transform">
            <svg viewBox="0 0 24 24" fill="currentColor" className="w-4 h-4">
              <path d="M20.317 4.37a19.791 19.791 0 0 0-4.885-1.515.074.074 0 0 0-.079.037c-.21.375-.444.864-.608 1.25a18.27 18.27 0 0 0-5.487 0 12.64 12.64 0 0 0-.617-1.25.077.077 0 0 0-.079-.037A19.736 19.736 0 0 0 3.677 4.37a.07.07 0 0 0-.032.027C.533 9.046-.32 13.58.099 18.057a.082.082 0 0 0 .031.057 19.9 19.9 0 0 0 5.993 3.03.078.078 0 0 0 .084-.028c.462-.63.874-1.295 1.226-1.994.021-.041.001-.09-.041-.106a13.107 13.107 0 0 1-1.872-.892.077.077 0 0 1-.008-.128 10.2 10.2 0 0 0 .372-.292.074.074 0 0 1 .077-.01c3.929 1.793 8.18 1.793 12.061 0a.074.074 0 0 1 .078.01c.12.098.246.198.373.292a.077.077 0 0 1-.006.127 12.299 12.299 0 0 1-1.873.893.077.077 0 0 0-.041.107c.36.698.772 1.362 1.225 1.993a.076.076 0 0 0 .084.028 19.839 19.839 0 0 0 6.002-3.03.077.077 0 0 0 .032-.054c.5-5.177-.838-9.674-3.549-13.66a.061.061 0 0 0-.031-.028zM8.02 15.33c-1.183 0-2.157-1.085-2.157-2.419 0-1.333.956-2.419 2.157-2.419 1.21 0 2.176 1.096 2.157 2.42 0 1.333-.956 2.418-2.157 2.418zm7.975 0c-1.183 0-2.157-1.085-2.157-2.419 0-1.333.955-2.419 2.157-2.419 1.21 0 2.176 1.096 2.157 2.42 0 1.333-.946 2.418-2.157 2.418z" />
            </svg>
          </div>
        );
      case 'instagram':
        return (
          <div className="w-7 h-7 rounded-lg bg-gradient-to-tr from-[#FD1D1D] via-[#E1306C] to-[#833AB4] flex items-center justify-center text-white shadow-md hover:scale-110 transition-transform">
            <Instagram className="w-4 h-4" />
          </div>
        );
      default:
        return null;
    }
  };

  return (
    <footer className="w-full mt-12 bg-[#041426]/80 backdrop-blur-xl border-t border-white/10 px-4 lg:px-8 py-8 transition-all">
      <div className="max-w-[1700px] mx-auto space-y-6">
        {/* Top bar with Tagline, Social Icons, and Brand */}
        <div className="flex flex-col md:flex-row items-center justify-between gap-4 py-3 px-6 rounded-2xl bg-white/5 border border-white/10">
          <div className="text-center md:text-left">
            <span className="text-xs sm:text-sm font-bold tracking-[0.2em] text-[#FF9500] uppercase font-['Space_Grotesk']">
              "{settings.tagline}"
            </span>
          </div>

          {/* Social Icons row */}
          <div className="flex items-center gap-3">
            {platforms.map(p => (
              <button
                key={p.id}
                id={`footer-social-btn-${p.id}`}
                onClick={() => setCurrentPage(p.type as PageId)}
                title={`Visit ${p.name}`}
                className="transition-transform"
              >
                {getPlatformIcon(p.type)}
              </button>
            ))}
            <div className="h-5 w-px bg-white/10 mx-1" />
            <span className="text-xs font-black text-white uppercase tracking-wider font-['Space_Grotesk']">
              SULTAN GAMING
            </span>
          </div>
        </div>

        {/* Links grid */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-6 pt-4 border-t border-white/5 text-xs text-[#B8C7D9]">
          <div>
            <h4 className="font-bold text-white uppercase tracking-wider text-[11px] mb-2.5 text-[#FF9500]">
              Content & Stream
            </h4>
            <ul className="space-y-1.5">
              <li>
                <button onClick={() => setCurrentPage('home')} className="hover:text-white transition-colors">
                  Home Hub
                </button>
              </li>
              <li>
                <button onClick={() => setCurrentPage('youtube')} className="hover:text-white transition-colors">
                  YouTube Channel
                </button>
              </li>
              <li>
                <button onClick={() => setCurrentPage('kick')} className="hover:text-white transition-colors">
                  Kick Livestreams
                </button>
              </li>
              <li>
                <button onClick={() => setCurrentPage('community')} className="hover:text-white transition-colors">
                  Community Feed
                </button>
              </li>
            </ul>
          </div>

          <div>
            <h4 className="font-bold text-white uppercase tracking-wider text-[11px] mb-2.5 text-[#00B7FF]">
              Community & Rewards
            </h4>
            <ul className="space-y-1.5">
              <li>
                <button onClick={() => setCurrentPage('giveaways')} className="hover:text-white transition-colors">
                  Official Giveaways
                </button>
              </li>
              <li>
                <button onClick={() => setCurrentPage('discord')} className="hover:text-white transition-colors">
                  Discord Server
                </button>
              </li>
              <li>
                <button onClick={() => setCurrentPage('pc-specs')} className="hover:text-white transition-colors">
                  PC Specs & Hardware
                </button>
              </li>
              <li>
                <button onClick={() => setCurrentPage('faq')} className="hover:text-white transition-colors">
                  FAQ & Rules
                </button>
              </li>
            </ul>
          </div>

          <div>
            <h4 className="font-bold text-white uppercase tracking-wider text-[11px] mb-2.5 text-[#53FC18]">
              Platforms
            </h4>
            <ul className="space-y-1.5">
              <li>
                <button onClick={() => setCurrentPage('youtube')} className="hover:text-white transition-colors">
                  YouTube (250K+)
                </button>
              </li>
              <li>
                <button onClick={() => setCurrentPage('kick')} className="hover:text-white transition-colors">
                  Kick Live (12.4K+)
                </button>
              </li>
              <li>
                <button onClick={() => setCurrentPage('discord')} className="hover:text-white transition-colors">
                  Discord (5.2K+)
                </button>
              </li>
              <li>
                <button onClick={() => setCurrentPage('instagram')} className="hover:text-white transition-colors">
                  Instagram (40K+)
                </button>
              </li>
            </ul>
          </div>

          <div>
            <h4 className="font-bold text-white uppercase tracking-wider text-[11px] mb-2.5 text-white/90">
              Admin & System
            </h4>
            <ul className="space-y-1.5">
              <li>
                <button
                  id="footer-admin-cms-link"
                  onClick={() => setCurrentPage('admin')}
                  className="flex items-center gap-1.5 text-[#FF9500] hover:underline font-semibold"
                >
                  <ShieldCheck className="w-3.5 h-3.5" />
                  Admin CMS Panel
                </button>
              </li>
              <li>
                <span className="text-white/40">Version 2.5 • Full-Stack CMS</span>
              </li>
              <li>
                <span className="text-white/40">Los Santos High-Heist Edition</span>
              </li>
            </ul>
          </div>
        </div>

        {/* Bottom copyright */}
        <div className="flex flex-col sm:flex-row items-center justify-between gap-2 pt-4 border-t border-white/5 text-[11px] text-white/40">
          <p>© {new Date().getFullYear()} Sultan Gaming. All rights reserved.</p>
          <div className="flex items-center gap-4">
            <button onClick={() => setCurrentPage('faq')} className="hover:underline">
              Terms & Conditions
            </button>
            <button onClick={() => setCurrentPage('faq')} className="hover:underline">
              Privacy Policy
            </button>
            <button onClick={() => setCurrentPage('admin')} className="hover:underline text-[#FF9500]">
              CMS Studio
            </button>
          </div>
        </div>
      </div>
    </footer>
  );
};
