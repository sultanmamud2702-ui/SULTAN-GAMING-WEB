import React from 'react';
import {
  Home,
  Users,
  Laptop,
  Gift,
  HelpCircle,
  Youtube,
  Tv,
  MessageSquare,
  Instagram,
  Gamepad2,
  Radio,
  ChevronRight,
  Flame,
  Crown,
  Sparkles,
  LayoutDashboard,
  ShieldCheck,
} from 'lucide-react';
import { useStore } from '../../context/StoreContext';
import { PageId } from '../../types';
import { ADMIN_USER_ID } from '../../lib/firebase';

export const Sidebar: React.FC = () => {
  const {
    currentPage,
    setCurrentPage,
    mobileMenuOpen,
    setMobileMenuOpen,
    platforms,
    games,
    settings,
    currentUser,
  } = useStore();

  const isRootAdmin = currentUser?.id === ADMIN_USER_ID || currentUser?.role === 'SUPER_ADMIN';

  const aboutLinks: { id: PageId; label: string; icon: React.ReactNode; badge?: string }[] = [
    { id: 'home', label: 'Home', icon: <Home className="w-4 h-4" /> },
    {
      id: 'dashboard',
      label: isRootAdmin ? 'Admin Dashboard' : 'Dashboard',
      icon: isRootAdmin ? <ShieldCheck className="w-4 h-4 text-[#FF7A00]" /> : <LayoutDashboard className="w-4 h-4" />,
      badge: isRootAdmin ? 'ADMIN' : undefined,
    },
    { id: 'community', label: 'Community', icon: <Users className="w-4 h-4" /> },
    { id: 'pc-specs', label: 'PC Specs', icon: <Laptop className="w-4 h-4" /> },
    { id: 'giveaways', label: 'Giveaways', icon: <Gift className="w-4 h-4" /> },
    { id: 'faq', label: 'FAQ', icon: <HelpCircle className="w-4 h-4" /> },
  ];

  const getPlatformIcon = (type: string) => {
    switch (type) {
      case 'youtube':
        return (
          <div className="w-5 h-5 rounded-md bg-[#FF0000] flex items-center justify-center text-white shadow-sm flex-shrink-0">
            <svg viewBox="0 0 24 24" fill="currentColor" className="w-3.5 h-3.5">
              <path d="M23.498 6.186a3.016 3.016 0 0 0-2.122-2.136C19.505 3.545 12 3.545 12 3.545s-7.505 0-9.377.505A3.017 3.017 0 0 0 .502 6.186C0 8.07 0 12 0 12s0 3.93.502 5.814a3.016 3.016 0 0 0 2.122 2.136c1.871.505 9.376.505 9.376.505s7.505 0 9.377-.505a3.015 3.015 0 0 0 2.122-2.136C24 15.93 24 12 24 12s0-3.93-.502-5.814zM9.545 15.568V8.432L15.818 12l-6.273 3.568z" />
            </svg>
          </div>
        );
      case 'kick':
        return (
          <div className="w-5 h-5 rounded-md bg-[#53FC18] flex items-center justify-center text-black font-black text-xs font-mono shadow-sm flex-shrink-0">
            K
          </div>
        );
      case 'discord':
        return (
          <div className="w-5 h-5 rounded-md bg-[#5865F2] flex items-center justify-center text-white shadow-sm flex-shrink-0">
            <svg viewBox="0 0 24 24" fill="currentColor" className="w-3.5 h-3.5">
              <path d="M20.317 4.37a19.791 19.791 0 0 0-4.885-1.515.074.074 0 0 0-.079.037c-.21.375-.444.864-.608 1.25a18.27 18.27 0 0 0-5.487 0 12.64 12.64 0 0 0-.617-1.25.077.077 0 0 0-.079-.037A19.736 19.736 0 0 0 3.677 4.37a.07.07 0 0 0-.032.027C.533 9.046-.32 13.58.099 18.057a.082.082 0 0 0 .031.057 19.9 19.9 0 0 0 5.993 3.03.078.078 0 0 0 .084-.028c.462-.63.874-1.295 1.226-1.994.021-.041.001-.09-.041-.106a13.107 13.107 0 0 1-1.872-.892.077.077 0 0 1-.008-.128 10.2 10.2 0 0 0 .372-.292.074.074 0 0 1 .077-.01c3.929 1.793 8.18 1.793 12.061 0a.074.074 0 0 1 .078.01c.12.098.246.198.373.292a.077.077 0 0 1-.006.127 12.299 12.299 0 0 1-1.873.893.077.077 0 0 0-.041.107c.36.698.772 1.362 1.225 1.993a.076.076 0 0 0 .084.028 19.839 19.839 0 0 0 6.002-3.03.077.077 0 0 0 .032-.054c.5-5.177-.838-9.674-3.549-13.66a.061.061 0 0 0-.031-.028zM8.02 15.33c-1.183 0-2.157-1.085-2.157-2.419 0-1.333.956-2.419 2.157-2.419 1.21 0 2.176 1.096 2.157 2.42 0 1.333-.956 2.418-2.157 2.418zm7.975 0c-1.183 0-2.157-1.085-2.157-2.419 0-1.333.955-2.419 2.157-2.419 1.21 0 2.176 1.096 2.157 2.42 0 1.333-.946 2.418-2.157 2.418z" />
            </svg>
          </div>
        );
      case 'instagram':
        return (
          <div className="w-5 h-5 rounded-md bg-gradient-to-tr from-[#FD1D1D] via-[#E1306C] to-[#833AB4] flex items-center justify-center text-white shadow-sm flex-shrink-0">
            <Instagram className="w-3.5 h-3.5" />
          </div>
        );
      default:
        return (
          <div className="w-5 h-5 rounded-md bg-[#008CFF] flex items-center justify-center text-white shadow-sm flex-shrink-0">
            <Radio className="w-3.5 h-3.5" />
          </div>
        );
    }
  };

  const getGameThumbnail = (game: (typeof games)[0]) => {
    return (
      <div className="w-5 h-5 rounded-md overflow-hidden bg-black/40 flex items-center justify-center flex-shrink-0 border border-white/10">
        <img
          src={game.logo}
          alt={game.title}
          className="w-full h-full object-contain p-0.5"
          onError={e => {
            (e.target as HTMLElement).style.display = 'none';
          }}
        />
      </div>
    );
  };

  return (
    <>
      {/* Mobile Backdrop */}
      {mobileMenuOpen && (
        <div
          id="mobile-sidebar-backdrop"
          onClick={() => setMobileMenuOpen(false)}
          className="fixed inset-0 bg-black/80 backdrop-blur-md z-40 lg:hidden"
        />
      )}

      {/* Main Sidebar Container */}
      <aside
        className={`fixed top-[57px] bottom-0 left-0 z-40 w-72 bg-[#020817]/95 lg:bg-transparent backdrop-blur-xl lg:backdrop-blur-none border-r border-white/10 lg:border-none p-3.5 overflow-y-auto transition-transform duration-300 ease-in-out ${
          mobileMenuOpen ? 'translate-x-0' : '-translate-x-full lg:translate-x-0'
        }`}
      >
        <div className="space-y-4 pb-12">
          {/* SECTION 1: ABOUT */}
          <div className="rounded-2xl bg-[#041426]/75 border border-white/10 p-2.5 backdrop-blur-md shadow-lg">
            <div className="flex items-center gap-2 px-3 py-2 text-[#FF9500] font-bold text-xs uppercase tracking-wider font-['Space_Grotesk']">
              <Crown className="w-4 h-4 fill-current" />
              <span>ABOUT</span>
            </div>

            <div className="space-y-1 mt-1">
              {aboutLinks.map(item => {
                const isActive = currentPage === item.id;
                return (
                  <button
                    key={item.id}
                    id={`sidebar-link-${item.id}`}
                    onClick={() => {
                      setCurrentPage(item.id);
                      setMobileMenuOpen(false);
                    }}
                    className={`w-full flex items-center justify-between px-3 py-2 rounded-xl text-xs font-semibold transition-all duration-200 group ${
                      isActive
                        ? 'bg-gradient-to-r from-[#FF7A00]/25 via-[#FF9500]/15 to-transparent border border-[#FF7A00] text-white shadow-[0_0_15px_rgba(255,122,0,0.35)]'
                        : 'text-[#B8C7D9] hover:text-white hover:bg-white/5 border border-transparent'
                    }`}
                  >
                    <div className="flex items-center gap-2.5">
                      <span
                        className={`${
                          isActive ? 'text-[#FF9500]' : 'text-[#B8C7D9] group-hover:text-white'
                        }`}
                      >
                        {item.icon}
                      </span>
                      <span>{item.label}</span>
                      {item.badge && (
                        <span className="px-1.5 py-0.2 rounded bg-[#FF7A00]/20 text-[#FF9500] border border-[#FF7A00]/40 text-[9px] font-bold font-mono">
                          {item.badge}
                        </span>
                      )}
                    </div>

                    {isActive && (
                      <div className="w-1.5 h-1.5 rounded-full bg-[#FF7A00] shadow-[0_0_8px_#FF7A00]" />
                    )}
                  </button>
                );
              })}
            </div>
          </div>

          {/* SECTION 2: PLATFORMS */}
          <div className="rounded-2xl bg-[#041426]/75 border border-white/10 p-2.5 backdrop-blur-md shadow-lg">
            <div className="flex items-center justify-between px-3 py-2 text-white font-bold text-xs uppercase tracking-wider font-['Space_Grotesk']">
              <div className="flex items-center gap-2 text-[#FF7A00]">
                <Radio className="w-4 h-4 text-[#FF7A00]" />
                <span>PLATFORMS</span>
              </div>
            </div>

            <div className="space-y-1 mt-1">
              {platforms.map(platform => {
                const isPlatformPage = currentPage === platform.type;
                return (
                  <button
                    key={platform.id}
                    id={`sidebar-platform-link-${platform.id}`}
                    onClick={() => {
                      setCurrentPage(platform.type as PageId);
                      setMobileMenuOpen(false);
                    }}
                    className={`w-full flex items-center justify-between px-3 py-2 rounded-xl text-xs font-semibold transition-all duration-200 group ${
                      isPlatformPage
                        ? 'bg-[#008CFF]/20 border border-[#008CFF] text-white shadow-[0_0_15px_rgba(0,140,255,0.35)]'
                        : 'text-[#B8C7D9] hover:text-white hover:bg-white/5 border border-transparent'
                    }`}
                  >
                    <div className="flex items-center gap-2.5 truncate mr-2">
                      {getPlatformIcon(platform.type)}
                      <span className="truncate">{platform.name}</span>
                    </div>

                    <span className="text-[10px] px-2 py-0.5 rounded-full bg-white/10 font-mono text-white/80 group-hover:bg-white/20 whitespace-nowrap">
                      {platform.followers.split(' ')[0]}
                    </span>
                  </button>
                );
              })}
            </div>
          </div>

          {/* SECTION 3: GAMES */}
          <div className="rounded-2xl bg-[#041426]/75 border border-white/10 p-2.5 backdrop-blur-md shadow-lg">
            <div className="flex items-center justify-between px-3 py-2 text-white font-bold text-xs uppercase tracking-wider font-['Space_Grotesk']">
              <div className="flex items-center gap-2 text-[#FF9500]">
                <Gamepad2 className="w-4 h-4 text-[#FF9500]" />
                <span>GAMES</span>
              </div>
            </div>

            <div className="space-y-1 mt-1">
              {games.map(game => {
                const isGamePage = currentPage === `game-${game.slug}`;
                return (
                  <button
                    key={game.id}
                    id={`sidebar-game-link-${game.slug}`}
                    onClick={() => {
                      setCurrentPage(`game-${game.slug}` as PageId);
                      setMobileMenuOpen(false);
                    }}
                    className={`w-full flex items-center justify-between px-3 py-2 rounded-xl text-xs font-semibold transition-all duration-200 group ${
                      isGamePage
                        ? 'bg-gradient-to-r from-[#FF7A00]/25 via-[#008CFF]/20 to-transparent border border-[#FF7A00] text-white shadow-[0_0_15px_rgba(255,122,0,0.35)]'
                        : 'text-[#B8C7D9] hover:text-white hover:bg-white/5 border border-transparent'
                    }`}
                  >
                    <div className="flex items-center gap-2.5 truncate">
                      {getGameThumbnail(game)}
                      <span className="truncate">{game.title}</span>
                    </div>

                    <ChevronRight
                      className={`w-3.5 h-3.5 transition-transform ${
                        isGamePage
                          ? 'text-[#FF9500] translate-x-0.5'
                          : 'text-white/30 group-hover:text-white group-hover:translate-x-0.5'
                      }`}
                    />
                  </button>
                );
              })}
            </div>
          </div>

          {/* Slogan pill in sidebar */}
          <div className="px-3 py-2 text-center text-[11px] text-white/50 tracking-wider uppercase font-medium">
            "{settings.tagline}"
          </div>
        </div>
      </aside>
    </>
  );
};
