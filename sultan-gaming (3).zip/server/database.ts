import fs from 'fs';
import path from 'path';
import {
  Platform,
  User,
  AuditLog,
  ReportItem,
  CommunityPost,
  Giveaway,
  PCSpecItem,
  FAQItem,
  HeroSlide,
  Game,
  SiteSettings,
  MediaItem,
  NotificationItem,
} from '../src/types';
import {
  INITIAL_SETTINGS,
  INITIAL_HERO_SLIDES,
  INITIAL_PLATFORMS,
  INITIAL_GAMES,
  INITIAL_COMMUNITY_POSTS,
  INITIAL_PC_SPECS,
  INITIAL_GIVEAWAYS,
  INITIAL_FAQS,
  INITIAL_MEDIA,
  INITIAL_NOTIFICATIONS,
} from '../src/data/initialData';

const DATA_DIR = path.join(process.cwd(), 'data');
const DB_FILE = path.join(DATA_DIR, 'database.json');
const UPLOADS_DIR = path.join(process.cwd(), 'public', 'uploads', 'logos');

// Ensure directories exist
if (!fs.existsSync(DATA_DIR)) {
  fs.mkdirSync(DATA_DIR, { recursive: true });
}
if (!fs.existsSync(UPLOADS_DIR)) {
  fs.mkdirSync(UPLOADS_DIR, { recursive: true });
}

export interface DatabaseSchema {
  platforms: Platform[];
  settings: SiteSettings;
  heroSlides: HeroSlide[];
  games: Game[];
  posts: CommunityPost[];
  pcSpecs: PCSpecItem[];
  giveaways: Giveaway[];
  faqs: FAQItem[];
  media: MediaItem[];
  notifications: NotificationItem[];
  auditLogs: AuditLog[];
  reports: ReportItem[];
  lastUpdated: string;
}

class Database {
  private data: DatabaseSchema;
  private isSaving: boolean = false;

  constructor() {
    this.data = this.loadDatabase();
  }

  private loadDatabase(): DatabaseSchema {
    try {
      if (fs.existsSync(DB_FILE)) {
        const fileContent = fs.readFileSync(DB_FILE, 'utf-8');
        const parsed = JSON.parse(fileContent);
        if (parsed && Array.isArray(parsed.platforms)) {
          // Normalize platforms with all required fields
          parsed.platforms = parsed.platforms.map((p: any, idx: number) => ({
            ...p,
            displayOrder: typeof p.displayOrder === 'number' ? p.displayOrder : idx + 1,
            order: typeof p.displayOrder === 'number' ? p.displayOrder : idx + 1,
            isActive: p.isActive !== false,
            active: p.isActive !== false,
            syncStatus: p.syncStatus || 'CONNECTED',
            createdAt: p.createdAt || new Date().toISOString(),
            updatedAt: p.updatedAt || new Date().toISOString(),
          }));
          return parsed;
        }
      }
    } catch (err) {
      console.error('[DATABASE] Error reading database.json, initializing fresh default schema:', err);
    }

    const defaultData: DatabaseSchema = {
      platforms: [...INITIAL_PLATFORMS],
      settings: { ...INITIAL_SETTINGS },
      heroSlides: [...INITIAL_HERO_SLIDES],
      games: [...INITIAL_GAMES],
      posts: [...INITIAL_COMMUNITY_POSTS],
      pcSpecs: [...INITIAL_PC_SPECS],
      giveaways: [...INITIAL_GIVEAWAYS],
      faqs: [...INITIAL_FAQS],
      media: [...INITIAL_MEDIA],
      notifications: [...INITIAL_NOTIFICATIONS],
      auditLogs: [],
      reports: [],
      lastUpdated: new Date().toISOString(),
    };

    this.saveToDisk(defaultData);
    return defaultData;
  }

  private saveToDisk(dataToSave?: DatabaseSchema) {
    try {
      const data = dataToSave || this.data;
      data.lastUpdated = new Date().toISOString();
      const tempFile = `${DB_FILE}.tmp.${Date.now()}`;
      fs.writeFileSync(tempFile, JSON.stringify(data, null, 2), 'utf-8');
      fs.renameSync(tempFile, DB_FILE);
    } catch (err) {
      console.error('[DATABASE] Error writing to database.json:', err);
    }
  }

  // ==========================================
  // PLATFORM CRUD METHODS (SOURCE OF TRUTH)
  // ==========================================

  public getPlatforms(includeInactive = false): Platform[] {
    const list = includeInactive
      ? [...this.data.platforms]
      : this.data.platforms.filter(p => p.isActive !== false);

    return list.sort((a, b) => (a.displayOrder || 0) - (b.displayOrder || 0));
  }

  public getPlatformById(id: string): Platform | undefined {
    return this.data.platforms.find(p => p.id === id);
  }

  public createPlatform(platformData: Partial<Platform>): Platform {
    const newId = platformData.id || `plat-${Date.now()}-${Math.random().toString(36).substr(2, 6)}`;
    const maxOrder = this.data.platforms.reduce((max, p) => Math.max(max, p.displayOrder || 0), 0);

    const newPlatform: Platform = {
      id: newId,
      name: platformData.name ? platformData.name.trim() : 'Platform',
      url: platformData.url ? platformData.url.trim() : '',
      logo: platformData.logo || 'https://cdn-icons-png.flaticon.com/512/3670/3670157.png',
      banner: platformData.banner || 'https://images.unsplash.com/photo-1511512578047-dfb367046420?auto=format&fit=crop&w=1600&q=80',
      username: platformData.username || platformData.handle || platformData.name || '',
      handle: platformData.handle || platformData.username || platformData.name || '',
      followers: platformData.followers || '0 Followers',
      followersNum: typeof platformData.followersNum === 'number' ? platformData.followersNum : 0,
      subscribers: platformData.subscribers,
      members: platformData.members,
      description: platformData.description || `Official link for Sultan Gaming.`,
      platformType: platformData.platformType || platformData.type || 'custom',
      type: platformData.type || platformData.platformType || 'custom',
      accentColor: platformData.accentColor || '#008CFF',
      glowColor: platformData.glowColor || 'rgba(0, 140, 255, 0.4)',
      isActive: platformData.isActive !== false,
      active: platformData.isActive !== false,
      displayOrder: typeof platformData.displayOrder === 'number' ? platformData.displayOrder : maxOrder + 1,
      order: typeof platformData.displayOrder === 'number' ? platformData.displayOrder : maxOrder + 1,
      syncStatus: platformData.syncStatus || 'CONNECTED',
      lastSynced: platformData.lastSynced || 'Just added',
      lastSyncAt: platformData.lastSyncAt || new Date().toISOString(),
      lastSuccessfulSyncAt: platformData.lastSuccessfulSyncAt || new Date().toISOString(),
      syncSource: platformData.syncSource || 'Manual / Admin CMS',
      syncErrorMessage: platformData.syncErrorMessage,
      verified: platformData.verified !== false,
      featured: platformData.featured === true,
      liveStatus: platformData.liveStatus,
      viewerCount: platformData.viewerCount,
      createdAt: platformData.createdAt || new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };

    this.data.platforms.push(newPlatform);
    this.saveToDisk();
    return newPlatform;
  }

  public updatePlatform(id: string, updates: Partial<Platform>): Platform | null {
    const platform = this.data.platforms.find(p => p.id === id);
    if (!platform) return null;

    if (updates.name !== undefined) platform.name = updates.name.trim();
    if (updates.url !== undefined) platform.url = updates.url.trim();
    if (updates.logo !== undefined) platform.logo = updates.logo;
    if (updates.banner !== undefined) platform.banner = updates.banner;
    if (updates.username !== undefined) platform.username = updates.username;
    if (updates.handle !== undefined) platform.handle = updates.handle;
    if (updates.followers !== undefined) platform.followers = updates.followers;
    if (updates.followersNum !== undefined) platform.followersNum = updates.followersNum;
    if (updates.subscribers !== undefined) platform.subscribers = updates.subscribers;
    if (updates.members !== undefined) platform.members = updates.members;
    if (updates.description !== undefined) platform.description = updates.description;
    if (updates.platformType !== undefined || updates.type !== undefined) {
      const t = updates.platformType || updates.type || platform.type;
      platform.platformType = t;
      platform.type = t;
    }
    if (updates.accentColor !== undefined) platform.accentColor = updates.accentColor;
    if (updates.glowColor !== undefined) platform.glowColor = updates.glowColor;
    if (updates.isActive !== undefined) {
      platform.isActive = updates.isActive;
      platform.active = updates.isActive;
    }
    if (typeof updates.displayOrder === 'number') {
      platform.displayOrder = updates.displayOrder;
      platform.order = updates.displayOrder;
    }
    if (updates.verified !== undefined) platform.verified = updates.verified;
    if (updates.featured !== undefined) platform.featured = updates.featured;
    if (updates.syncStatus !== undefined) platform.syncStatus = updates.syncStatus;
    if (updates.lastSynced !== undefined) platform.lastSynced = updates.lastSynced;
    if (updates.lastSyncAt !== undefined) platform.lastSyncAt = updates.lastSyncAt;
    if (updates.lastSuccessfulSyncAt !== undefined) platform.lastSuccessfulSyncAt = updates.lastSuccessfulSyncAt;
    if (updates.syncSource !== undefined) platform.syncSource = updates.syncSource;
    if (updates.syncErrorMessage !== undefined) platform.syncErrorMessage = updates.syncErrorMessage;
    if (updates.liveStatus !== undefined) platform.liveStatus = updates.liveStatus;
    if (updates.viewerCount !== undefined) platform.viewerCount = updates.viewerCount;

    platform.updatedAt = new Date().toISOString();
    this.saveToDisk();
    return platform;
  }

  public deletePlatform(id: string): boolean {
    const index = this.data.platforms.findIndex(p => p.id === id);
    if (index === -1) return false;

    this.data.platforms.splice(index, 1);
    this.saveToDisk();
    return true;
  }

  public togglePlatformActive(id: string): Platform | null {
    const platform = this.data.platforms.find(p => p.id === id);
    if (!platform) return null;

    platform.isActive = !platform.isActive;
    platform.active = platform.isActive;
    platform.updatedAt = new Date().toISOString();
    this.saveToDisk();
    return platform;
  }

  public reorderPlatforms(orderedIds: string[]): Platform[] {
    const platformMap = new Map(this.data.platforms.map(p => [p.id, p]));
    const reordered: Platform[] = [];

    orderedIds.forEach((id, index) => {
      const p = platformMap.get(id);
      if (p) {
        p.displayOrder = index + 1;
        p.order = index + 1;
        p.updatedAt = new Date().toISOString();
        reordered.push(p);
        platformMap.delete(id);
      }
    });

    // Append any remaining platforms that weren't in orderedIds
    let currentMax = reordered.length;
    platformMap.forEach(p => {
      currentMax += 1;
      p.displayOrder = currentMax;
      p.order = currentMax;
      reordered.push(p);
    });

    this.data.platforms = reordered;
    this.saveToDisk();
    return this.getPlatforms(true);
  }

  // ==========================================
  // AUDIT LOGS
  // ==========================================
  public addAuditLog(log: AuditLog) {
    this.data.auditLogs.unshift(log);
    if (this.data.auditLogs.length > 500) {
      this.data.auditLogs.pop();
    }
    this.saveToDisk();
  }

  public getAuditLogs(): AuditLog[] {
    return this.data.auditLogs || [];
  }
}

export const db = new Database();
