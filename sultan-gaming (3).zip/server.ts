import express, { Request, Response, NextFunction } from 'express';
import path from 'path';
import fs from 'fs';
import crypto from 'crypto';
import cookieParser from 'cookie-parser';
import cors from 'cors';
import { createServer as createViteServer } from 'vite';
import { db } from './server/database';
import {
  INITIAL_SETTINGS,
  INITIAL_HERO_SLIDES,
  INITIAL_PLATFORMS,
  INITIAL_GAMES,
  INITIAL_COMMUNITY_POSTS,
  INITIAL_PC_SPECS,
  INITIAL_GIVEAWAYS,
  INITIAL_FAQS,
  INITIAL_VIDEOS,
  INITIAL_PLAYLISTS,
  INITIAL_DISCORD_CHANNELS,
  INITIAL_DISCORD_EVENTS,
  INITIAL_INSTAGRAM_POSTS,
  INITIAL_INSTAGRAM_STORIES,
  INITIAL_NOTIFICATIONS,
  INITIAL_MEDIA,
} from './src/data/initialData';
import {
  User,
  UserRole,
  UserStatus,
  AuditLog,
  ReportItem,
  CommunityPost,
  CommunityComment,
  Giveaway,
  PCSpecItem,
  FAQItem,
  HeroSlide,
  Platform,
  Game,
  SiteSettings,
  MediaItem,
  NotificationItem,
} from './src/types';
import { syncEngine, formatCount } from './server/syncAdapters';

// ==========================================
// SERVER STATE & DATABASE REPOSITORY
// ==========================================

const SESSIONS = new Map<string, { userId: string; expiresAt: number }>();

const USERS: Map<string, User> = new Map([
  [
    'user-sultan-owner',
    {
      id: 'user-sultan-owner',
      email: 'sultan@sultangaming.gg',
      displayName: 'Sultan (Owner)',
      username: 'sultan_owner',
      avatar: 'https://images.unsplash.com/photo-1566492031773-4f4e44671857?w=150&auto=format&fit=crop&q=80',
      bio: 'Official Creator & Streamer. GTA V, Palworld, Farming Simulator 25 & Minecraft.',
      role: 'SUPER_ADMIN',
      status: 'ACTIVE',
      verified: true,
      level: 99,
      xp: 450000,
      postsCount: 14,
      commentsCount: 230,
      giveawaysEnteredCount: 0,
      createdAt: '2024-01-01T00:00:00.000Z',
      lastLoginAt: new Date().toISOString(),
    },
  ],
  [
    'user-moderator-alex',
    {
      id: 'user-moderator-alex',
      email: 'alex.mod@sultangaming.gg',
      displayName: 'Alex (Mod Lead)',
      username: 'alex_mod',
      avatar: 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=150&auto=format&fit=crop&q=80',
      bio: 'Head Moderator for Sultan Gaming Community.',
      role: 'ADMIN',
      status: 'ACTIVE',
      verified: true,
      level: 45,
      xp: 85000,
      postsCount: 8,
      commentsCount: 142,
      giveawaysEnteredCount: 2,
      createdAt: '2024-02-15T00:00:00.000Z',
      lastLoginAt: new Date().toISOString(),
    },
  ],
  [
    'user-gamer-marcus',
    {
      id: 'user-gamer-marcus',
      email: 'marcus.v@gmail.com',
      displayName: 'Marcus Vance',
      username: 'marcus_v',
      avatar: 'https://images.unsplash.com/photo-1570295999919-56ceb5ecca61?w=150&auto=format&fit=crop&q=80',
      bio: 'Heavy machinery fanatic & Palworld builder.',
      role: 'USER',
      status: 'ACTIVE',
      verified: false,
      level: 12,
      xp: 14200,
      postsCount: 3,
      commentsCount: 18,
      giveawaysEnteredCount: 5,
      createdAt: '2024-05-10T00:00:00.000Z',
      lastLoginAt: new Date().toISOString(),
    },
  ],
]);

let SETTINGS: SiteSettings = { ...INITIAL_SETTINGS };
let HERO_SLIDES: HeroSlide[] = [...INITIAL_HERO_SLIDES];
let PLATFORMS: Platform[] = [...INITIAL_PLATFORMS];
let GAMES: Game[] = [...INITIAL_GAMES];
let POSTS: CommunityPost[] = [...INITIAL_COMMUNITY_POSTS];
let PC_SPECS: PCSpecItem[] = [...INITIAL_PC_SPECS];
let GIVEAWAYS: Giveaway[] = [...INITIAL_GIVEAWAYS];
let FAQS: FAQItem[] = [...INITIAL_FAQS];
let MEDIA: MediaItem[] = [...INITIAL_MEDIA];
let NOTIFICATIONS: NotificationItem[] = [...INITIAL_NOTIFICATIONS];

const POST_LIKES = new Map<string, Set<string>>([
  ['post-1', new Set(['user-sultan-owner', 'user-moderator-alex', 'user-gamer-marcus'])],
  ['post-2', new Set(['user-sultan-owner', 'user-gamer-marcus'])],
  ['post-3', new Set(['user-gamer-marcus'])],
]);

const POST_VOTES = new Map<string, Map<string, string>>([
  ['post-2', new Map([['user-sultan-owner', 'opt-1'], ['user-gamer-marcus', 'opt-1']])],
]);

const COMMENTS: Map<string, CommunityComment[]> = new Map([
  [
    'post-1',
    [
      {
        id: 'comm-1',
        postId: 'post-1',
        author: {
          name: 'Alex (Mod Lead)',
          avatar: 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=150&auto=format&fit=crop&q=80',
          level: 45,
        },
        timestamp: '2 hours ago',
        content: 'The lighting on the rooftop scene is phenomenal! Looking forward to the convoy stream tonight.',
        likes: 12,
      },
    ],
  ],
  [
    'post-2',
    [
      {
        id: 'comm-2',
        postId: 'post-2',
        author: {
          name: 'Marcus Vance',
          avatar: 'https://images.unsplash.com/photo-1570295999919-56ceb5ecca61?w=150&auto=format&fit=crop&q=80',
          level: 12,
        },
        timestamp: '5 hours ago',
        content: 'Definitely CLAAS Lexion! It handles the steep slopes near the river valley much better.',
        likes: 5,
      },
    ],
  ],
]);

const GIVEAWAY_ENTRIES = new Map<string, Set<string>>([
  ['giveaway-1', new Set(['user-gamer-marcus', 'user-moderator-alex'])],
]);

const AUDIT_LOGS: AuditLog[] = [
  {
    id: 'log-1',
    action: 'SYSTEM_INITIALIZED',
    adminId: 'user-sultan-owner',
    adminName: 'Sultan (Owner)',
    adminRole: 'SUPER_ADMIN',
    details: 'Security and RBAC system initialized with Super Admin access.',
    ipAddress: '127.0.0.1',
    timestamp: new Date(Date.now() - 86400000).toISOString(),
  },
  {
    id: 'log-2',
    action: 'ROLE_ASSIGNED',
    adminId: 'user-sultan-owner',
    adminName: 'Sultan (Owner)',
    adminRole: 'SUPER_ADMIN',
    targetId: 'user-moderator-alex',
    targetType: 'user',
    details: 'Assigned ADMIN role to alex.mod@sultangaming.gg for community moderation.',
    ipAddress: '127.0.0.1',
    timestamp: new Date(Date.now() - 43200000).toISOString(),
  },
];

const REPORTS: ReportItem[] = [
  {
    id: 'rep-1',
    reporterId: 'user-gamer-marcus',
    reporterName: 'Marcus Vance',
    targetType: 'post',
    targetId: 'post-3',
    targetSnippet: 'Need a squad for Palworld tower boss raid tonight...',
    reason: 'Checking if duplicate team recruitment post was allowed.',
    status: 'resolved',
    actionTaken: 'Verified post follows gaming community guidelines.',
    resolvedBy: 'Alex (Mod Lead)',
    createdAt: new Date(Date.now() - 172800000).toISOString(),
    resolvedAt: new Date(Date.now() - 86400000).toISOString(),
  },
];

function logAudit(
  admin: User,
  action: string,
  details: string,
  targetId?: string,
  targetType?: string,
  ip?: string
) {
  const log: AuditLog = {
    id: `log-${Date.now()}-${Math.random().toString(36).substr(2, 6)}`,
    action,
    adminId: admin.id,
    adminName: admin.displayName,
    adminRole: admin.role,
    targetId,
    targetType,
    details,
    ipAddress: ip || '127.0.0.1',
    timestamp: new Date().toISOString(),
  };
  AUDIT_LOGS.unshift(log);
  if (AUDIT_LOGS.length > 500) {
    AUDIT_LOGS.pop();
  }
  return log;
}

// ==========================================
// AUTH & RBAC MIDDLEWARE
// ==========================================

export interface AuthenticatedRequest extends Request {
  user?: User;
  sessionToken?: string;
}

function extractToken(req: Request): string | null {
  const authHeader = req.headers.authorization;
  if (authHeader && authHeader.startsWith('Bearer ')) {
    return authHeader.substring(7);
  }
  if (req.cookies && req.cookies.sultan_session) {
    return req.cookies.sultan_session;
  }
  return null;
}

function authMiddleware(req: AuthenticatedRequest, res: Response, next: NextFunction) {
  const token = extractToken(req);
  if (token) {
    const session = SESSIONS.get(token);
    if (session && session.expiresAt > Date.now()) {
      const user = USERS.get(session.userId);
      if (user) {
        req.user = user;
        req.sessionToken = token;
      }
    }
  }

  // Check client user context header if not yet resolved
  if (!req.user) {
    const customUserId = (req.headers['x-user-id'] as string) || (req.headers['x-client-userid'] as string);
    const customUserRole = (req.headers['x-user-role'] as UserRole) || 'USER';
    const customUserEmail = (req.headers['x-user-email'] as string) || '';

    if (customUserId && USERS.has(customUserId)) {
      req.user = USERS.get(customUserId);
      if (customUserRole && req.user && req.user.role !== customUserRole) {
        req.user.role = customUserRole;
      }
    } else if (customUserId) {
      // Create user entry in USERS repository for Firebase authenticated sessions
      const isOwner =
        customUserEmail === 'samgaming2726@gmail.com' ||
        customUserEmail === 'sultan@sultangaming.gg' ||
        customUserId === 'user-sultan-owner' ||
        customUserRole === 'SUPER_ADMIN';

      const userRole: UserRole = isOwner ? 'SUPER_ADMIN' : customUserRole;
      const userName = customUserEmail ? customUserEmail.split('@')[0] : 'Gamer';

      const newUser: User = {
        id: customUserId,
        email: customUserEmail || `${userName.toLowerCase()}@sultangaming.gg`,
        displayName: userName.charAt(0).toUpperCase() + userName.slice(1),
        username: userName.toLowerCase().replace(/[^a-z0-9_]/g, '_'),
        avatar: 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=150&auto=format&fit=crop&q=80',
        bio: 'Sultan Gaming Community Member',
        role: userRole,
        status: 'ACTIVE',
        verified: true,
        level: 1,
        xp: 300,
        postsCount: 0,
        commentsCount: 0,
        giveawaysEnteredCount: 0,
        createdAt: new Date().toISOString(),
        lastLoginAt: new Date().toISOString(),
      };
      USERS.set(customUserId, newUser);
      req.user = newUser;
    } else {
      // Default fallback for dev workspace preview
      req.user = USERS.get('user-sultan-owner');
    }
  }

  next();
}

function requireAuth(req: AuthenticatedRequest, res: Response, next: NextFunction) {
  if (!req.user) {
    return res.status(401).json({ error: 'Authentication required. Please log in.' });
  }
  if (req.user.status === 'BANNED') {
    return res.status(403).json({ error: 'Your account has been suspended or banned from this platform.' });
  }
  next();
}

function requireRole(allowedRoles: UserRole[]) {
  return (req: AuthenticatedRequest, res: Response, next: NextFunction) => {
    if (!req.user) {
      return res.status(401).json({ error: 'Authentication required.' });
    }
    if (req.user.status === 'BANNED') {
      return res.status(403).json({ error: 'Access forbidden: Account suspended.' });
    }
    if (!allowedRoles.includes(req.user.role)) {
      return res.status(403).json({
        error: `Access denied. Requires one of: [${allowedRoles.join(', ')}]. Your role: ${req.user.role}`,
      });
    }
    next();
  };
}

// Simple in-memory rate limiter for anti-abuse
const RATE_LIMIT_MAP = new Map<string, { count: number; resetAt: number }>();
function rateLimiter(limit: number, windowMs: number) {
  return (req: Request, res: Response, next: NextFunction) => {
    const ip = req.ip || 'anonymous';
    const key = `${ip}-${req.path}`;
    const now = Date.now();
    const entry = RATE_LIMIT_MAP.get(key);

    if (!entry || entry.resetAt < now) {
      RATE_LIMIT_MAP.set(key, { count: 1, resetAt: now + windowMs });
      return next();
    }

    if (entry.count >= limit) {
      return res.status(429).json({ error: 'Too many requests. Please slow down and try again shortly.' });
    }

    entry.count += 1;
    next();
  };
}

// ==========================================
// EXPRESS SERVER SETUP
// ==========================================

async function startServer() {
  const app = express();
  const PORT = 3000;

  // Static uploads directory serving
  const uploadsDir = path.join(process.cwd(), 'public', 'uploads');
  if (!fs.existsSync(uploadsDir)) {
    fs.mkdirSync(uploadsDir, { recursive: true });
  }
  const logosDir = path.join(uploadsDir, 'logos');
  if (!fs.existsSync(logosDir)) {
    fs.mkdirSync(logosDir, { recursive: true });
  }

  app.use('/uploads', express.static(uploadsDir));

  // Security Headers & Middlewares
  app.use(express.json({ limit: '20mb' }));
  app.use(express.urlencoded({ extended: true, limit: '20mb' }));
  app.use(cookieParser());
  app.use(cors({ origin: true, credentials: true }));

  // Custom Security Headers
  app.use((req, res, next) => {
    res.setHeader('X-Content-Type-Options', 'nosniff');
    res.setHeader('X-XSS-Protection', '1; mode=block');
    res.setHeader('Referrer-Policy', 'strict-origin-when-cross-origin');
    next();
  });

  app.use(authMiddleware);

  // ==========================================
  // AUTHENTICATION & USER ENDPOINTS
  // ==========================================

  // 1. Get Current Authenticated User & Permissions
  app.get('/api/auth/me', (req: AuthenticatedRequest, res: Response) => {
    if (!req.user) {
      return res.json({
        authenticated: false,
        user: null,
        permissions: {
          canPost: false,
          canModerate: false,
          canManageUsers: false,
          canManageSystem: false,
        },
      });
    }

    const permissions = {
      canPost: req.user.status === 'ACTIVE',
      canModerate: ['ADMIN', 'SUPER_ADMIN'].includes(req.user.role),
      canManageUsers: req.user.role === 'SUPER_ADMIN',
      canManageSystem: req.user.role === 'SUPER_ADMIN',
    };

    res.json({
      authenticated: true,
      user: req.user,
      permissions,
    });
  });

  // 2. Google OAuth / OpenID Token Verification & Login
  app.post('/api/auth/google', rateLimiter(10, 60000), async (req: Request, res: Response) => {
    try {
      const { credential, email, name, picture, googleId } = req.body;

      let userEmail = email;
      let userName = name;
      let userAvatar = picture;
      let userGId = googleId;

      // If a JWT credential was passed, decode payload safely
      if (credential && typeof credential === 'string') {
        try {
          const parts = credential.split('.');
          if (parts.length === 3) {
            const payload = JSON.parse(Buffer.from(parts[1], 'base64').toString());
            userEmail = payload.email || userEmail;
            userName = payload.name || userName;
            userAvatar = payload.picture || userAvatar;
            userGId = payload.sub || userGId;
          }
        } catch {
          // fallback to direct fields
        }
      }

      if (!userEmail) {
        return res.status(400).json({ error: 'Valid email is required for authentication.' });
      }

      // Find existing user by email
      let user: User | undefined;
      for (const existing of USERS.values()) {
        if (existing.email.toLowerCase() === userEmail.toLowerCase()) {
          user = existing;
          break;
        }
      }

      if (!user) {
        // Determine role: Sultan or designated admin emails become super_admin/admin
        const isSuperAdminEmail =
          userEmail.toLowerCase().includes('sultan') || userEmail.toLowerCase() === 'owner@sultangaming.gg';
        const role: UserRole = isSuperAdminEmail ? 'SUPER_ADMIN' : 'USER';

        const newId = `user-${Date.now()}-${Math.random().toString(36).substr(2, 6)}`;
        const usernameBase = (userEmail.split('@')[0] || 'gamer').replace(/[^a-zA-Z0-9_]/g, '');

        user = {
          id: newId,
          googleId: userGId || `gid_${Date.now()}`,
          email: userEmail,
          displayName: userName || usernameBase,
          username: usernameBase,
          avatar:
            userAvatar ||
            `https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=150&auto=format&fit=crop&q=80`,
          bio: 'Sultan Gaming Community Member',
          role,
          status: 'ACTIVE',
          verified: role !== 'USER',
          level: 1,
          xp: 100,
          postsCount: 0,
          commentsCount: 0,
          giveawaysEnteredCount: 0,
          createdAt: new Date().toISOString(),
          lastLoginAt: new Date().toISOString(),
        };

        USERS.set(user.id, user);

        logAudit(
          user,
          'USER_REGISTERED',
          `New user registered via Google: ${user.email} with role ${user.role}`,
          user.id,
          'user',
          req.ip
        );
      } else {
        user.lastLoginAt = new Date().toISOString();
        if (userAvatar) user.avatar = userAvatar;
        if (userName && !user.displayName) user.displayName = userName;
        USERS.set(user.id, user);
      }

      if (user.status === 'BANNED') {
        return res.status(403).json({ error: 'Your account has been suspended or banned.' });
      }

      // Generate Session Token
      const sessionToken = crypto.randomBytes(32).toString('hex');
      const expiresAt = Date.now() + 30 * 24 * 60 * 60 * 1000; // 30 days
      SESSIONS.set(sessionToken, { userId: user.id, expiresAt });

      res.cookie('sultan_session', sessionToken, {
        httpOnly: true,
        secure: process.env.NODE_ENV === 'production',
        sameSite: 'lax',
        maxAge: 30 * 24 * 60 * 60 * 1000,
      });

      res.json({
        success: true,
        sessionToken,
        user,
      });
    } catch (err: any) {
      res.status(500).json({ error: err.message || 'Authentication failed' });
    }
  });

  // 3. Dev / Fast Role Switcher & Sandbox Auth
  app.post('/api/auth/dev-switch-role', (req: Request, res: Response) => {
    const { role, customUserId } = req.body;

    let targetUser: User | undefined;

    if (customUserId && USERS.has(customUserId)) {
      targetUser = USERS.get(customUserId);
    } else if (role === 'SUPER_ADMIN') {
      targetUser = USERS.get('user-sultan-owner');
    } else if (role === 'ADMIN') {
      targetUser = USERS.get('user-moderator-alex');
    } else {
      targetUser = USERS.get('user-gamer-marcus');
    }

    if (!targetUser) {
      return res.status(404).json({ error: 'Target user not found' });
    }

    targetUser.lastLoginAt = new Date().toISOString();

    const sessionToken = crypto.randomBytes(32).toString('hex');
    const expiresAt = Date.now() + 30 * 24 * 60 * 60 * 1000;
    SESSIONS.set(sessionToken, { userId: targetUser.id, expiresAt });

    res.cookie('sultan_session', sessionToken, {
      httpOnly: true,
      secure: process.env.NODE_ENV === 'production',
      sameSite: 'lax',
      maxAge: 30 * 24 * 60 * 60 * 1000,
    });

    res.json({
      success: true,
      sessionToken,
      user: targetUser,
    });
  });

  // 4. Logout
  app.post('/api/auth/logout', (req: AuthenticatedRequest, res: Response) => {
    if (req.sessionToken) {
      SESSIONS.delete(req.sessionToken);
    }
    res.clearCookie('sultan_session');
    res.json({ success: true, message: 'Logged out successfully.' });
  });

  // 5. Update Profile
  app.put('/api/auth/profile', requireAuth, (req: AuthenticatedRequest, res: Response) => {
    const user = req.user!;
    const { displayName, bio, avatar, username } = req.body;

    if (displayName) user.displayName = displayName.trim().substring(0, 50);
    if (bio !== undefined) user.bio = bio.trim().substring(0, 250);
    if (avatar) user.avatar = avatar;
    if (username) {
      const cleanUsername = username.toLowerCase().replace(/[^a-z0-9_]/g, '').substring(0, 25);
      if (cleanUsername) user.username = cleanUsername;
    }

    USERS.set(user.id, user);
    res.json({ success: true, user });
  });

  // 6. Delete Account (Right to Be Forgotten)
  app.delete('/api/auth/account', requireAuth, (req: AuthenticatedRequest, res: Response) => {
    const user = req.user!;
    if (user.role === 'SUPER_ADMIN') {
      return res.status(400).json({ error: 'Super Admin accounts cannot be self-deleted.' });
    }

    USERS.delete(user.id);
    if (req.sessionToken) {
      SESSIONS.delete(req.sessionToken);
    }
    res.clearCookie('sultan_session');
    res.json({ success: true, message: 'Your account and personal data have been permanently deleted.' });
  });

  // ==========================================
  // COMMUNITY & POSTS ENDPOINTS
  // ==========================================

  // List Posts (with user liked / voted state)
  app.get('/api/posts', (req: AuthenticatedRequest, res: Response) => {
    const currentUserId = req.user?.id;
    const gameTag = req.query.gameTag as string | undefined;

    let filtered = POSTS;
    if (gameTag && gameTag !== 'all') {
      filtered = POSTS.filter(p => p.gameTag.toLowerCase() === gameTag.toLowerCase());
    }

    const result = filtered.map(post => {
      const likesSet = POST_LIKES.get(post.id) || new Set();
      const votesMap = POST_VOTES.get(post.id) || new Map();

      return {
        ...post,
        likes: likesSet.size || post.likes,
        userLiked: currentUserId ? likesSet.has(currentUserId) : false,
        poll: post.poll
          ? {
              ...post.poll,
              userVotedOptionId: currentUserId ? votesMap.get(currentUserId) : undefined,
            }
          : undefined,
      };
    });

    res.json({ posts: result });
  });

  // Create Post
  app.post('/api/posts', requireAuth, rateLimiter(5, 60000), (req: AuthenticatedRequest, res: Response) => {
    const user = req.user!;
    const { gameTag, content, images, poll } = req.body;

    if (!content || !content.trim()) {
      return res.status(400).json({ error: 'Post content cannot be empty.' });
    }

    if (content.length > 2000) {
      return res.status(400).json({ error: 'Post content exceeds 2,000 character limit.' });
    }

    const sanitizedContent = content.trim();

    let formattedPoll;
    if (poll && poll.question && Array.isArray(poll.options) && poll.options.length >= 2) {
      formattedPoll = {
        question: poll.question.trim(),
        options: poll.options.slice(0, 5).map((opt: string, idx: number) => ({
          id: `opt-${Date.now()}-${idx}`,
          text: opt.trim(),
          votes: 0,
        })),
        totalVotes: 0,
      };
    }

    const newPost: CommunityPost = {
      id: `post-${Date.now()}`,
      author: {
        name: user.displayName,
        avatar: user.avatar,
        level: user.level,
        badge: user.role === 'SUPER_ADMIN' ? 'Owner' : user.role === 'ADMIN' ? 'Moderator' : undefined,
        verified: user.verified,
        isOwner: user.role === 'SUPER_ADMIN',
      },
      timestamp: 'Just now',
      gameTag: gameTag || 'General',
      content: sanitizedContent,
      images: Array.isArray(images) ? images.slice(0, 4) : undefined,
      likes: 0,
      commentsCount: 0,
      userLiked: false,
      poll: formattedPoll,
    };

    POSTS.unshift(newPost);
    user.postsCount += 1;
    user.xp += 50;
    USERS.set(user.id, user);

    res.status(201).json({ success: true, post: newPost });
  });

  // Toggle Like Post
  app.post('/api/posts/:id/like', requireAuth, (req: AuthenticatedRequest, res: Response) => {
    const postId = req.params.id;
    const user = req.user!;

    const post = POSTS.find(p => p.id === postId);
    if (!post) {
      return res.status(404).json({ error: 'Post not found' });
    }

    if (!POST_LIKES.has(postId)) {
      POST_LIKES.set(postId, new Set());
    }

    const likesSet = POST_LIKES.get(postId)!;
    const isLiked = likesSet.has(user.id);

    if (isLiked) {
      likesSet.delete(user.id);
    } else {
      likesSet.add(user.id);
    }

    post.likes = likesSet.size;
    res.json({ success: true, userLiked: !isLiked, totalLikes: post.likes });
  });

  // Vote on Poll
  app.post('/api/posts/:id/vote', requireAuth, (req: AuthenticatedRequest, res: Response) => {
    const postId = req.params.id;
    const { optionId } = req.body;
    const user = req.user!;

    const post = POSTS.find(p => p.id === postId);
    if (!post || !post.poll) {
      return res.status(404).json({ error: 'Poll not found on this post' });
    }

    if (!POST_VOTES.has(postId)) {
      POST_VOTES.set(postId, new Map());
    }

    const votesMap = POST_VOTES.get(postId)!;
    if (votesMap.has(user.id)) {
      return res.status(400).json({ error: 'You have already voted in this poll' });
    }

    const targetOpt = post.poll.options.find(o => o.id === optionId);
    if (!targetOpt) {
      return res.status(404).json({ error: 'Poll option not found' });
    }

    targetOpt.votes += 1;
    post.poll.totalVotes += 1;
    votesMap.set(user.id, optionId);

    res.json({ success: true, poll: post.poll, userVotedOptionId: optionId });
  });

  // Delete Post (Author or Admin)
  app.delete('/api/posts/:id', requireAuth, (req: AuthenticatedRequest, res: Response) => {
    const postId = req.params.id;
    const user = req.user!;

    const index = POSTS.findIndex(p => p.id === postId);
    if (index === -1) {
      return res.status(404).json({ error: 'Post not found' });
    }

    const post = POSTS[index];
    const isAuthor = post.author.name === user.displayName || post.author.name === user.username;
    const isMod = ['ADMIN', 'SUPER_ADMIN'].includes(user.role);

    if (!isAuthor && !isMod) {
      return res.status(403).json({ error: 'You do not have permission to delete this post.' });
    }

    POSTS.splice(index, 1);
    POST_LIKES.delete(postId);
    POST_VOTES.delete(postId);
    COMMENTS.delete(postId);

    if (isMod && !isAuthor) {
      logAudit(
        user,
        'POST_DELETED_BY_MOD',
        `Moderator removed post by ${post.author.name}: "${post.content.substring(0, 60)}..."`,
        postId,
        'post',
        req.ip
      );
    }

    res.json({ success: true, message: 'Post deleted successfully.' });
  });

  // Report Post
  app.post('/api/posts/:id/report', requireAuth, (req: AuthenticatedRequest, res: Response) => {
    const postId = req.params.id;
    const { reason } = req.body;
    const user = req.user!;

    const post = POSTS.find(p => p.id === postId);
    if (!post) {
      return res.status(404).json({ error: 'Post not found' });
    }

    const report: ReportItem = {
      id: `rep-${Date.now()}`,
      reporterId: user.id,
      reporterName: user.displayName,
      targetType: 'post',
      targetId: postId,
      targetSnippet: post.content.substring(0, 100),
      reason: reason || 'Inappropriate gaming content / community violation',
      status: 'pending',
      createdAt: new Date().toISOString(),
    };

    REPORTS.unshift(report);
    res.json({ success: true, message: 'Report submitted to moderators. Thank you for keeping the community safe.' });
  });

  // Comments Endpoints
  app.get('/api/posts/:id/comments', (req: Request, res: Response) => {
    const postId = req.params.id;
    const postComments = COMMENTS.get(postId) || [];
    res.json({ comments: postComments });
  });

  app.post('/api/posts/:id/comments', requireAuth, rateLimiter(10, 60000), (req: AuthenticatedRequest, res: Response) => {
    const postId = req.params.id;
    const { content } = req.body;
    const user = req.user!;

    if (!content || !content.trim()) {
      return res.status(400).json({ error: 'Comment text cannot be empty' });
    }

    const post = POSTS.find(p => p.id === postId);
    if (!post) {
      return res.status(404).json({ error: 'Post not found' });
    }

    const newComment: CommunityComment = {
      id: `comm-${Date.now()}`,
      postId,
      author: {
        name: user.displayName,
        avatar: user.avatar,
        level: user.level,
      },
      timestamp: 'Just now',
      content: content.trim().substring(0, 500),
      likes: 0,
    };

    if (!COMMENTS.has(postId)) {
      COMMENTS.set(postId, []);
    }
    COMMENTS.get(postId)!.push(newComment);
    post.commentsCount = COMMENTS.get(postId)!.length;

    user.commentsCount += 1;
    user.xp += 15;
    USERS.set(user.id, user);

    res.status(201).json({ success: true, comment: newComment });
  });

  // ==========================================
  // GIVEAWAYS ENDPOINTS
  // ==========================================

  app.get('/api/giveaways', (req: AuthenticatedRequest, res: Response) => {
    const currentUserId = req.user?.id;
    const result = GIVEAWAYS.map(g => {
      const entries = GIVEAWAY_ENTRIES.get(g.id) || new Set();
      return {
        ...g,
        entriesCount: entries.size || g.entriesCount,
        isEntered: currentUserId ? entries.has(currentUserId) : false,
      };
    });
    res.json({ giveaways: result });
  });

  app.post('/api/giveaways/:id/enter', requireAuth, (req: AuthenticatedRequest, res: Response) => {
    const giveawayId = req.params.id;
    const user = req.user!;

    const giveaway = GIVEAWAYS.find(g => g.id === giveawayId);
    if (!giveaway) {
      return res.status(404).json({ error: 'Giveaway not found' });
    }
    if (giveaway.completed) {
      return res.status(400).json({ error: 'This giveaway is already completed.' });
    }

    if (!GIVEAWAY_ENTRIES.has(giveawayId)) {
      GIVEAWAY_ENTRIES.set(giveawayId, new Set());
    }

    const entries = GIVEAWAY_ENTRIES.get(giveawayId)!;
    if (entries.has(user.id)) {
      return res.status(400).json({ error: 'You are already registered for this giveaway.' });
    }

    entries.add(user.id);
    giveaway.entriesCount = entries.size;
    user.giveawaysEnteredCount += 1;
    user.xp += 100;
    USERS.set(user.id, user);

    res.json({ success: true, message: 'Successfully entered giveaway!', entriesCount: giveaway.entriesCount });
  });

  app.post('/api/giveaways/:id/draw-winner', requireRole(['ADMIN', 'SUPER_ADMIN']), (req: AuthenticatedRequest, res: Response) => {
    const giveawayId = req.params.id;
    const admin = req.user!;

    const giveaway = GIVEAWAYS.find(g => g.id === giveawayId);
    if (!giveaway) {
      return res.status(404).json({ error: 'Giveaway not found' });
    }

    const entries = GIVEAWAY_ENTRIES.get(giveawayId);
    const entryIds = entries ? Array.from(entries) : [];

    let winnerUser: User | undefined;
    if (entryIds.length > 0) {
      const winnerId = entryIds[Math.floor(Math.random() * entryIds.length)];
      winnerUser = USERS.get(winnerId);
    }

    giveaway.completed = true;
    giveaway.winnerAnnounced = true;
    giveaway.winnerName = winnerUser ? `${winnerUser.displayName} (@${winnerUser.username})` : 'GamerTag_SultanFan';

    logAudit(
      admin,
      'GIVEAWAY_WINNER_DRAWN',
      `Drew official winner for ${giveaway.title}: ${giveaway.winnerName}`,
      giveawayId,
      'giveaway',
      req.ip
    );

    res.json({ success: true, giveaway });
  });

  // ==========================================
  // ADMIN CMS & MODERATION ENDPOINTS
  // ==========================================

  // List Users (Admin/Super Admin)
  app.get('/api/admin/users', requireRole(['ADMIN', 'SUPER_ADMIN']), (req: Request, res: Response) => {
    const list = Array.from(USERS.values());
    res.json({ users: list });
  });

  // Change User Role (Super Admin only)
  app.put('/api/admin/users/:id/role', requireRole(['SUPER_ADMIN']), (req: AuthenticatedRequest, res: Response) => {
    const targetUserId = req.params.id;
    const { role } = req.body;
    const admin = req.user!;

    const targetUser = USERS.get(targetUserId);
    if (!targetUser) {
      return res.status(404).json({ error: 'User not found' });
    }

    if (targetUser.id === admin.id && role !== 'SUPER_ADMIN') {
      return res.status(400).json({ error: 'You cannot revoke your own Super Admin status.' });
    }

    const oldRole = targetUser.role;
    targetUser.role = role;
    USERS.set(targetUser.id, targetUser);

    logAudit(
      admin,
      'USER_ROLE_CHANGED',
      `Changed role for ${targetUser.email} from ${oldRole} to ${role}`,
      targetUser.id,
      'user',
      req.ip
    );

    res.json({ success: true, user: targetUser });
  });

  // Change User Status (Ban / Suspend)
  app.put('/api/admin/users/:id/status', requireRole(['ADMIN', 'SUPER_ADMIN']), (req: AuthenticatedRequest, res: Response) => {
    const targetUserId = req.params.id;
    const { status, reason } = req.body;
    const admin = req.user!;

    const targetUser = USERS.get(targetUserId);
    if (!targetUser) {
      return res.status(404).json({ error: 'User not found' });
    }

    if (targetUser.role === 'SUPER_ADMIN') {
      return res.status(403).json({ error: 'Cannot modify Super Admin accounts.' });
    }

    const oldStatus = targetUser.status;
    targetUser.status = status;
    USERS.set(targetUser.id, targetUser);

    logAudit(
      admin,
      `USER_STATUS_${status}`,
      `Changed status for ${targetUser.email} from ${oldStatus} to ${status}. Reason: ${reason || 'Violation of rules'}`,
      targetUser.id,
      'user',
      req.ip
    );

    res.json({ success: true, user: targetUser });
  });

  // Audit Logs Endpoint
  app.get('/api/admin/audit-logs', requireRole(['ADMIN', 'SUPER_ADMIN']), (req: Request, res: Response) => {
    res.json({ auditLogs: AUDIT_LOGS });
  });

  // Reports Endpoint
  app.get('/api/admin/reports', requireRole(['ADMIN', 'SUPER_ADMIN']), (req: Request, res: Response) => {
    res.json({ reports: REPORTS });
  });

  app.put('/api/admin/reports/:id', requireRole(['ADMIN', 'SUPER_ADMIN']), (req: AuthenticatedRequest, res: Response) => {
    const reportId = req.params.id;
    const { status, actionTaken } = req.body;
    const admin = req.user!;

    const report = REPORTS.find(r => r.id === reportId);
    if (!report) {
      return res.status(404).json({ error: 'Report not found' });
    }

    report.status = status || 'resolved';
    report.actionTaken = actionTaken || 'Action taken by moderator.';
    report.resolvedBy = admin.displayName;
    report.resolvedAt = new Date().toISOString();

    logAudit(
      admin,
      'REPORT_RESOLVED',
      `Resolved report on ${report.targetType} ${report.targetId}: ${report.actionTaken}`,
      report.id,
      'report',
      req.ip
    );

    res.json({ success: true, report });
  });

  // Site Settings (Super Admin only)
  app.get('/api/settings', (req: Request, res: Response) => {
    res.json({ settings: SETTINGS });
  });

  app.put('/api/settings', requireRole(['SUPER_ADMIN']), (req: AuthenticatedRequest, res: Response) => {
    const updates = req.body;
    const admin = req.user!;

    SETTINGS = { ...SETTINGS, ...updates };

    logAudit(
      admin,
      'SITE_SETTINGS_UPDATED',
      `Updated site branding, stats or social links configuration.`,
      undefined,
      'settings',
      req.ip
    );

    res.json({ success: true, settings: SETTINGS });
  });

  // Media Library Upload & Management
  app.get('/api/admin/media', (req: Request, res: Response) => {
    res.json({ media: MEDIA });
  });

  app.post('/api/admin/media', requireRole(['ADMIN', 'SUPER_ADMIN']), (req: AuthenticatedRequest, res: Response) => {
    const { name, url, size, type } = req.body;
    const admin = req.user!;

    if (!url || !name) {
      return res.status(400).json({ error: 'Media URL and Name are required.' });
    }

    const newItem: MediaItem = {
      id: `media-${Date.now()}`,
      name: name.trim(),
      url,
      size: size || '1.2 MB',
      type: type || 'banner',
      createdAt: new Date().toISOString().split('T')[0],
    };

    MEDIA.unshift(newItem);

    logAudit(admin, 'MEDIA_UPLOADED', `Uploaded asset ${newItem.name} (${newItem.type})`, newItem.id, 'media', req.ip);

    res.status(201).json({ success: true, media: newItem });
  });

  app.delete('/api/admin/media/:id', requireRole(['ADMIN', 'SUPER_ADMIN']), (req: AuthenticatedRequest, res: Response) => {
    const id = req.params.id;
    const admin = req.user!;
    MEDIA = MEDIA.filter(m => m.id !== id);
    logAudit(admin, 'MEDIA_DELETED', `Deleted media asset ID: ${id}`, id, 'media', req.ip);
    res.json({ success: true });
  });

  // ==========================================
  // LOGO & MEDIA UPLOAD SYSTEM
  // ==========================================

  app.post('/api/upload/logo', requireRole(['ADMIN', 'SUPER_ADMIN']), (req: AuthenticatedRequest, res: Response) => {
    try {
      const { fileData, fileName } = req.body;
      if (!fileData || typeof fileData !== 'string') {
        return res.status(400).json({ error: 'No image data provided.' });
      }

      // Format validation: allow data:image/(png|jpeg|jpg|webp|svg\+xml);base64,...
      const match = fileData.match(/^data:image\/(png|jpeg|jpg|webp|svg\+xml);base64,(.+)$/i);
      if (!match) {
        return res.status(400).json({
          error: 'Invalid file format. Supported formats: JPG, JPEG, PNG, WEBP, SVG.',
        });
      }

      let extension = match[1].toLowerCase();
      if (extension === 'jpeg') extension = 'jpg';
      if (extension === 'svg+xml') extension = 'svg';
      const base64Data = match[2];
      const buffer = Buffer.from(base64Data, 'base64');

      // 10MB size limit check
      if (buffer.length > 10 * 1024 * 1024) {
        return res.status(400).json({ error: 'File size exceeds maximum allowed limit (10MB).' });
      }

      const targetDir = path.join(process.cwd(), 'public', 'uploads', 'logos');
      if (!fs.existsSync(targetDir)) {
        fs.mkdirSync(targetDir, { recursive: true });
      }

      const cleanFileName = `logo_${Date.now()}_${Math.random().toString(36).substring(2, 8)}.${extension}`;
      const filePath = path.join(targetDir, cleanFileName);
      fs.writeFileSync(filePath, buffer);

      const publicUrl = `/uploads/logos/${cleanFileName}`;
      return res.status(200).json({
        success: true,
        url: publicUrl,
        fileName: cleanFileName,
        size: `${(buffer.length / 1024).toFixed(1)} KB`,
      });
    } catch (err: any) {
      console.error('[UPLOAD] Error saving logo:', err);
      return res.status(500).json({ error: err?.message || 'Failed to process logo upload.' });
    }
  });

  // General Image / Media File Upload (Community Posts, Profile Avatars, Media Gallery)
  app.post('/api/upload/image', (req: AuthenticatedRequest, res: Response) => {
    try {
      const { fileData, fileName, folder = 'images' } = req.body;
      if (!fileData || typeof fileData !== 'string') {
        return res.status(400).json({ error: 'No image data provided.' });
      }

      const match = fileData.match(/^data:image\/(png|jpeg|jpg|webp|gif|svg\+xml);base64,(.+)$/i);
      if (!match) {
        return res.status(400).json({
          error: 'Invalid file format. Supported formats: PNG, JPG, JPEG, WEBP, GIF, SVG.',
        });
      }

      let extension = match[1].toLowerCase();
      if (extension === 'jpeg') extension = 'jpg';
      if (extension === 'svg+xml') extension = 'svg';
      const base64Data = match[2];
      const buffer = Buffer.from(base64Data, 'base64');

      // 10MB limit
      if (buffer.length > 10 * 1024 * 1024) {
        return res.status(400).json({ error: 'File size exceeds maximum allowed limit (10MB).' });
      }

      const safeFolder = folder === 'avatars' ? 'avatars' : folder === 'posts' ? 'posts' : 'images';
      const targetDir = path.join(process.cwd(), 'public', 'uploads', safeFolder);
      if (!fs.existsSync(targetDir)) {
        fs.mkdirSync(targetDir, { recursive: true });
      }

      const cleanFileName = `${safeFolder}_${Date.now()}_${Math.random().toString(36).substring(2, 8)}.${extension}`;
      const filePath = path.join(targetDir, cleanFileName);
      fs.writeFileSync(filePath, buffer);

      const publicUrl = `/uploads/${safeFolder}/${cleanFileName}`;
      return res.status(200).json({
        success: true,
        url: publicUrl,
        fileName: cleanFileName,
        size: `${(buffer.length / 1024).toFixed(1)} KB`,
      });
    } catch (err: any) {
      console.error('[UPLOAD] Error saving image:', err);
      return res.status(500).json({ error: err?.message || 'Failed to process image upload.' });
    }
  });

  // ==========================================
  // PLATFORMS CRUD & SYNC SYSTEM (PERSISTENT DATABASE SOURCE OF TRUTH)
  // ==========================================

  // 1. Public / Client Get Platforms
  app.get('/api/platforms', (req: Request, res: Response) => {
    const includeInactive = req.query.includeInactive === 'true';
    const list = db.getPlatforms(includeInactive);
    res.json({ platforms: list });
  });

  // 2. Admin Get All Platforms
  app.get('/api/admin/platforms', requireRole(['ADMIN', 'SUPER_ADMIN']), (req: Request, res: Response) => {
    const list = db.getPlatforms(true);
    res.json({ platforms: list });
  });

  // 3. Admin Add Platform (Real Persistent Database Save)
  app.post('/api/admin/platforms', requireRole(['ADMIN', 'SUPER_ADMIN']), async (req: AuthenticatedRequest, res: Response) => {
    const admin = req.user!;
    const {
      name,
      url,
      logo,
      banner,
      followers,
      followersNum,
      subscribers,
      members,
      platformType,
      type,
      accentColor,
      glowColor,
      description,
      username,
      handle,
      isActive,
      verified,
      featured,
    } = req.body;

    // Strict validation
    if (!name || !name.trim()) {
      return res.status(400).json({ error: 'Platform display name is required.' });
    }

    if (!url || !url.trim()) {
      return res.status(400).json({ error: 'Platform URL is required.' });
    }

    // URL format validation
    const trimmedUrl = url.trim();
    if (!/^https?:\/\/.+/i.test(trimmedUrl)) {
      return res.status(400).json({ error: 'Invalid platform URL format. Must start with http:// or https://' });
    }

    const { platformName, adapter } = syncEngine.identifyPlatform(trimmedUrl);
    const finalName = name.trim();
    const finalType = (type || platformType || adapter.name.toLowerCase() || 'custom') as any;

    const createdPlatform = db.createPlatform({
      name: finalName,
      url: trimmedUrl,
      logo: logo || 'https://cdn-icons-png.flaticon.com/512/3670/3670157.png',
      banner: banner || 'https://images.unsplash.com/photo-1511512578047-dfb367046420?auto=format&fit=crop&w=1600&q=80',
      followers: followers || '0 Followers',
      followersNum: typeof followersNum === 'number' ? followersNum : 0,
      subscribers: subscribers || undefined,
      members: members || undefined,
      platformType: finalType,
      type: finalType,
      accentColor: accentColor || '#008CFF',
      glowColor: glowColor || 'rgba(0, 140, 255, 0.4)',
      description: description || `Official ${finalName} link for Sultan Gaming.`,
      username: username || handle || finalName,
      handle: handle || username || finalName,
      isActive: isActive !== false,
      verified: verified !== false,
      featured: featured === true,
      syncSource: 'Manual / Admin CMS',
    });

    // Attempt initial live sync if adapter supports it
    try {
      const syncRes = await adapter.sync(createdPlatform.url, createdPlatform);
      if (syncRes.success) {
        db.updatePlatform(createdPlatform.id, {
          followers: syncRes.followers || createdPlatform.followers,
          followersNum: syncRes.followersNum || createdPlatform.followersNum,
          subscribers: syncRes.subscribers || createdPlatform.subscribers,
          members: syncRes.members || createdPlatform.members,
          liveStatus: syncRes.liveStatus !== undefined ? syncRes.liveStatus : createdPlatform.liveStatus,
          viewerCount: syncRes.viewerCount !== undefined ? syncRes.viewerCount : createdPlatform.viewerCount,
          syncStatus: 'SYNCED',
          syncSource: syncRes.syncSource,
          lastSuccessfulSyncAt: new Date().toISOString(),
        });
      }
    } catch {
      // Keep initial manual values in database
    }

    const savedPlatform = db.getPlatformById(createdPlatform.id) || createdPlatform;

    logAudit(
      admin,
      'PLATFORM_CREATED',
      `Saved new platform "${savedPlatform.name}" (${savedPlatform.url}) into database`,
      savedPlatform.id,
      'platform',
      req.ip
    );

    res.status(201).json({ success: true, platform: savedPlatform });
  });

  // 4. Admin Update Platform (Real Persistent Database Update)
  const handleUpdatePlatform = async (req: AuthenticatedRequest, res: Response) => {
    const id = req.params.id;
    const admin = req.user!;
    const platform = db.getPlatformById(id);

    if (!platform) {
      return res.status(404).json({ error: 'Platform not found in database.' });
    }

    const {
      name,
      url,
      logo,
      banner,
      followers,
      followersNum,
      subscribers,
      members,
      platformType,
      type,
      accentColor,
      glowColor,
      description,
      username,
      handle,
      isActive,
      displayOrder,
      verified,
      featured,
    } = req.body;

    if (url && url.trim() && !/^https?:\/\/.+/i.test(url.trim())) {
      return res.status(400).json({ error: 'Invalid platform URL format. Must start with http:// or https://' });
    }

    const updated = db.updatePlatform(id, {
      ...(name !== undefined && { name: name.trim() }),
      ...(url !== undefined && { url: url.trim() }),
      ...(logo !== undefined && { logo }),
      ...(banner !== undefined && { banner }),
      ...(followers !== undefined && { followers }),
      ...(followersNum !== undefined && { followersNum }),
      ...(subscribers !== undefined && { subscribers }),
      ...(members !== undefined && { members }),
      ...((platformType || type) && { platformType: platformType || type, type: platformType || type }),
      ...(accentColor !== undefined && { accentColor }),
      ...(glowColor !== undefined && { glowColor }),
      ...(description !== undefined && { description }),
      ...(username !== undefined && { username }),
      ...(handle !== undefined && { handle }),
      ...(isActive !== undefined && { isActive, active: isActive }),
      ...(typeof displayOrder === 'number' && { displayOrder, order: displayOrder }),
      ...(verified !== undefined && { verified }),
      ...(featured !== undefined && { featured }),
    });

    if (!updated) {
      return res.status(500).json({ error: 'Failed to update platform in database.' });
    }

    logAudit(
      admin,
      'PLATFORM_UPDATED',
      `Updated platform "${updated.name}" details in database`,
      updated.id,
      'platform',
      req.ip
    );

    res.json({ success: true, platform: updated });
  };

  app.put('/api/admin/platforms/:id', requireRole(['ADMIN', 'SUPER_ADMIN']), handleUpdatePlatform);
  app.patch('/api/admin/platforms/:id', requireRole(['ADMIN', 'SUPER_ADMIN']), handleUpdatePlatform);

  // 5. Admin Delete Platform (Real Persistent Database Deletion)
  app.delete('/api/admin/platforms/:id', requireRole(['ADMIN', 'SUPER_ADMIN']), (req: AuthenticatedRequest, res: Response) => {
    const id = req.params.id;
    const admin = req.user!;
    const platform = db.getPlatformById(id);

    if (!platform) {
      return res.status(404).json({ error: 'Platform not found in database.' });
    }

    const deleted = db.deletePlatform(id);
    if (!deleted) {
      return res.status(500).json({ error: 'Failed to delete platform from database.' });
    }

    logAudit(
      admin,
      'PLATFORM_DELETED',
      `Permanently deleted platform "${platform.name}" (${platform.url}) from database`,
      platform.id,
      'platform',
      req.ip
    );

    res.json({ success: true, message: `Platform ${platform.name} deleted successfully.` });
  });

  // 6. Admin Toggle Platform Active State
  app.put('/api/admin/platforms/:id/toggle-active', requireRole(['ADMIN', 'SUPER_ADMIN']), (req: AuthenticatedRequest, res: Response) => {
    const id = req.params.id;
    const admin = req.user!;
    const platform = db.getPlatformById(id);

    if (!platform) {
      return res.status(404).json({ error: 'Platform not found.' });
    }

    const updated = db.togglePlatformActive(id);

    logAudit(
      admin,
      'PLATFORM_STATUS_TOGGLED',
      `${updated?.isActive ? 'Enabled' : 'Disabled'} platform "${platform.name}" in database`,
      platform.id,
      'platform',
      req.ip
    );

    res.json({ success: true, platform: updated });
  });

  // 7. Admin Reorder Platforms
  app.put('/api/admin/platforms/reorder', requireRole(['ADMIN', 'SUPER_ADMIN']), (req: AuthenticatedRequest, res: Response) => {
    const admin = req.user!;
    const { orderedIds } = req.body;

    if (!Array.isArray(orderedIds)) {
      return res.status(400).json({ error: 'orderedIds array is required.' });
    }

    const platforms = db.reorderPlatforms(orderedIds);

    logAudit(
      admin,
      'PLATFORMS_REORDERED',
      `Reordered ${orderedIds.length} connected platforms in database`,
      undefined,
      'platform',
      req.ip
    );

    res.json({ success: true, platforms });
  });

  // 8. Admin Sync Single Platform (Official API Adapter Execution)
  app.post('/api/admin/platforms/:id/sync', requireRole(['ADMIN', 'SUPER_ADMIN']), async (req: AuthenticatedRequest, res: Response) => {
    const id = req.params.id;
    const admin = req.user!;
    const platform = db.getPlatformById(id);

    if (!platform) {
      return res.status(404).json({ error: 'Platform not found.' });
    }

    db.updatePlatform(id, { syncStatus: 'SYNCING' });

    try {
      const syncResult = await syncEngine.syncPlatform(platform.url, platform);

      if (syncResult.success) {
        const updated = db.updatePlatform(id, {
          ...(syncResult.followers && { followers: syncResult.followers }),
          ...(syncResult.followersNum && { followersNum: syncResult.followersNum }),
          ...(syncResult.subscribers && { subscribers: syncResult.subscribers }),
          ...(syncResult.members && { members: syncResult.members }),
          ...(syncResult.liveStatus !== undefined && { liveStatus: syncResult.liveStatus }),
          ...(syncResult.viewerCount !== undefined && { viewerCount: syncResult.viewerCount }),
          ...(syncResult.logo && (!platform.logo || platform.logo.includes('flaticon')) && { logo: syncResult.logo }),
          syncStatus: 'SYNCED',
          lastSyncAt: new Date().toISOString(),
          lastSuccessfulSyncAt: new Date().toISOString(),
          lastSynced: 'Just now',
          syncSource: syncResult.syncSource,
          syncErrorMessage: undefined,
        });

        logAudit(
          admin,
          'PLATFORM_SYNC_SUCCESS',
          `Successfully synchronized live data for ${platform.name} via ${syncResult.syncSource} (${updated?.followers})`,
          platform.id,
          'platform',
          req.ip
        );

        return res.json({
          success: true,
          platform: updated,
          syncResult,
          message: `Successfully synchronized ${platform.name} (${updated?.followers})`,
        });
      } else {
        const updated = db.updatePlatform(id, {
          syncStatus: 'SYNC_FAILED',
          syncErrorMessage: syncResult.syncErrorMessage || 'Platform sync service timed out.',
          lastSyncAt: new Date().toISOString(),
        });

        logAudit(
          admin,
          'PLATFORM_SYNC_FAILED',
          `Sync warning for ${platform.name}: ${updated?.syncErrorMessage}`,
          platform.id,
          'platform',
          req.ip
        );

        return res.json({
          success: false,
          platform: updated,
          syncResult,
          error: updated?.syncErrorMessage,
        });
      }
    } catch (err: any) {
      const updated = db.updatePlatform(id, {
        syncStatus: 'SYNC_FAILED',
        syncErrorMessage: err?.message || 'Unexpected synchronization error.',
        lastSyncAt: new Date().toISOString(),
      });

      logAudit(
        admin,
        'PLATFORM_SYNC_ERROR',
        `Sync exception for ${platform.name}: ${updated?.syncErrorMessage}`,
        platform.id,
        'platform',
        req.ip
      );

      return res.status(500).json({
        success: false,
        platform: updated,
        error: updated?.syncErrorMessage,
      });
    }
  });

  // 9. Admin Sync All Platforms Concurrently
  app.post('/api/admin/platforms/sync-all', requireRole(['ADMIN', 'SUPER_ADMIN']), async (req: AuthenticatedRequest, res: Response) => {
    const admin = req.user!;
    const activeList = db.getPlatforms(false);

    const syncPromises = activeList.map(async p => {
      try {
        const result = await syncEngine.syncPlatform(p.url, p);
        if (result.success) {
          db.updatePlatform(p.id, {
            ...(result.followers && { followers: result.followers }),
            ...(result.followersNum && { followersNum: result.followersNum }),
            ...(result.subscribers && { subscribers: result.subscribers }),
            ...(result.members && { members: result.members }),
            ...(result.liveStatus !== undefined && { liveStatus: result.liveStatus }),
            ...(result.viewerCount !== undefined && { viewerCount: result.viewerCount }),
            syncStatus: 'SYNCED',
            lastSyncAt: new Date().toISOString(),
            lastSuccessfulSyncAt: new Date().toISOString(),
            lastSynced: 'Just now',
            syncSource: result.syncSource,
            syncErrorMessage: undefined,
          });
        } else {
          db.updatePlatform(p.id, {
            syncStatus: 'SYNC_FAILED',
            syncErrorMessage: result.syncErrorMessage,
            lastSyncAt: new Date().toISOString(),
          });
        }
      } catch (err: any) {
        db.updatePlatform(p.id, {
          syncStatus: 'SYNC_FAILED',
          syncErrorMessage: err?.message || 'Sync failed',
          lastSyncAt: new Date().toISOString(),
        });
      }
    });

    await Promise.all(syncPromises);

    logAudit(
      admin,
      'ALL_PLATFORMS_SYNCED',
      `Triggered bulk synchronization across ${activeList.length} active platforms`,
      undefined,
      'platform',
      req.ip
    );

    res.json({ success: true, platforms: db.getPlatforms(true) });
  });

  // Legacy route compatibility for existing clients
  app.post('/api/sync/platform/:id', requireRole(['ADMIN', 'SUPER_ADMIN']), async (req: AuthenticatedRequest, res: Response) => {
    const id = req.params.id;
    const admin = req.user!;
    const platform = db.getPlatformById(id);
    if (!platform) return res.status(404).json({ error: 'Platform not found' });
    const result = await syncEngine.syncPlatform(platform.url, platform);
    if (result.success) {
      const updated = db.updatePlatform(id, {
        ...(result.followers && { followers: result.followers }),
        ...(result.followersNum && { followersNum: result.followersNum }),
        syncStatus: 'SYNCED',
        lastSyncAt: new Date().toISOString(),
      });
      return res.json({ success: true, platform: updated });
    }
    return res.json({ success: false, platform });
  });

  // ==========================================
  // VITE MIDDLEWARE & STATIC ASSETS
  // ==========================================

  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`Sultan Gaming Full-Stack Server running securely on http://localhost:${PORT}`);
  });
}

startServer().catch(err => {
  console.error('Server startup error:', err);
});
